import React, { useState } from 'react';

import {
    View,
    Text,
    Switch,
    TouchableOpacity,
} from 'react-native';

import styles from '../styles/globalStyles';

export default function SettingsScreen(props) {
    const [darkMode, setDarkMode] = useState(false);

    return (
        <View
            style={[
                styles.container,
                {
                    backgroundColor: darkMode ? '#222' : '#fff',
                },
            ]}
        >
            <Text
                style={[
                    styles.title,
                    {
                        color: darkMode ? '#fff' : '#000',
                    },
                ]}
            >
                Settings
            </Text>

            <Text
                style={{
                    color: darkMode ? '#fff' : '#000',
                    fontSize: 18,
                    textAlign: 'center',
                }}
            >
                Dark Mode
            </Text>

            <Switch
                value={darkMode}
                onValueChange={setDarkMode}
            />

            <TouchableOpacity
                style={styles.button}
                onPress={() => props.goToHome()}
            >
                <Text style={styles.buttonText}>
                    Back to Home
                </Text>
            </TouchableOpacity>
        </View>
    );
}

// import React, { useState } from "react";

// import {
//     View,
//     Text,
//     Switch,
//     TouchableOpacity,
// } from "react-native";

// import { Ionicons } from "@expo/vector-icons";

// import styles from "../styles/globalStyles";

// export default function SettingsScreen({ navigation }) {
//     const [darkMode, setDarkMode] = useState(false);

//     return (
//         <View
//             style={[
//                 styles.container,
//                 {
//                     backgroundColor: darkMode
//                         ? "#111827"
//                         : "#F8FAFC",
//                 },
//             ]}
//         >

//             <View style={styles.settingsIconCircle}>
//                 <Ionicons
//                     name="moon"
//                     size={50}
//                     color="#3730A3"
//                 />
//             </View>

//             <Text
//                 style={[
//                     styles.title,
//                     {
//                         color: darkMode
//                             ? "#FFFFFF"
//                             : "#172554",
//                     },
//                 ]}
//             >
//                 Dark Mode
//             </Text>

//             <Text
//                 style={[
//                     styles.settingsDescription,
//                     {
//                         color: darkMode
//                             ? "#CBD5E1"
//                             : "#64748B",
//                     },
//                 ]}
//             >
//                 Turn dark mode on or off
//             </Text>

//             <Switch
//                 value={darkMode}
//                 onValueChange={setDarkMode}
//                 trackColor={{
//                     false: "#CBD5E1",
//                     true: "#60A5FA",
//                 }}
//                 thumbColor={
//                     darkMode ? "#2563EB" : "#FFFFFF"
//                 }
//             />

//             <TouchableOpacity
//                 style={styles.backButton}
//                 onPress={() => navigation.goBack()}
//             >
//                 <Ionicons
//                     name="arrow-back"
//                     size={23}
//                     color="#FFFFFF"
//                 />

//                 <Text style={styles.backButtonText}>
//                     Back
//                 </Text>
//             </TouchableOpacity>

//         </View>
//     );
// }