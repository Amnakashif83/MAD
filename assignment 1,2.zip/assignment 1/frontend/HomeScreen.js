import React from 'react';

import {
    View,
    Text,
    ImageBackground,
    TouchableOpacity,
} from 'react-native';

import styles from '../styles/globalStyles';

export default function HomeScreen(props) {
    return (
        <ImageBackground
            source={{
                uri: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3',
            }}
            style={styles.container}
        >
            <View>
                <Text style={styles.title}>
                    Student App
                </Text>

                <TouchableOpacity
                    style={styles.button}
                    onPress={() => props.goToProfile()}
                >
                    <Text style={styles.buttonText}>
                        Profile
                    </Text>
                </TouchableOpacity>
                
                  <TouchableOpacity
                    style={styles.button}
                    onPress={() => props.goToSettings()}
                >
                    <Text style={styles.buttonText}>
                        Settings
                    </Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.button}
                    onPress={() => props.goToContact()}
                >
                    <Text style={styles.buttonText}>
                        Contact
                    </Text>
                </TouchableOpacity>
            </View>
        </ImageBackground>
    );
}


// import React from "react";

// import {
//     View,
//     Text,
//     ImageBackground,
//     TouchableOpacity,
// } from "react-native";

// import { Ionicons } from "@expo/vector-icons";

// import styles from "../styles/globalStyles";

// export default function HomeScreen({ navigation }) {
//     return (
//         <ImageBackground
//             source={{
//                 uri: "https://images.unsplash.com/photo-1564981797816-1043664bf78d",
//             }}
//             style={styles.homeBackground}
//             imageStyle={styles.backgroundImage}
//         >
//             <View style={styles.overlay}>

//                 <View style={styles.homeContent}>

//                     <View style={styles.homeIconCircle}>
//                         <Ionicons
//                             name="school"
//                             size={48}
//                             color="#2563EB"
//                         />
//                     </View>

//                     <Text style={styles.homeTitle}>
//                         Student App
//                     </Text>

//                     <Text style={styles.homeSubtitle}>
//                         Learn • Grow • Achieve
//                     </Text>

//                     {/* Profile Button */}
//                     <TouchableOpacity
//                         style={[
//                             styles.homeButton,
//                             styles.profileButton,
//                         ]}
//                         onPress={() =>
//                             navigation.navigate("Profile")
//                         }
//                     >
//                         <Ionicons
//                             name="person-outline"
//                             size={26}
//                             color="#FFFFFF"
//                         />

//                         <Text style={styles.homeButtonText}>
//                             Profile
//                         </Text>
//                     </TouchableOpacity>

//                     {/* Settings Button */}
//                     <TouchableOpacity
//                         style={[
//                             styles.homeButton,
//                             styles.settingsButton,
//                         ]}
//                         onPress={() =>
//                             navigation.navigate("Settings")
//                         }
//                     >
//                         <Ionicons
//                             name="settings-outline"
//                             size={26}
//                             color="#FFFFFF"
//                         />

//                         <Text style={styles.homeButtonText}>
//                             Settings
//                         </Text>
//                     </TouchableOpacity>

//                     {/* Contact Button */}
//                     <TouchableOpacity
//                         style={[
//                             styles.homeButton,
//                             styles.contactButton,
//                         ]}
//                         onPress={() =>
//                             navigation.navigate("Contact")
//                         }
//                     >
//                         <Ionicons
//                             name="mail-outline"
//                             size={26}
//                             color="#FFFFFF"
//                         />

//                         <Text style={styles.homeButtonText}>
//                             Contact
//                         </Text>
//                     </TouchableOpacity>

//                 </View>

//             </View>
//         </ImageBackground>
//     );
// }













