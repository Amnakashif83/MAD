import React, { useState } from 'react';

import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    Alert,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../styles/globalStyles';

export default function ContactScreen(props) {
    const [email, setEmail] = useState('');

    const submitEmail = () => {
        if (email.trim() === '') {
            Alert.alert(
                'Error',
                'Please enter your email.'
            );
            return;
        }

        Alert.alert(
            'Submitted',
            'Your email is: ' + email
        );
    };

    return (
        <View style={styles.container}>

            <Text style={styles.title}>
                Contact Us
            </Text>

            <View style={styles.inputContainer}>

                <Ionicons
                    name="mail-outline"
                    size={24}
                    color="#555"
                />

                <TextInput
                    style={styles.emailInput}
                    placeholder="Enter your email"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    inputMode="email"
                    autoCapitalize="none"
                />

            </View>

            <TouchableOpacity
                style={styles.button}
                onPress={submitEmail}
            >
                <Text style={styles.buttonText}>
                    Submit
                </Text>
            </TouchableOpacity>

            <TouchableOpacity
                style={styles.button}
                onPress={() => props.goToHome()}
            >
                <Text style={styles.buttonText}>
                    Back to Home
                </Text>
            </TouchableOpacity>

        </View>
    );
}

// import React, { useState } from "react";

// import {
//     View,
//     Text,
//     TextInput,
//     TouchableOpacity,
//     Alert,
// } from "react-native";

// import { Ionicons } from "@expo/vector-icons";

// import styles from "../styles/globalStyles";

// export default function ContactScreen({ navigation }) {
//     const [email, setEmail] = useState("");

//     const submitEmail = () => {
//         if (!email.trim()) {
//             Alert.alert(
//                 "Required",
//                 "Please enter your email."
//             );
//             return;
//         }

//         Alert.alert(
//             "Submitted",
//             "Your email is: " + email
//         );
//     };

//     return (
//         <View style={styles.container}>

//             <View style={styles.contactIconCircle}>
//                 <Ionicons
//                     name="mail"
//                     size={45}
//                     color="#2563EB"
//                 />
//             </View>

//             <Text style={styles.title}>
//                 Contact Us
//             </Text>

//             <Text style={styles.contactDescription}>
//                 Enter your email and we will get back to you.
//             </Text>

//             <View style={styles.inputContainer}>
//                 <Ionicons
//                     name="mail-outline"
//                     size={23}
//                     color="#2563EB"
//                 />

//                 <TextInput
//                     style={styles.input}
//                     placeholder="Enter your email"
//                     value={email}
//                     onChangeText={setEmail}
//                     keyboardType="email-address"
//                     inputMode="email"
//                     autoCapitalize="none"
//                 />
//             </View>

//             <TouchableOpacity
//                 style={styles.submitButton}
//                 onPress={submitEmail}
//             >
//                 <Text style={styles.submitButtonText}>
//                     Submit
//                 </Text>
//             </TouchableOpacity>

//             <TouchableOpacity
//                 style={styles.backButton}
//                 onPress={() => navigation.goBack()}
//             >
//                 <Ionicons
//                     name="arrow-back"
//                     size={23}
//                     color="#FFFFFF"
//                 />

//                 <Text style={styles.backButtonText}>
//                     Back
//                 </Text>
//             </TouchableOpacity>

//         </View>
//     );
// }