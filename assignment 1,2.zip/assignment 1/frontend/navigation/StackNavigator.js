import React from "react";

import {
    createNativeStackNavigator,
} from "@react-navigation/native-stack";

import {
    DrawerActions,
} from "@react-navigation/native";

import {
    TouchableOpacity,
} from "react-native";

import {
    Ionicons,
} from "@expo/vector-icons";

import HomeScreen from "../HomeScreen";
import ProfileScreen from "../ProfileScreen";
import SettingsScreen from "../SettingsScreen";
import ContactScreen from "../ContactScreen";

const Stack = createNativeStackNavigator();

export default function StackNavigator() {
    return (
        <Stack.Navigator
            initialRouteName="Home"
            screenOptions={({ navigation }) => ({
                headerStyle: {
                    backgroundColor: "#2563EB",
                },

                headerTintColor: "#FFFFFF",

                headerTitleStyle: {
                    fontWeight: "bold",
                    fontSize: 20,
                },

                headerTitleAlign: "center",

                headerLeft: () => (
                    <TouchableOpacity
                        onPress={() =>
                            navigation.dispatch(
                                DrawerActions.toggleDrawer()
                            )
                        }
                        style={{
                            marginLeft: 10,
                            padding: 5,
                        }}
                    >
                        <Ionicons
                            name="menu"
                            size={30}
                            color="#FFFFFF"
                        />
                    </TouchableOpacity>
                ),
            })}
        >
            <Stack.Screen
                name="Home"
                component={HomeScreen}
                options={{
                    title: "Student App",
                }}
            />

            <Stack.Screen
                name="Profile"
                component={ProfileScreen}
                options={{
                    title: "Profile",
                }}
            />

            <Stack.Screen
                name="Settings"
                component={SettingsScreen}
                options={{
                    title: "Settings",
                }}
            />

            <Stack.Screen
                name="Contact"
                component={ContactScreen}
                options={{
                    title: "Contact",
                }}
            />
        </Stack.Navigator>
    );
}