import React from "react";

import {
    createDrawerNavigator,
    DrawerContentScrollView,
} from "@react-navigation/drawer";

import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import StackNavigator from "./StackNavigator";

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
    const { navigation } = props;

    const goToScreen = (screenName) => {
        navigation.navigate("Main", {
            screen: screenName,
        });

        navigation.closeDrawer();
    };

    return (
        <DrawerContentScrollView
            {...props}
            contentContainerStyle={drawerStyles.container}
        >
            {/* Drawer Header */}
            <View style={drawerStyles.header}>
                <View style={drawerStyles.logoCircle}>
                    <Ionicons
                        name="school"
                        size={38}
                        color="#2563EB"
                    />
                </View>

                <Text style={drawerStyles.headerTitle}>
                    Student App
                </Text>

                <Text style={drawerStyles.headerSubtitle}>
                    Learn • Grow • Achieve
                </Text>
            </View>

            {/* Home */}
            <TouchableOpacity
                style={drawerStyles.menuItem}
                onPress={() => goToScreen("Home")}
            >
                <Ionicons
                    name="home"
                    size={24}
                    color="#2563EB"
                />

                <Text style={drawerStyles.menuText}>
                    Home
                </Text>
            </TouchableOpacity>

            {/* Profile */}
            <TouchableOpacity
                style={drawerStyles.menuItem}
                onPress={() => goToScreen("Profile")}
            >
                <Ionicons
                    name="person"
                    size={24}
                    color="#2563EB"
                />

                <Text style={drawerStyles.menuText}>
                    Profile
                </Text>
            </TouchableOpacity>

            {/* Settings */}
            <TouchableOpacity
                style={drawerStyles.menuItem}
                onPress={() => goToScreen("Settings")}
            >
                <Ionicons
                    name="settings"
                    size={24}
                    color="#2563EB"
                />

                <Text style={drawerStyles.menuText}>
                    Settings
                </Text>
            </TouchableOpacity>

            {/* Contact */}
            <TouchableOpacity
                style={drawerStyles.menuItem}
                onPress={() => goToScreen("Contact")}
            >
                <Ionicons
                    name="mail"
                    size={24}
                    color="#2563EB"
                />

                <Text style={drawerStyles.menuText}>
                    Contact
                </Text>
            </TouchableOpacity>

            <View style={drawerStyles.line} />

            <View style={drawerStyles.footer}>
                <Ionicons
                    name="school-outline"
                    size={20}
                    color="#64748B"
                />

                <Text style={drawerStyles.footerText}>
                    Student Management App
                </Text>
            </View>
        </DrawerContentScrollView>
    );
}

export default function DrawerNavigator() {
    return (
        <Drawer.Navigator
            drawerContent={(props) => (
                <CustomDrawerContent {...props} />
            )}
            screenOptions={{
                headerShown: false,
                drawerType: "slide",
                drawerStyle: {
                    width: 300,
                },
            }}
        >
            <Drawer.Screen
                name="Main"
                component={StackNavigator}
            />
        </Drawer.Navigator>
    );
}

const drawerStyles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFFFFF",
    },

    header: {
        backgroundColor: "#2563EB",
        paddingVertical: 35,
        paddingHorizontal: 20,
        alignItems: "center",
        marginBottom: 15,
    },

    logoCircle: {
        width: 75,
        height: 75,
        borderRadius: 38,
        backgroundColor: "#FFFFFF",
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 12,
    },

    headerTitle: {
        color: "#FFFFFF",
        fontSize: 25,
        fontWeight: "bold",
    },

    headerSubtitle: {
        color: "#DBEAFE",
        fontSize: 14,
        marginTop: 5,
    },

    menuItem: {
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: 15,
        marginVertical: 5,
        paddingVertical: 15,
        paddingHorizontal: 18,
        borderRadius: 12,
    },

    menuText: {
        fontSize: 17,
        color: "#172554",
        marginLeft: 18,
        fontWeight: "600",
    },

    line: {
        height: 1,
        backgroundColor: "#E2E8F0",
        marginHorizontal: 20,
        marginTop: 20,
        marginBottom: 20,
    },

    footer: {
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 20,
    },

    footerText: {
        color: "#64748B",
        fontSize: 13,
        marginLeft: 10,
    },
});