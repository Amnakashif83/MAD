import React, { useState } from 'react';

import {
    View,
    Text,
    Image,
    TextInput,
    TouchableOpacity,
} from 'react-native';

import styles from '../styles/globalStyles';

export default function ProfileScreen(props) {
    const [name, setName] = useState('');
    const [age, setAge] = useState('');

    return (
        <View style={styles.container}>

            <Text style={styles.title}>
                Student Profile
            </Text>

            <Image
                source={{
                    uri: 'https://i.pravatar.cc/150',
                }}
                style={{
                    width: 150,
                    height: 150,
                    borderRadius: 75,
                    alignSelf: 'center',
                    marginBottom: 20,
                }}
            />

            <TextInput
                style={styles.input}
                placeholder="Enter your name"
                value={name}
                onChangeText={setName}
                inputMode="text"
            />

            <TextInput
                style={styles.input}
                placeholder="Enter your age"
                value={age}
                onChangeText={setAge}
                keyboardType="numeric"
                inputMode="numeric"
            />

            <Text style={styles.infoText}>
                Name: {name}
            </Text>

            <Text style={styles.infoText}>
                Age: {age}
            </Text>

            <TouchableOpacity
                style={styles.button}
                onPress={() => props.goToHome()}
            >
                <Text style={styles.buttonText}>
                    Back to Home
                </Text>
            </TouchableOpacity>

        </View>
    );
}

// import React, { useState } from "react";

// import {
//     View,
//     Text,
//     Image,
//     TextInput,
//     TouchableOpacity,
// } from "react-native";

// import { Ionicons } from "@expo/vector-icons";

// import styles from "../styles/globalStyles";

// export default function ProfileScreen({ navigation }) {
//     const [name, setName] = useState("");
//     const [age, setAge] = useState("");

//     return (
//         <View style={styles.container}>

//             <Image
//                 source={{
//                     uri: "https://i.pravatar.cc/150",
//                 }}
//                 style={styles.profileImage}
//             />

//             <Text style={styles.title}>
//                 Student Profile
//             </Text>

//             <View style={styles.inputContainer}>
//                 <Ionicons
//                     name="person-outline"
//                     size={23}
//                     color="#2563EB"
//                 />

//                 <TextInput
//                     style={styles.input}
//                     placeholder="Enter your name"
//                     value={name}
//                     onChangeText={setName}
//                     inputMode="text"
//                 />
//             </View>

//             <View style={styles.inputContainer}>
//                 <Ionicons
//                     name="calendar-outline"
//                     size={23}
//                     color="#2563EB"
//                 />

//                 <TextInput
//                     style={styles.input}
//                     placeholder="Enter your age"
//                     value={age}
//                     onChangeText={setAge}
//                     keyboardType="numeric"
//                     inputMode="numeric"
//                 />
//             </View>

//             <View style={styles.infoBox}>
//                 <Text style={styles.infoText}>
//                     Name: {name || "Your Name"}
//                 </Text>

//                 <Text style={styles.infoText}>
//                     Age: {age || "Your Age"}
//                 </Text>
//             </View>

//             <TouchableOpacity
//                 style={styles.backButton}
//                 onPress={() => navigation.goBack()}
//             >
//                 <Ionicons
//                     name="arrow-back"
//                     size={23}
//                     color="#FFFFFF"
//                 />

//                 <Text style={styles.backButtonText}>
//                     Back
//                 </Text>
//             </TouchableOpacity>

//         </View>
//     );
// }