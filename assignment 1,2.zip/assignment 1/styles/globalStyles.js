import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
        justifyContent: 'center',
    },

    title: {
        fontSize: 30,
        fontWeight: 'bold',
        fontFamily: 'Poppins',
        textAlign: 'center',
        marginBottom: 30,
    },

    button: {
        width: 250,
        padding: 15,
        margin: 10,
        borderRadius: 10,
        alignItems: 'center',
        alignSelf: 'center',
        backgroundColor: '#4A90E2',
    },

    buttonText: {
        fontSize: 18,
        fontWeight: 'bold',
        fontFamily: 'Poppins',
        color: '#fff',
    },

    input: {
        borderWidth: 1,
        borderColor: '#999',
        padding: 12,
        marginVertical: 10,
        borderRadius: 8,
        fontSize: 16,
        backgroundColor: '#fff',
    },

    infoText: {
        fontSize: 18,
        marginVertical: 5,
    },

    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#999',
        borderRadius: 8,
        paddingHorizontal: 12,
        marginVertical: 10,
        backgroundColor: '#fff',
    },

    emailInput: {
        flex: 1,
        padding: 12,
        fontSize: 16,
        marginLeft: 8,
    },
});

export default styles;





// import { StyleSheet } from "react-native";

// const styles = StyleSheet.create({

//     /* ---------------- CONTAINER ---------------- */

//     container: {
//         flex: 1,
//         backgroundColor: "#F8FAFC",
//         padding: 20,
//         justifyContent: "center",
//     },

//     /* ---------------- HOME SCREEN ---------------- */

//     homeBackground: {
//         flex: 1,
//         justifyContent: "center",
//     },

//     backgroundImage: {
//         resizeMode: "cover",
//     },

//     overlay: {
//         flex: 1,
//         backgroundColor: "rgba(15, 23, 42, 0.42)",
//         justifyContent: "center",
//         alignItems: "center",
//         padding: 20,
//     },

//     homeContent: {
//         width: "100%",
//         alignItems: "center",
//     },

//     homeIconCircle: {
//         width: 85,
//         height: 85,
//         borderRadius: 43,
//         backgroundColor: "#FFFFFF",
//         justifyContent: "center",
//         alignItems: "center",
//         marginBottom: 15,
//     },

//     homeTitle: {
//         color: "#FFFFFF",
//         fontSize: 34,
//         fontWeight: "bold",
//         textAlign: "center",
//     },

//     homeSubtitle: {
//         color: "#E0E7FF",
//         fontSize: 17,
//         marginTop: 5,
//         marginBottom: 25,
//     },

//     /* ---------------- HOME BUTTONS ---------------- */

//     homeButton: {
//         width: "100%",
//         height: 62,
//         borderRadius: 14,
//         flexDirection: "row",
//         alignItems: "center",
//         justifyContent: "center",
//         marginVertical: 7,
//         elevation: 4,
//     },

//     profileButton: {
//         backgroundColor: "#2563EB",
//     },

//     settingsButton: {
//         backgroundColor: "#7C3AED",
//     },

//     contactButton: {
//         backgroundColor: "#10B981",
//     },

//     homeButtonText: {
//         color: "#FFFFFF",
//         fontSize: 18,
//         fontWeight: "bold",
//         marginLeft: 15,
//     },

//     /* ---------------- TITLES ---------------- */

//     title: {
//         fontSize: 28,
//         fontWeight: "bold",
//         textAlign: "center",
//         color: "#172554",
//         marginBottom: 20,
//     },

//     /* ---------------- PROFILE ---------------- */

//     profileImage: {
//         width: 150,
//         height: 150,
//         borderRadius: 75,
//         alignSelf: "center",
//         marginBottom: 20,
//         borderWidth: 4,
//         borderColor: "#FFFFFF",
//         elevation: 5,
//     },

//     inputContainer: {
//         width: "100%",
//         minHeight: 55,
//         flexDirection: "row",
//         alignItems: "center",
//         backgroundColor: "#FFFFFF",
//         borderWidth: 1,
//         borderColor: "#CBD5E1",
//         borderRadius: 12,
//         paddingHorizontal: 15,
//         marginVertical: 7,
//     },

//     input: {
//         flex: 1,
//         fontSize: 16,
//         paddingHorizontal: 12,
//         color: "#172554",
//     },

//     infoBox: {
//         width: "100%",
//         backgroundColor: "#EFF6FF",
//         borderRadius: 12,
//         padding: 15,
//         marginTop: 12,
//         marginBottom: 10,
//     },

//     infoText: {
//         fontSize: 16,
//         color: "#172554",
//         fontWeight: "600",
//         marginVertical: 4,
//     },

//     /* ---------------- SETTINGS ---------------- */

//     settingsIconCircle: {
//         width: 100,
//         height: 100,
//         borderRadius: 50,
//         backgroundColor: "#EEF2FF",
//         justifyContent: "center",
//         alignItems: "center",
//         alignSelf: "center",
//         marginBottom: 20,
//     },

//     settingsDescription: {
//         fontSize: 16,
//         textAlign: "center",
//         marginBottom: 20,
//     },

//     /* ---------------- CONTACT ---------------- */

//     contactIconCircle: {
//         width: 90,
//         height: 90,
//         borderRadius: 45,
//         backgroundColor: "#DBEAFE",
//         justifyContent: "center",
//         alignItems: "center",
//         alignSelf: "center",
//         marginBottom: 15,
//     },

//     contactDescription: {
//         fontSize: 15,
//         color: "#64748B",
//         textAlign: "center",
//         marginBottom: 15,
//     },

//     submitButton: {
//         width: "100%",
//         height: 55,
//         borderRadius: 12,
//         backgroundColor: "#2563EB",
//         justifyContent: "center",
//         alignItems: "center",
//         marginTop: 15,
//     },

//     submitButtonText: {
//         color: "#FFFFFF",
//         fontSize: 17,
//         fontWeight: "bold",
//     },

//     /* ---------------- BACK BUTTON ---------------- */

//     backButton: {
//         width: "100%",
//         height: 55,
//         borderRadius: 12,
//         backgroundColor: "#2563EB",
//         flexDirection: "row",
//         justifyContent: "center",
//         alignItems: "center",
//         marginTop: 15,
//     },

//     backButtonText: {
//         color: "#FFFFFF",
//         fontSize: 17,
//         fontWeight: "bold",
//         marginLeft: 10,
//     },

// });

// export default styles;