import React from "react";

import {
  View,
  Text,
  StyleSheet,
} from "react-native";

import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from "@react-navigation/drawer";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";

import HomeScreen from "../screens/HomeScreen";
import ProductsScreen from "../screens/ProductsScreen";
import WishlistScreen from "../screens/WishlistScreen";
import ProfileScreen from "../screens/ProfileScreen";
import SettingsScreen from "../screens/SettingsScreen";

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
  const { colors } = useTheme();
  const { user, logout } = useAuth();

  async function handleLogout() {
    await logout();

    props.navigation.reset({
      index: 0,
      routes: [{ name: "Welcome" }],
    });
  }

  return (
    <DrawerContentScrollView
      {...props}
      contentContainerStyle={[
        styles.drawerContainer,
        { backgroundColor: colors.background },
      ]}
    >
      <View
        style={[
          styles.header,
          { backgroundColor: colors.primary },
        ]}
      >
        <View style={styles.logoCircle}>
          <Ionicons
            name="flower-outline"
            size={30}
            color={colors.primary}
          />
        </View>

        <Text style={styles.brandName}>LUNA</Text>

        <Text style={styles.brandSubtitle}>
          BEAUTY • STYLE • YOU
        </Text>

        <Text style={styles.userName}>
          Hello, {user?.name || "Guest"} 💗
        </Text>
      </View>

      <DrawerItemList {...props} />

      <View
        style={[
          styles.offerCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <Ionicons
          name="pricetag"
          size={22}
          color={colors.primary}
        />

        <View style={styles.offerContent}>
          <Text
            style={[
              styles.offerTitle,
              { color: colors.text },
            ]}
          >
            Special Offer
          </Text>

          <Text
            style={[
              styles.offerDescription,
              { color: colors.muted },
            ]}
          >
            Shop for Rs. 1,200 or more and get 20% off
            eligible sale products.
          </Text>
        </View>
      </View>

      <DrawerItem
        label="Welcome"
        onPress={() => props.navigation.navigate("Welcome")}
        icon={({ color, size }) => (
          <Ionicons
            name="home-outline"
            size={size}
            color={color}
          />
        )}
        labelStyle={{ color: colors.text }}
      />

      <DrawerItem
        label="Logout"
        onPress={handleLogout}
        icon={({ color, size }) => (
          <Ionicons
            name="log-out-outline"
            size={size}
            color={color}
          />
        )}
        labelStyle={{
          color: colors.error,
          fontWeight: "700",
        }}
      />
    </DrawerContentScrollView>
  );
}

export default function DrawerNavigator() {
  const { colors } = useTheme();

  return (
    <Drawer.Navigator
      initialRouteName="Home"
      drawerContent={(props) => (
        <CustomDrawerContent {...props} />
      )}
      screenOptions={{
        headerShown: true,

        headerStyle: {
          backgroundColor: colors.card,
        },

        headerTintColor: colors.text,

        headerTitleStyle: {
          fontWeight: "900",
        },

        drawerStyle: {
          backgroundColor: colors.background,
          width: 290,
        },

        drawerActiveTintColor: colors.primary,
        drawerInactiveTintColor: colors.muted,

        drawerActiveBackgroundColor: colors.card,

        drawerLabelStyle: {
          fontSize: 14,
          fontWeight: "700",
        },

        sceneStyle: {
          backgroundColor: colors.background,
        },
      }}
    >
      <Drawer.Screen
        name="Home"
        component={HomeScreen}
        options={{
          title: "LUNA Shopping",
          drawerIcon: ({ color, size }) => (
            <Ionicons
              name="home-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Products"
        component={ProductsScreen}
        options={{
          title: "All Products",
          drawerIcon: ({ color, size }) => (
            <Ionicons
              name="grid-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Wishlist"
        component={WishlistScreen}
        options={{
          title: "My Wishlist",
          drawerIcon: ({ color, size }) => (
            <Ionicons
              name="heart-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          title: "My Account",
          drawerIcon: ({ color, size }) => (
            <Ionicons
              name="person-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />

      <Drawer.Screen
        name="Settings"
        component={SettingsScreen}
        options={{
          title: "Settings",
          drawerIcon: ({ color, size }) => (
            <Ionicons
              name="settings-outline"
              size={size}
              color={color}
            />
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  drawerContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },

  header: {
    paddingVertical: 28,
    paddingHorizontal: 20,
    alignItems: "center",
    marginBottom: 12,
    borderBottomLeftRadius: 22,
    borderBottomRightRadius: 22,
  },

  logoCircle: {
    height: 62,
    width: 62,
    borderRadius: 31,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
  },

  brandName: {
    color: "#FFFFFF",
    fontSize: 29,
    fontWeight: "900",
    letterSpacing: 5,
  },

  brandSubtitle: {
    color: "#FFFFFF",
    fontSize: 9,
    letterSpacing: 2,
    marginTop: 5,
  },

  userName: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
    marginTop: 15,
  },

  offerCard: {
    marginHorizontal: 15,
    marginTop: 15,
    marginBottom: 12,
    padding: 14,
    borderRadius: 15,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
  },

  offerContent: {
    flex: 1,
  },

  offerTitle: {
    fontSize: 13,
    fontWeight: "900",
    marginBottom: 5,
  },

  offerDescription: {
    fontSize: 11,
    lineHeight: 17,
  },
});
