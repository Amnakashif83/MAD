// ============================================
// LUNA SHOPPING APP - STACK NAVIGATOR
// ============================================

import React from "react";

import {
  createNativeStackNavigator,
} from "@react-navigation/native-stack";

import { useTheme } from "../context/ThemeContext";

// Screens
import SplashScreen from "../screens/SplashScreen";
import WelcomeScreen from "../screens/WelcomeScreen";

import LoginScreen from "../screens/LoginScreen";
import SignupScreen from "../screens/SignupScreen";
import ForgotPasswordScreen from "../screens/ForgotPasswordScreen";

import HomeScreen from "../screens/HomeScreen";
import ProductsScreen from "../screens/ProductsScreen";
import DetailsScreen from "../screens/DetailsScreen";

import CartScreen from "../screens/CartScreen";
import CheckoutScreen from "../screens/CheckoutScreen";
import WishlistScreen from "../screens/WishlistScreen";

import ProfileScreen from "../screens/ProfileScreen";
import SettingsScreen from "../screens/SettingsScreen";

import OrderSuccessScreen from "../screens/OrderSuccessScreen";

// Main drawer
import DrawerNavigator from "./DrawerNavigator";

const Stack = createNativeStackNavigator();

// ============================================
// STACK NAVIGATOR
// ============================================

export default function StackNavigator() {
  const { colors } = useTheme();

  return (
    <Stack.Navigator
      initialRouteName="Splash"
      screenOptions={{
        headerShown: false,

        animation: "slide_from_right",

        contentStyle: {
          backgroundColor: colors.background,
        },
      }}
    >
      {/* ======================================
          SPLASH & WELCOME
      ====================================== */}

      <Stack.Screen
        name="Splash"
        component={SplashScreen}
      />

      <Stack.Screen
        name="Welcome"
        component={WelcomeScreen}
      />

      {/* ======================================
          AUTHENTICATION
      ====================================== */}

      <Stack.Screen
        name="Login"
        component={LoginScreen}
      />

      <Stack.Screen
        name="Signup"
        component={SignupScreen}
      />

      <Stack.Screen
        name="ForgotPassword"
        component={ForgotPasswordScreen}
      />

      {/* ======================================
          MAIN DRAWER
      ====================================== */}

      <Stack.Screen
        name="Main"
        component={DrawerNavigator}
      />

      {/* ======================================
          SHOPPING
      ====================================== */}

      <Stack.Screen
        name="Home"
        component={HomeScreen}
      />

      <Stack.Screen
        name="Products"
        component={ProductsScreen}
      />

      <Stack.Screen
        name="Details"
        component={DetailsScreen}
      />

      <Stack.Screen
        name="Cart"
        component={CartScreen}
      />

      <Stack.Screen
        name="Checkout"
        component={CheckoutScreen}
      />

      <Stack.Screen
        name="Wishlist"
        component={WishlistScreen}
      />

      {/* ======================================
          ACCOUNT & SETTINGS
      ====================================== */}

      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
      />

      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
      />

      {/* ======================================
          ORDER SUCCESS
      ====================================== */}

      <Stack.Screen
        name="OrderSuccess"
        component={OrderSuccessScreen}
      />
    </Stack.Navigator>
  );
}
