// ============================================
// LUNA SHOPPING APP
// File: frontend/data/api.js
// ============================================

import { PRODUCTS } from "./products";

const API_BASE_URL = "https://fakestoreapi.com";

const SUPPORTED_CATEGORIES = [
  "Makeup",
  "Men",
  "Women",
  "Accessories",
];

// ============================================
// VALIDATE IMAGE URL
// ============================================

export function isValidImageUrl(image) {
  if (typeof image !== "string") {
    return false;
  }

  const value = image.trim();

  if (!value || value.toLowerCase() === "string") {
    return false;
  }

  return /^https?:\/\/\S+/i.test(value);
}

// ============================================
// NORMALIZE API PRODUCT
// ============================================

function normalizeApiProduct(product) {
  const originalCategory = String(
    product.category || ""
  ).toLowerCase();

  let category;

  if (originalCategory.includes("men's clothing")) {
    category = "Men";
  } else if (
    originalCategory.includes("women's clothing")
  ) {
    category = "Women";
  } else if (
    originalCategory.includes("jewelery") ||
    originalCategory.includes("jewelry")
  ) 
{}

  const priceInUSD = Number(product.price) || 0;

  const image = isValidImageUrl(product.image)
    ? product.image
    : null;

  return {
    id: `api-${product.id}`,

    title: product.title || "Beautiful Product",

    name: product.title || "Beautiful Product",

    description: product.description || "",

    category,

    image,

    thumbnail: image,

    // Convert USD to PKR.
    // This is an approximate conversion rate.
    price: Math.round(priceInUSD * 280),

    rating: {
      rate: Number(product.rating?.rate) || 0,
      count: Number(product.rating?.count) || 0,
    },

    onSale: false,

    source: "api",
  };
}

// ============================================
// GET LOCAL PRODUCTS
// ============================================

export function getLocalProducts() {
  return Array.isArray(PRODUCTS)
    ? PRODUCTS.filter((product) => {
        return SUPPORTED_CATEGORIES.includes(
          product.category
        );
      })
    : [];
}

// ============================================
// FETCH PRODUCTS
// ============================================

export async function fetchProducts() {
  const localProducts = getLocalProducts();

  try {
    const response = await fetch(
      `${API_BASE_URL}/products`,
      {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      }
    );

    if (!response.ok) {
      throw new Error(
        `Products API returned ${response.status}`
      );
    }

    const data = await response.json();

    if (!Array.isArray(data)) {
      throw new Error("Invalid products response");
    }

    const apiProducts = data
      .map(normalizeApiProduct)
      .filter(Boolean);

    // Local products are shown first.
    // API products are added after local products.
    const combinedProducts = [
      ...localProducts,
      ...apiProducts,
    ];

    // Prevent duplicate IDs.
    const uniqueProducts = [];
    const seenIds = new Set();

    combinedProducts.forEach((product) => {
      const id = String(product.id);

      if (!seenIds.has(id)) {
        seenIds.add(id);
        uniqueProducts.push(product);
      }
    });

    return uniqueProducts;
  } catch (error) {
    console.warn(
      "Products API unavailable. Showing local products:",
      error.message
    );

    // The app can still display products offline.
    return localProducts;
  }
}

// ============================================
// BACKWARD COMPATIBILITY
// Supports HomeScreen files using getProducts()
// ============================================

export async function getProducts() {
  return fetchProducts();
}

// ============================================
// FETCH PRODUCT BY ID
// ============================================

export async function fetchProductById(id) {
  const localProduct = PRODUCTS.find(
    (product) => String(product.id) === String(id)
  );

  if (localProduct) {
    return localProduct;
  }

  const productId = String(id).replace(/^api-/, "");

  if (!/^\d+$/.test(productId)) {
    return null;
  }

  try {
    const response = await fetch(
      `${API_BASE_URL}/products/${productId}`
    );

    if (!response.ok) {
      throw new Error(
        `Product API returned ${response.status}`
      );
    }

    const data = await response.json();

    return normalizeApiProduct(data);
  } catch (error) {
    console.warn(
      "Unable to fetch product:",
      error.message
    );

    return null;
  }
}

// ============================================
// BACKWARD COMPATIBILITY
// ============================================

export async function getProductById(id) {
  return fetchProductById(id);
}

// ============================================
// FETCH CATEGORIES
// ============================================

export async function fetchCategories() {
  return SUPPORTED_CATEGORIES.map((name, index) => ({
    id: index + 1,
    name,
  }));
}

// ============================================
// FETCH PRODUCTS BY CATEGORY
// ============================================

export async function fetchProductsByCategory(category) {
  const normalizedCategory = String(category || "")
    .trim()
    .toLowerCase();

  const products = await fetchProducts();

  return products.filter(
    (product) =>
      String(product.category || "").toLowerCase() ===
      normalizedCategory
  );
}

// ============================================
// BACKWARD COMPATIBILITY
// ============================================

export async function getProductsByCategory(category) {
  return fetchProductsByCategory(category);
}

// ============================================
// DEFAULT EXPORT
// ============================================

const api = {
  fetchProducts,
  getProducts,

  fetchProductById,
  getProductById,

  fetchCategories,

  fetchProductsByCategory,
  getProductsByCategory,

  getLocalProducts,
  isValidImageUrl,
};

export default api;
