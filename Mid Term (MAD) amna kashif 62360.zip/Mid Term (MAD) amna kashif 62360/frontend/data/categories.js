// ============================================
// LUNA SHOPPING APP
// File: frontend/data/categories.js
// ============================================

export const CATEGORIES = [
  {
    id: "makeup",
    name: "Makeup",
    title: "Makeup",
    description: "Beauty and makeup essentials",
    icon: "color-palette-outline",
    image:
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500",
  },

  {
    id: "men",
    name: "Men",
    title: "Men",
    description: "Men's clothing and shoes",
    icon: "man-outline",
    image:
      "https://images.unsplash.com/photo-1617137968427-85924c800a22?w=500",
  },

  {
    id: "women",
    name: "Women",
    title: "Women",
    description: "Women's fashion collection",
    icon: "woman-outline",
    image:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=500",
  },

  {
    id: "accessories",
    name: "Accessories",
    title: "Accessories",
    description: "Watches, bags and jewelry",
    icon: "watch-outline",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500",
  },
];

// ============================================
// GET CATEGORY BY ID
// ============================================

export function getCategoryById(categoryId) {
  const normalizedId = String(categoryId || "")
    .trim()
    .toLowerCase();

  return (
    CATEGORIES.find(
      (category) =>
        category.id.toLowerCase() === normalizedId
    ) || null
  );
}

// ============================================
// GET CATEGORY NAMES
// ============================================

export function getCategoryNames() {
  return CATEGORIES.map((category) => category.name);
}

// ============================================
// DEFAULT EXPORT
// ============================================

export default CATEGORIES;
