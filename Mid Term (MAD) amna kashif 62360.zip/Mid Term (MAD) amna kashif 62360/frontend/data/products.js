// ============================================
// LUNA SHOPPING APP
// File: frontend/data/products.js
// ============================================

export const PRODUCTS = [
  // ==========================================
  // MAKEUP
  // ==========================================

  {
    id: "makeup-1",
    title: "Rose Pink Makeup Set",
    name: "Rose Pink Makeup Set",
    description:
      "A beautiful makeup collection for everyday looks and special occasions.",
    price: 1450,
    category: "Makeup",
    image:
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.7,
      count: 120,
    },
    onSale: true,
  },

  {
    id: "makeup-2",
    title: "Luxury Makeup Palette",
    name: "Luxury Makeup Palette",
    description:
      "A versatile makeup palette suitable for natural and glamorous looks.",
    price: 1850,
    category: "Makeup",
    image:
      "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.5,
      count: 95,
    },
    onSale: true,
  },

  {
    id: "makeup-3",
    title: "Everyday Beauty Essentials",
    name: "Everyday Beauty Essentials",
    description:
      "A selection of everyday beauty essentials for your personal collection.",
    price: 950,
    category: "Makeup",
    image:
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.4,
      count: 78,
    },
    onSale: false,
  },

  {
    id: "makeup-4",
    title: "Premium Beauty Collection",
    name: "Premium Beauty Collection",
    description:
      "A premium collection designed for a polished and elegant beauty routine.",
    price: 2200,
    category: "Makeup",
image: require("../../assets/images/foundation.jpg.png"),
thumbnail: require("../../assets/images/foundation.jpg.png"),

    rating: {
      rate: 4.8,
      count: 140,
    },
    onSale: true,
  },

  // ==========================================
  // MEN
  // ==========================================

  {
    id: "men-1",
    title: "Classic Men's Shirt",
    name: "Classic Men's Shirt",
    description:
      "A versatile men's shirt for casual outings and everyday wear.",
    price: 1800,
    category: "Men",
    image:
      "https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1603252109303-2751441dd157?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.6,
      count: 110,
    },
    onSale: true,
  },

  {
    id: "men-2",
    title: "Men's Casual Sneakers",
    name: "Men's Casual Sneakers",
    description:
      "Comfortable casual sneakers designed for everyday activities.",
    price: 2600,
    category: "Men",
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.7,
      count: 180,
    },
    onSale: true,
  },

  {
    id: "men-3",
    title: "Men's Everyday Jacket",
    name: "Men's Everyday Jacket",
    description:
      "A stylish jacket that works well with casual everyday outfits.",
    price: 3200,
    category: "Men",
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.5,
      count: 85,
    },
    onSale: true,
  },

  {
    id: "men-4",
    title: "Classic Men's T-Shirt",
    name: "Classic Men's T-Shirt",
    description:
      "A comfortable basic T-shirt for relaxed and casual styling.",
    price: 850,
    category: "Men",
    image:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.3,
      count: 72,
    },
    onSale: false,
  },

  // ==========================================
  // WOMEN
  // ==========================================

  {
    id: "women-1",
    title: "Elegant Women's Outfit",
    name: "Elegant Women's Outfit",
    description:
      "An elegant outfit for celebrations, gatherings and everyday style.",
    price: 2400,
    category: "Women",
    image:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.8,
      count: 150,
    },
    onSale: true,
  },

  {
    id: "women-2",
    title: "Women's Fashion Dress",
    name: "Women's Fashion Dress",
    description:
      "A fashionable dress for a graceful and contemporary look.",
    price: 2850,
    category: "Women",
    image:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.6,
      count: 125,
    },
    onSale: true,
  },

  {
    id: "women-3",
    title: "Women's Casual Top",
    name: "Women's Casual Top",
    description:
      "A versatile top that pairs easily with your favourite outfits.",
    price: 1100,
    category: "Women",
    image:
      "https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.4,
      count: 68,
    },
    onSale: false,
  },

  {
    id: "women-4",
    title: "Women's Premium Collection",
    name: "Women's Premium Collection",
    description:
      "A refined fashion selection for a modern and confident wardrobe.",
    price: 3500,
    category: "Women",
    image:
      "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.9,
      count: 190,
    },
    onSale: true,
  },

  // ==========================================
  // ACCESSORIES
  // ==========================================

  {
    id: "accessories-1",
    title: "Minimal Wrist Watch",
    name: "Minimal Wrist Watch",
    description:
      "A minimalist wristwatch with a versatile design for everyday wear.",
    price: 2100,
    category: "Accessories",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.7,
      count: 210,
    },
    onSale: true,
  },

  {
    id: "accessories-2",
    title: "Elegant Women's Handbag",
    name: "Elegant Women's Handbag",
    description:
      "An elegant handbag for carrying your daily essentials in style.",
    price: 2800,
    category: "Accessories",
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.6,
      count: 130,
    },
    onSale: true,
  },

  {
    id: "accessories-3",
    title: "Classic Jewelry Collection",
    name: "Classic Jewelry Collection",
    description:
      "A timeless jewelry collection for special occasions and everyday styling.",
    price: 1650,
    category: "Accessories",
    image:
      "https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.5,
      count: 98,
    },
    onSale: true,
  },

  {
    id: "accessories-4",
    title: "Stylish Sunglasses",
    name: "Stylish Sunglasses",
    description:
      "A fashionable accessory for completing your everyday look.",
    price: 900,
    category: "Accessories",
    image:
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=600&q=80",
    thumbnail:
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=300&q=80",
    rating: {
      rate: 4.4,
      count: 76,
    },
    onSale: false,
  },
];

// ============================================
// PRODUCT HELPERS
// ============================================

export function getProductById(id) {
  return (
    PRODUCTS.find(
      (product) => String(product.id) === String(id)
    ) || null
  );
}

export function getProductsByCategory(category) {
  const normalizedCategory = String(category || "")
    .trim()
    .toLowerCase();

  return PRODUCTS.filter(
    (product) =>
      String(product.category).toLowerCase() ===
      normalizedCategory
  );
}

export function getFeaturedProducts(limit = 8) {
  return PRODUCTS.slice(0, Math.max(0, limit));
}

export default PRODUCTS;
