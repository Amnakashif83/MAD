// frontend/theme/colors.js

export const LIGHT_COLORS = {
  primary: "#705582",
  secondary: "#A894B8",

  background: "#F1EBF5",
  card: "#FFFFFF",

  text: "#29252D",
  secondaryText: "#705582",
  muted: "#776D7D",
  placeholder: "#776D7D",

  border: "#E9C9D8",
  accent: "#E9C9D8",

  buttonBackground: "#705582",
  buttonText: "#FFFFFF",

  inputBackground: "#FFFFFF",

  success: "#2E8B57",
  error: "#D9534F",
  warning: "#E5A000",

  heart: "#E85D86",

  overlay: "rgba(35, 15, 40, 0.48)",

  tabBackground: "#FFFFFF",
  tabActive: "#705582",
  tabInactive: "#9B8DA5",

  white: "#FFFFFF",
  black: "#000000",

  sale: "#E85D86",
  saleBackground: "#FCE7EF",
};

export const DARK_COLORS = {
  primary: "#A894B8",
  secondary: "#E9C9D8",

  background: "#29252D",
  card: "#38313D",

  text: "#FFFFFF",
  secondaryText: "#D2C3DC",
  muted: "#C0B4C9",
  placeholder: "#B7A9C2",

  border: "#705582",
  accent: "#E9C9D8",

  buttonBackground: "#705582",
  buttonText: "#FFFFFF",

  inputBackground: "#38313D",

  success: "#69C58A",
  error: "#FF7777",
  warning: "#FFD166",

  heart: "#FF7FA3",

  overlay: "rgba(0, 0, 0, 0.60)",

  tabBackground: "#38313D",
  tabActive: "#E9C9D8",
  tabInactive: "#B7A9C2",

  white: "#FFFFFF",
  black: "#000000",

  sale: "#FF7FA3",
  saleBackground: "#493440",
};

// Default theme
export const COLORS = LIGHT_COLORS;

// Get theme colors
export function getThemeColors(isDark) {
  return isDark ? DARK_COLORS : LIGHT_COLORS;
}
