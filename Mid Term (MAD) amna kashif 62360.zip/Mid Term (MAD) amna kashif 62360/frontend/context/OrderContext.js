
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

const OrderContext = createContext(null);

const ORDERS_STORAGE_KEY = "@luna_orders";

// ============================================
// ORDER PROVIDER
// ============================================

export function OrderProvider({ children }) {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // ==========================================
  // LOAD SAVED ORDERS
  // ==========================================

  useEffect(() => {
    let mounted = true;

    async function loadOrders() {
      try {
        const storedOrders =
          await AsyncStorage.getItem(
            ORDERS_STORAGE_KEY
          );

        if (storedOrders && mounted) {
          const parsedOrders = JSON.parse(storedOrders);

          if (Array.isArray(parsedOrders)) {
            setOrders(parsedOrders);
          }
        }
      } catch (error) {
        console.error("Order restore error:", error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadOrders();

    return () => {
      mounted = false;
    };
  }, []);

  // ==========================================
  // SAVE ORDERS
  // ==========================================

  useEffect(() => {
    if (loading) {
      return;
    }

    AsyncStorage.setItem(
      ORDERS_STORAGE_KEY,
      JSON.stringify(orders)
    ).catch((error) => {
      console.error("Order save error:", error);
    });
  }, [orders, loading]);

  // ==========================================
  // ADD ORDER
  // ==========================================

  const addOrder = useCallback(
    async (orderData) => {
      if (
        !orderData ||
        !Array.isArray(orderData.items) ||
        orderData.items.length === 0
      ) {
        return {
          success: false,
          message: "Your order has no products.",
        };
      }

      const newOrder = {
        id: `LUNA-${Date.now()}`,

        items: orderData.items.map((item) => ({
          ...item,
          quantity: Number(item.quantity) || 1,
          price: Number(item.price) || 0,
        })),

        subtotal: Number(orderData.subtotal) || 0,
        discount: Number(orderData.discount) || 0,
        total: Number(orderData.total) || 0,

        customer: orderData.customer || null,

        shippingAddress:
          orderData.shippingAddress || "",

        paymentMethod:
          orderData.paymentMethod || "Cash on Delivery",

        status: "Confirmed",

        createdAt: new Date().toISOString(),
      };

      try {
        const updatedOrders = [
          newOrder,
          ...orders,
        ];

        await AsyncStorage.setItem(
          ORDERS_STORAGE_KEY,
          JSON.stringify(updatedOrders)
        );

        setOrders(updatedOrders);

        return {
          success: true,
          order: newOrder,
        };
      } catch (error) {
        console.error("Add order error:", error);

        return {
          success: false,
          message:
            "Unable to save your order. Please try again.",
        };
      }
    },
    [orders]
  );

  // ==========================================
  // GET ORDER BY ID
  // ==========================================

  const getOrderById = useCallback(
    (orderId) =>
      orders.find(
        (order) => String(order.id) === String(orderId)
      ) || null,
    [orders]
  );

  // ==========================================
  // CANCEL ORDER
  // ==========================================

  const cancelOrder = useCallback(
    async (orderId) => {
      const existingOrder = orders.find(
        (order) => String(order.id) === String(orderId)
      );

      if (!existingOrder) {
        return {
          success: false,
          message: "Order not found.",
        };
      }

      if (existingOrder.status !== "Confirmed") {
        return {
          success: false,
          message:
            "Only confirmed orders can be cancelled.",
        };
      }

      const updatedOrders = orders.map((order) =>
        String(order.id) === String(orderId)
          ? {
              ...order,
              status: "Cancelled",
            }
          : order
      );

      try {
        await AsyncStorage.setItem(
          ORDERS_STORAGE_KEY,
          JSON.stringify(updatedOrders)
        );

        setOrders(updatedOrders);

        return {
          success: true,
        };
      } catch (error) {
        console.error("Cancel order error:", error);

        return {
          success: false,
          message: "Unable to cancel this order.",
        };
      }
    },
    [orders]
  );

  // ==========================================
  // CLEAR ORDER HISTORY
  // ==========================================

  const clearOrders = useCallback(async () => {
    try {
      await AsyncStorage.setItem(
        ORDERS_STORAGE_KEY,
        JSON.stringify([])
      );

      setOrders([]);

      return {
        success: true,
      };
    } catch (error) {
      console.error("Clear orders error:", error);

      return {
        success: false,
        message: "Unable to clear order history.",
      };
    }
  }, []);

  // ==========================================
  // CONTEXT VALUE
  // ==========================================

  const value = {
    orders,
    loading,

    addOrder,
    getOrderById,
    cancelOrder,
    clearOrders,

    orderCount: orders.length,
  };

  return (
    <OrderContext.Provider value={value}>
      {children}
    </OrderContext.Provider>
  );
}

// ============================================
// ORDER HOOK
// ============================================

export function useOrder() {
  const context = useContext(OrderContext);

  if (!context) {
    throw new Error(
      "useOrder must be used inside OrderProvider."
    );
  }

  return context;
}
