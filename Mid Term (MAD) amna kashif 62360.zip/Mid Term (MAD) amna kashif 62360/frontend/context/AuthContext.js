import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

const AuthContext = createContext(null);

const USERS_KEY = "@luna_users";
const SESSION_KEY = "@luna_session";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore the logged-in user after app restart.
  useEffect(() => {
    let mounted = true;

    async function restoreSession() {
      try {
        const savedSession = await AsyncStorage.getItem(SESSION_KEY);

        if (savedSession) {
          const parsedUser = JSON.parse(savedSession);

          if (mounted) {
            setUser(parsedUser);
          }
        }
      } catch (error) {
        console.log("Session restore error:", error);

        try {
          await AsyncStorage.removeItem(SESSION_KEY);
        } catch (storageError) {
          console.log("Session cleanup error:", storageError);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    restoreSession();

    return () => {
      mounted = false;
    };
  }, []);

  const getUsers = useCallback(async () => {
    const storedUsers = await AsyncStorage.getItem(USERS_KEY);

    if (!storedUsers) {
      return [];
    }

    const parsedUsers = JSON.parse(storedUsers);

    return Array.isArray(parsedUsers) ? parsedUsers : [];
  }, []);

  // Create a new account.
  const signup = useCallback(
    async (name, email, password) => {
      try {
        const cleanName =
          typeof name === "string" ? name.trim() : "";

        const cleanEmail =
          typeof email === "string"
            ? email.trim().toLowerCase()
            : "";

        const cleanPassword =
          typeof password === "string" ? password : "";

        if (!cleanName || !cleanEmail || !cleanPassword) {
          return {
            success: false,
            message: "Please fill in all fields.",
          };
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(cleanEmail)) {
          return {
            success: false,
            message: "Please enter a valid email address.",
          };
        }

        if (cleanPassword.length < 6) {
          return {
            success: false,
            message: "Password must contain at least 6 characters.",
          };
        }

        const users = await getUsers();

        const existingUser = users.find(
          (item) => item.email === cleanEmail
        );

        if (existingUser) {
          return {
            success: false,
            message: "An account with this email already exists.",
          };
        }

        const newUser = {
          id: Date.now().toString(),
          name: cleanName,
          email: cleanEmail,
          password: cleanPassword,
        };

        await AsyncStorage.setItem(
          USERS_KEY,
          JSON.stringify([...users, newUser])
        );

        const sessionUser = {
          id: newUser.id,
          name: newUser.name,
          email: newUser.email,
        };

        await AsyncStorage.setItem(
          SESSION_KEY,
          JSON.stringify(sessionUser)
        );

        setUser(sessionUser);

        return {
          success: true,
          user: sessionUser,
        };
      } catch (error) {
        console.log("Signup error:", error);

        return {
          success: false,
          message: "Unable to create your account. Please try again.",
        };
      }
    },
    [getUsers]
  );

  // Sign in an existing account.
  const login = useCallback(
    async (email, password) => {
      try {
        const cleanEmail =
          typeof email === "string"
            ? email.trim().toLowerCase()
            : "";

        const cleanPassword =
          typeof password === "string" ? password : "";

        if (!cleanEmail || !cleanPassword) {
          return {
            success: false,
            message: "Please enter your email and password.",
          };
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(cleanEmail)) {
          return {
            success: false,
            message: "Please enter a valid email address.",
          };
        }

        const users = await getUsers();

        const existingUser = users.find(
          (item) =>
            item.email === cleanEmail &&
            item.password === cleanPassword
        );

        if (!existingUser) {
          return {
            success: false,
            message: "Incorrect email or password.",
          };
        }

        const sessionUser = {
          id: existingUser.id,
          name: existingUser.name,
          email: existingUser.email,
        };

        await AsyncStorage.setItem(
          SESSION_KEY,
          JSON.stringify(sessionUser)
        );

        setUser(sessionUser);

        return {
          success: true,
          user: sessionUser,
        };
      } catch (error) {
        console.log("Login error:", error);

        return {
          success: false,
          message: "Unable to login. Please try again.",
        };
      }
    },
    [getUsers]
  );

  // Log out and clear the saved session.
  const logout = useCallback(async () => {
    try {
      await AsyncStorage.removeItem(SESSION_KEY);

      setUser(null);

      return {
        success: true,
      };
    } catch (error) {
      console.log("Logout error:", error);

      return {
        success: false,
        message: "Unable to logout. Please try again.",
      };
    }
  }, []);

  const value = {
    user,
    loading,
    isAuthenticated: Boolean(user),
    signup,
    login,
    logout,
    signOut: logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error(
      "useAuth must be used inside AuthProvider."
    );
  }

  return context;
}
