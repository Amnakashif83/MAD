import React, {
  createContext,
  useContext,
  useState,
  useMemo,
  useCallback,
} from "react";

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [wishlist, setWishlist] = useState([]);
  const [isDark, setIsDark] = useState(false);

  // Add/remove a product from wishlist.
  const toggleWishlist = useCallback((product) => {
    if (!product || product.id == null) {
      return;
    }

    setWishlist((previous) => {
      const exists = previous.some(
        (item) => String(item.id) === String(product.id)
      );

      return exists
        ? previous.filter(
            (item) => String(item.id) !== String(product.id)
          )
        : [...previous, product];
    });
  }, []);

  // Check whether a product is in the wishlist.
  const isInWishlist = useCallback(
    (productId) =>
      wishlist.some(
        (item) => String(item.id) === String(productId)
      ),
    [wishlist]
  );

  const value = useMemo(
    () => ({
      user,
      setUser,
      wishlist,
      toggleWishlist,
      isInWishlist,
      isDark,
      setIsDark,
    }),
    [
      user,
      wishlist,
      toggleWishlist,
      isInWishlist,
      isDark,
    ]
  );

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);

  if (!context) {
    throw new Error(
      "useApp must be used inside an AppProvider"
    );
  }

  return context;
}
