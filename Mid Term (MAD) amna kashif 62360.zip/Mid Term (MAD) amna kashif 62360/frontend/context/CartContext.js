// ============================================
// LUNA SHOPPING APP - CART CONTEXT
// ============================================

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

import { calculateBill } from "../services/productService";

const CartContext = createContext(null);

const CART_STORAGE_KEY = "@luna_cart";

// ============================================
// CART PROVIDER
// ============================================

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);
  const [loading, setLoading] = useState(true);

  // ==========================================
  // RESTORE CART
  // ==========================================

  useEffect(() => {
    let mounted = true;

    async function loadCart() {
      try {
        const storedCart = await AsyncStorage.getItem(
          CART_STORAGE_KEY
        );

        if (storedCart && mounted) {
          const parsedCart = JSON.parse(storedCart);

          if (Array.isArray(parsedCart)) {
            setCart(parsedCart);
          }
        }
      } catch (error) {
        console.error("Cart restore error:", error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadCart();

    return () => {
      mounted = false;
    };
  }, []);

  // ==========================================
  // SAVE CART
  // ==========================================

  useEffect(() => {
    if (loading) {
      return;
    }

    AsyncStorage.setItem(
      CART_STORAGE_KEY,
      JSON.stringify(cart)
    ).catch((error) => {
      console.error("Cart save error:", error);
    });
  }, [cart, loading]);

  // ==========================================
  // ADD TO CART
  // ==========================================

  const addToCart = useCallback((product, quantity = 1) => {
    if (!product || product.id == null) {
      return false;
    }

    const productQuantity = Number(quantity);

    if (
      !Number.isFinite(productQuantity) ||
      productQuantity < 1
    ) {
      return false;
    }

    const price = Number(product.price);

    if (!Number.isFinite(price) || price < 0) {
      return false;
    }

    setCart((previousCart) => {
      const existingItem = previousCart.find(
        (item) =>
          String(item.id) === String(product.id)
      );

      if (existingItem) {
        return previousCart.map((item) =>
          String(item.id) === String(product.id)
            ? {
                ...item,
                quantity: Math.min(
                  99,
                  (Number(item.quantity) || 1) +
                    productQuantity
                ),
              }
            : item
        );
      }

      return [
        ...previousCart,
        {
          ...product,
          price,
          quantity: Math.min(99, productQuantity),
        },
      ];
    });

    return true;
  }, []);

  // ==========================================
  // REMOVE PRODUCT
  // ==========================================

  const removeFromCart = useCallback((productId) => {
    setCart((previousCart) =>
      previousCart.filter(
        (item) =>
          String(item.id) !== String(productId)
      )
    );
  }, []);

  // ==========================================
  // UPDATE QUANTITY
  // ==========================================

  const updateQuantity = useCallback(
    (productId, quantity) => {
      const nextQuantity = Number(quantity);

      if (
        !Number.isFinite(nextQuantity) ||
        nextQuantity < 1
      ) {
        return;
      }

      setCart((previousCart) =>
        previousCart.map((item) =>
          String(item.id) === String(productId)
            ? {
                ...item,
                quantity: Math.min(99, nextQuantity),
              }
            : item
        )
      );
    },
    []
  );

  // ==========================================
  // INCREASE QUANTITY
  // ==========================================

  const increaseQuantity = useCallback(
    (productId) => {
      setCart((previousCart) =>
        previousCart.map((item) =>
          String(item.id) === String(productId)
            ? {
                ...item,
                quantity: Math.min(
                  99,
                  (Number(item.quantity) || 1) + 1
                ),
              }
            : item
        )
      );
    },
    []
  );

  // ==========================================
  // DECREASE QUANTITY
  // ==========================================

  const decreaseQuantity = useCallback(
    (productId) => {
      setCart((previousCart) =>
        previousCart
          .map((item) =>
            String(item.id) === String(productId)
              ? {
                  ...item,
                  quantity:
                    (Number(item.quantity) || 1) - 1,
                }
              : item
          )
          .filter((item) => item.quantity > 0)
      );
    },
    []
  );

  // ==========================================
  // CLEAR CART
  // ==========================================

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  // ==========================================
  // BILL CALCULATION
  // ==========================================

  const bill = useMemo(() => {
    return calculateBill(cart);
  }, [cart]);

  const itemCount = useMemo(
    () =>
      cart.reduce(
        (total, item) =>
          total + (Number(item.quantity) || 0),
        0
      ),
    [cart]
  );

  // ==========================================
  // CONTEXT VALUE
  // ==========================================

  const value = {
    cart,
    loading,

    addToCart,
    removeFromCart,
    updateQuantity,
    increaseQuantity,
    decreaseQuantity,
    clearCart,

    subtotal: bill.subtotal,
    discount: bill.discount,
    total: bill.total,

    itemCount,
    cartCount: itemCount,

    calculateBill: () => calculateBill(cart),
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}

// ============================================
// CART HOOK
// ============================================

export function useCart() {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error(
      "useCart must be used inside CartProvider."
    );
  }

  return context;
}
