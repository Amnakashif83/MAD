import React, {
  createContext,
  useContext,
  useEffect,
  useState,
} from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  LIGHT_COLORS,
  DARK_COLORS,
} from "../theme/colors";

const ThemeContext = createContext(null);

const THEME_KEY = "@luna_dark_mode";

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    async function loadTheme() {
      try {
        const savedTheme = await AsyncStorage.getItem(
          THEME_KEY
        );

        if (savedTheme !== null && mounted) {
          setIsDark(savedTheme === "true");
        }
      } catch (error) {
        console.log("Load theme error:", error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadTheme();

    return () => {
      mounted = false;
    };
  }, []);

  const toggleTheme = async () => {
    const nextTheme = !isDark;

    setIsDark(nextTheme);

    try {
      await AsyncStorage.setItem(
        THEME_KEY,
        String(nextTheme)
      );
    } catch (error) {
      console.log("Save theme error:", error);
    }
  };

  const colors = isDark
    ? DARK_COLORS
    : LIGHT_COLORS;

  return (
    <ThemeContext.Provider
      value={{
        isDark,
        colors,
        loading,
        toggleTheme,
        setIsDark,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);

  if (!context) {
    throw new Error(
      "useTheme must be used inside ThemeProvider."
    );
  }

  return context;
}
