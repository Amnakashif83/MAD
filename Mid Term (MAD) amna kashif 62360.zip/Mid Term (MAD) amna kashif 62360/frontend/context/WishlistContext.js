
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";

import AsyncStorage from "@react-native-async-storage/async-storage";

const WishlistContext = createContext(null);

const WISHLIST_KEY = "@luna_wishlist";

// ============================================
// GET PRODUCT ID
// ============================================

function getProductId(product) {
  if (!product) {
    return "";
  }

  return String(
    product.id ??
    product._id ??
    product.title ??
    product.name ??
    ""
  );
}

// ============================================
// WISHLIST PROVIDER
// ============================================

export function WishlistProvider({ children }) {
  const [wishlist, setWishlist] = useState([]);
  const [loading, setLoading] = useState(true);

  // ==========================================
  // LOAD SAVED WISHLIST
  // ==========================================

  useEffect(() => {
    let mounted = true;

    async function loadWishlist() {
      try {
        const saved = await AsyncStorage.getItem(
          WISHLIST_KEY
        );

        if (saved) {
          const parsed = JSON.parse(saved);

          if (mounted && Array.isArray(parsed)) {
            setWishlist(parsed);
          }
        }
      } catch (error) {
        console.log(
          "Wishlist loading error:",
          error
        );
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadWishlist();

    return () => {
      mounted = false;
    };
  }, []);

  // ==========================================
  // SAVE WISHLIST
  // ==========================================

  useEffect(() => {
    if (loading) {
      return;
    }

    async function saveWishlist() {
      try {
        await AsyncStorage.setItem(
          WISHLIST_KEY,
          JSON.stringify(wishlist)
        );
      } catch (error) {
        console.log(
          "Wishlist saving error:",
          error
        );
      }
    }

    saveWishlist();
  }, [wishlist, loading]);

  // ==========================================
  // TOGGLE WISHLIST
  // ==========================================

  const toggleWishlist = useCallback((product) => {
    if (!product) {
      return;
    }

    const productId = getProductId(product);

    if (!productId) {
      console.log(
        "Cannot add product without an ID."
      );

      return;
    }

    setWishlist((previousWishlist) => {
      const exists = previousWishlist.some(
        (item) =>
          getProductId(item) === productId
      );

      if (exists) {
        return previousWishlist.filter(
          (item) =>
            getProductId(item) !== productId
        );
      }

      return [
        ...previousWishlist,
        product,
      ];
    });
  }, []);

  // ==========================================
  // ADD TO WISHLIST
  // ==========================================

  const addToWishlist = useCallback((product) => {
    if (!product) {
      return;
    }

    const productId = getProductId(product);

    if (!productId) {
      return;
    }

    setWishlist((previousWishlist) => {
      const exists = previousWishlist.some(
        (item) =>
          getProductId(item) === productId
      );

      if (exists) {
        return previousWishlist;
      }

      return [
        ...previousWishlist,
        product,
      ];
    });
  }, []);

  // ==========================================
  // REMOVE FROM WISHLIST
  // ==========================================

  const removeFromWishlist = useCallback(
    (productId) => {
      const id = String(productId);

      setWishlist((previousWishlist) =>
        previousWishlist.filter(
          (item) =>
            getProductId(item) !== id
        )
      );
    },
    []
  );

  // ==========================================
  // CHECK WISHLIST
  // ==========================================

  const isInWishlist = useCallback(
    (productId) => {
      const id = String(productId);

      return wishlist.some(
        (item) =>
          getProductId(item) === id
      );
    },
    [wishlist]
  );

  // ==========================================
  // CLEAR WISHLIST
  // ==========================================

  const clearWishlist = useCallback(() => {
    setWishlist([]);
  }, []);

  // ==========================================
  // CONTEXT VALUE
  // ==========================================

  const value = {
    wishlist,
    loading,

    toggleWishlist,
    addToWishlist,
    removeFromWishlist,

    isInWishlist,

    clearWishlist,

    wishlistCount: wishlist.length,
  };

  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  );
}

// ============================================
// USE WISHLIST
// ============================================

export function useWishlist() {
  const context = useContext(
    WishlistContext
  );

  if (!context) {
    throw new Error(
      "useWishlist must be used inside WishlistProvider."
    );
  }

  return context;
}
