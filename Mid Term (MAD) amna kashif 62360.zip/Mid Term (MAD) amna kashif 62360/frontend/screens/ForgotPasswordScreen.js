import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "../context/ThemeContext";

export default function ForgotPasswordScreen({ navigation }) {
  const { colors, isDark } = useTheme();

  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleReset = () => {
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail) {
      Alert.alert("Email required", "Please enter your email address.");
      return;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(cleanEmail)) {
      Alert.alert("Invalid email", "Please enter a valid email address.");
      return;
    }

    // Demo mode: this app does not have a password-reset backend.
    setSubmitted(true);
  };

  return (
    <KeyboardAvoidingView
      style={[styles.screen, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <StatusBar
        barStyle={isDark ? "light-content" : "dark-content"}
        backgroundColor={colors.background}
      />

      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[
            styles.backButton,
            { backgroundColor: colors.card, borderColor: colors.border },
          ]}
        >
          <Ionicons name="arrow-back" size={22} color={colors.text} />
        </TouchableOpacity>

        <View
          style={[
            styles.iconCircle,
            { backgroundColor: colors.primary + "20" },
          ]}
        >
          <Ionicons
            name={submitted ? "mail-open-outline" : "lock-closed-outline"}
            size={48}
            color={colors.primary}
          />
        </View>

        <Text style={[styles.brand, { color: colors.primary }]}>
          L U N A
        </Text>

        <Text style={[styles.title, { color: colors.text }]}>
          {submitted ? "Check your email" : "Forgot password?"}
        </Text>

        <Text style={[styles.description, { color: colors.muted }]}>
          {submitted
            ? "If an account exists for this email, you can use the password-reset process configured by your application administrator."
            : "Enter your registered email address to begin the password recovery process."}
        </Text>

        {!submitted ? (
          <>
            <Text style={[styles.label, { color: colors.text }]}>
              Email address
            </Text>

            <View
              style={[
                styles.inputContainer,
                {
                  backgroundColor: colors.inputBackground,
                  borderColor: colors.border,
                },
              ]}
            >
              <Ionicons
                name="mail-outline"
                size={20}
                color={colors.muted}
              />

              <TextInput
                style={[styles.input, { color: colors.text }]}
                placeholder="you@example.com"
                placeholderTextColor={colors.placeholder}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                value={email}
                onChangeText={setEmail}
                accessibilityLabel="Email address"
              />
            </View>

            <TouchableOpacity
              style={[
                styles.primaryButton,
                { backgroundColor: colors.primary },
              ]}
              onPress={handleReset}
              activeOpacity={0.85}
            >
              <Text style={styles.primaryButtonText}>
                Continue
              </Text>

              <Ionicons
                name="arrow-forward"
                size={19}
                color="#FFFFFF"
              />
            </TouchableOpacity>
          </>
        ) : (
          <View
            style={[
              styles.notice,
              { backgroundColor: colors.card, borderColor: colors.border },
            ]}
          >
            <Ionicons
              name="information-circle-outline"
              size={23}
              color={colors.primary}
            />

            <Text style={[styles.noticeText, { color: colors.text }]}>
              Password reset is not connected to an email service yet. This
              screen demonstrates the recovery flow but does not change your
              password.
            </Text>
          </View>
        )}

        <TouchableOpacity
          style={styles.loginLink}
          onPress={() => navigation.navigate("Login")}
        >
          <Text style={[styles.loginLinkText, { color: colors.primary }]}>
            Back to Login
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 25,
  },
  backButton: {
    width: 46,
    height: 46,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    marginBottom: 38,
  },
  iconCircle: {
    width: 100,
    height: 100,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
    marginBottom: 25,
  },
  brand: {
    fontSize: 16,
    fontWeight: "900",
    textAlign: "center",
    marginBottom: 15,
  },
  title: {
    fontSize: 28,
    fontWeight: "900",
    textAlign: "center",
    marginBottom: 12,
  },
  description: {
    fontSize: 13,
    lineHeight: 21,
    textAlign: "center",
    marginBottom: 30,
  },
  label: {
    fontSize: 13,
    fontWeight: "800",
    marginBottom: 9,
  },
  inputContainer: {
    minHeight: 54,
    borderWidth: 1,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 15,
    marginBottom: 20,
  },
  input: {
    flex: 1,
    fontSize: 14,
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  primaryButton: {
    height: 54,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "900",
  },
  notice: {
    borderWidth: 1,
    borderRadius: 15,
    padding: 15,
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
  },
  noticeText: {
    flex: 1,
    fontSize: 12,
    lineHeight: 19,
  },
  loginLink: {
    alignItems: "center",
    marginTop: 25,
    padding: 10,
  },
  loginLinkText: {
    fontSize: 13,
    fontWeight: "900",
  },
});
