// ============================================
// LUNA SHOPPING APP
// File: frontend/screens/ProductsScreen.js
// ============================================

import React, {
  useCallback,
  useEffect,
  useState,
} from "react";

import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  StatusBar,
  ActivityIndicator,
  Alert,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import ProductCard from "../components/ProductCard";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/WishlistContext";

import { getProducts } from "../data/api";
import { CATEGORIES } from "../data/categories";

// ============================================
// ALLOWED CATEGORIES
// ============================================

const ALLOWED_CATEGORIES = [
  "makeup",
  "men",
  "women",
  "accessories",
];

// ============================================
// NORMALIZE CATEGORY
// ============================================

function normalizeCategory(category) {
  return String(category || "")
    .trim()
    .toLowerCase();
}

// ============================================
// PRODUCTS SCREEN
// ============================================

export default function ProductsScreen({
  navigation,
  route,
}) {
  const { colors, isDark } = useTheme();

  const { user } = useAuth();

  const { addToCart } = useCart();

  const {
    wishlist = [],
    toggleWishlist,
  } = useWishlist();

  const selectedCategory = route?.params?.category;

  const selectedCategoryId = route?.params?.categoryId;

  const [products, setProducts] = useState([]);

  const [loading, setLoading] = useState(true);

  const [activeCategory, setActiveCategory] = useState(
    selectedCategory || "All"
  );

  // ==========================================
  // LOAD PRODUCTS
  // ==========================================

  const loadProducts = useCallback(async () => {
    try {
      setLoading(true);

      const result = await getProducts();

      const allProducts = Array.isArray(result)
        ? result
        : [];

      // Remove products outside the four allowed
      // categories.

      const filteredProducts = allProducts.filter(
        (product) => {
          const category = normalizeCategory(
            product.category
          );

          const categoryId = normalizeCategory(
            product.categoryId
          );

          return (
            ALLOWED_CATEGORIES.includes(category) ||
            ALLOWED_CATEGORIES.includes(categoryId)
          );
        }
      );

      setProducts(filteredProducts);
    } catch (error) {
      console.log("Products loading error:", error);

      setProducts([]);

      Alert.alert(
        "Unable to Load Products",
        "Please check your connection and try again."
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  // ==========================================
  // HANDLE SELECTED CATEGORY
  // ==========================================

  useEffect(() => {
    if (selectedCategory) {
      setActiveCategory(selectedCategory);
      return;
    }

    if (selectedCategoryId) {
      const matchingCategory = CATEGORIES.find(
        (category) =>
          normalizeCategory(category.id) ===
          normalizeCategory(selectedCategoryId)
      );

      setActiveCategory(
        matchingCategory?.name || "All"
      );

      return;
    }

    setActiveCategory("All");
  }, [selectedCategory, selectedCategoryId]);

  // ==========================================
  // FILTER VISIBLE PRODUCTS
  // ==========================================

  const visibleProducts =
    normalizeCategory(activeCategory) === "all"
      ? products
      : products.filter((product) => {
          const category = normalizeCategory(
            product.category
          );

          const categoryId = normalizeCategory(
            product.categoryId
          );

          const selectedName = normalizeCategory(
            activeCategory
          );

          const selectedCategoryObject =
            CATEGORIES.find(
              (item) =>
                normalizeCategory(item.name) ===
                  selectedName ||
                normalizeCategory(item.id) ===
                  selectedName
            );

          const selectedId = normalizeCategory(
            selectedCategoryObject?.id
          );

          return (
            category === selectedName ||
            (
              selectedId !== "" &&
              (
                category === selectedId ||
                categoryId === selectedId
              )
            )
          );
        });

  // ==========================================
  // CHECK WISHLIST
  // ==========================================

  function isFavourite(product) {
    const productId = String(
      product.id ??
        product._id ??
        product.title ??
        product.name
    );

    return wishlist.some((item) => {
      const wishlistId = String(
        item.id ??
          item._id ??
          item.title ??
          item.name
      );

      return wishlistId === productId;
    });
  }

  // ==========================================
  // ADD TO CART
  // LOGIN REQUIRED
  // ==========================================

  function handleAddToCart(product) {
    if (!user) {
      Alert.alert(
        "Login Required",
        "Please login or create an account before adding products to your cart.",
        [
          {
            text: "Cancel",
            style: "cancel",
          },

          {
            text: "Login",
            onPress: () =>
              navigation.navigate("Login", {
                returnTo: "Products",
                pendingProduct: product,
              }),
          },

          {
            text: "Sign Up",
            onPress: () =>
              navigation.navigate("Signup", {
                returnTo: "Products",
                pendingProduct: product,
              }),
          },
        ]
      );

      return;
    }

    addToCart({
      ...product,
      quantity: 1,
    });

    Alert.alert(
      "Added to Cart 💗",
      `${
        product.title ||
        product.name ||
        "Product"
      } added to your cart.`
    );
  }

  // ==========================================
  // RENDER PRODUCT
  // ==========================================

  function renderProduct({ item }) {
    return (
      <View style={styles.productWrapper}>
        <ProductCard
          product={item}
          onPress={() =>
            navigation.navigate("Details", {
              product: item,
            })
          }
          onAdd={() => handleAddToCart(item)}
          isFavourite={isFavourite(item)}
          onWishlist={() => toggleWishlist(item)}
        />
      </View>
    );
  }

  // ==========================================
  // RENDER SCREEN
  // ==========================================

  return (
    <View
      style={[
        styles.screen,
        {
          backgroundColor: colors.background,
        },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={
          isDark
            ? "light-content"
            : "dark-content"
        }
      />

      {/* HEADER */}

      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[
            styles.backButton,
            {
              backgroundColor: colors.card,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Go back"
        >
          <Ionicons
            name="arrow-back"
            size={22}
            color={colors.primary}
          />
        </TouchableOpacity>

        <View style={styles.headerTextContainer}>
          <Text
            style={[
              styles.title,
              {
                color: colors.text,
              },
            ]}
          >
            Our Collection
          </Text>

          <Text
            style={[
              styles.subtitle,
              {
                color: colors.muted,
              },
            ]}
          >
            Find something you love
          </Text>
        </View>

        <TouchableOpacity
          onPress={() =>
            navigation.navigate("Wishlist")
          }
          style={[
            styles.backButton,
            {
              backgroundColor: colors.card,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Open wishlist"
        >
          <Ionicons
            name="heart-outline"
            size={22}
            color={colors.primary}
          />
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() =>
            navigation.navigate("Cart")
          }
          style={[
            styles.backButton,
            {
              backgroundColor: colors.card,
              marginLeft: 8,
            },
          ]}
          accessibilityRole="button"
          accessibilityLabel="Open cart"
        >
          <Ionicons
            name="bag-outline"
            size={22}
            color={colors.primary}
          />
        </TouchableOpacity>
      </View>

      {/* CATEGORY FILTERS */}

      <View style={styles.categorySection}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={[
            {
              id: "all",
              name: "All",
            },
            ...CATEGORIES,
          ]}
          keyExtractor={(item) =>
            String(item.id)
          }
          renderItem={({ item }) => {
            const selected =
              normalizeCategory(activeCategory) ===
              normalizeCategory(item.name);

            return (
              <TouchableOpacity
                onPress={() =>
                  setActiveCategory(item.name)
                }
                style={[
                  styles.filterButton,
                  {
                    backgroundColor: selected
                      ? colors.primary
                      : colors.card,
                    borderColor: colors.border,
                  },
                ]}
                accessibilityRole="button"
                accessibilityState={{
                  selected,
                }}
              >
                <Text
                  style={[
                    styles.filterText,
                    {
                      color: selected
                        ? "#FFFFFF"
                        : colors.text,
                    },
                  ]}
                >
                  {item.name}
                </Text>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      {/* PRODUCTS */}

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator
            size="large"
            color={colors.primary}
          />

          <Text
            style={[
              styles.loadingText,
              {
                color: colors.muted,
              },
            ]}
          >
            Loading products...
          </Text>
        </View>
      ) : (
        <>
          {/* RESULTS HEADER */}

          <View style={styles.resultsHeader}>
            <Text
              style={[
                styles.resultsTitle,
                {
                  color: colors.text,
                },
              ]}
            >
              {activeCategory === "All"
                ? "All Products"
                : activeCategory}
            </Text>

            <Text
              style={[
                styles.resultsCount,
                {
                  color: colors.muted,
                },
              ]}
            >
              {visibleProducts.length} items
            </Text>
          </View>

          {/* EMPTY STATE */}

          {visibleProducts.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons
                name="file-tray-outline"
                size={48}
                color={colors.primary}
              />

              <Text
                style={[
                  styles.emptyTitle,
                  {
                    color: colors.text,
                  },
                ]}
              >
                No products found
              </Text>

              <Text
                style={[
                  styles.emptyDescription,
                  {
                    color: colors.muted,
                  },
                ]}
              >
                There are no products in this category yet.
              </Text>

              <TouchableOpacity
                style={[
                  styles.retryButton,
                  {
                    backgroundColor: colors.primary,
                  },
                ]}
                onPress={loadProducts}
              >
                <Text style={styles.retryText}>
                  Reload Products
                </Text>
              </TouchableOpacity>
            </View>
          ) : (
            <FlatList
              key="products-grid"
              data={visibleProducts}
              renderItem={renderProduct}
              keyExtractor={(item, index) =>
                String(
                  item.id ??
                    item._id ??
                    index
                )
              }
              numColumns={2}
              columnWrapperStyle={
                styles.productRow
              }
              contentContainerStyle={
                styles.productList
              }
              showsVerticalScrollIndicator={false}
              refreshing={loading}
              onRefresh={loadProducts}
            />
          )}
        </>
      )}
    </View>
  );
}

// ============================================
// STYLES
// ============================================

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    paddingTop: 10,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 20,
  },

  backButton: {
    width: 43,
    height: 43,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTextContainer: {
    flex: 1,
    marginHorizontal: 10,
  },

  title: {
    fontSize: 20,
    fontWeight: "900",
  },

  subtitle: {
    fontSize: 11,
    marginTop: 4,
  },

  categorySection: {
    paddingLeft: 18,
    marginBottom: 18,
  },

  filterButton: {
    paddingHorizontal: 17,
    paddingVertical: 11,
    borderRadius: 13,
    borderWidth: 1,
    marginRight: 9,
  },

  filterText: {
    fontSize: 12,
    fontWeight: "800",
  },

  resultsHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 18,
    marginBottom: 15,
  },

  resultsTitle: {
    fontSize: 17,
    fontWeight: "900",
  },

  resultsCount: {
    fontSize: 11,
  },

  productList: {
    paddingHorizontal: 18,
    paddingBottom: 30,
  },

  productRow: {
    justifyContent: "space-between",
  },

  productWrapper: {
    width: "49%",
  },

  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  loadingText: {
    marginTop: 12,
    fontSize: 12,
  },

  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 25,
  },

  emptyTitle: {
    fontSize: 17,
    fontWeight: "900",
    marginTop: 15,
  },

  emptyDescription: {
    textAlign: "center",
    fontSize: 12,
    marginTop: 8,
    lineHeight: 19,
  },

  retryButton: {
    marginTop: 17,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },

  retryText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "800",
  },
});
