import React from 'react';

import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
  ScrollView,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import { useTheme } from '../context/ThemeContext';

export default function WelcomeScreen({ navigation }) {
  const { colors, isDark } = useTheme();

  // ========================================
  // NAVIGATION FUNCTIONS
  // ========================================

  function openGuestMode() {
    navigation.replace('Main');
  }

  function openSignup() {
    navigation.navigate('Signup');
  }

  function openLogin() {
    navigation.navigate('Login');
  }

  function openSettings() {
    navigation.navigate('Settings');
  }

  // ========================================
  // SCREEN UI
  // ========================================

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.background,
        },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={
          isDark ? 'light-content' : 'dark-content'
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.scrollContent}
      >
        {/* ================================== */}
        {/* HEADER */}
        {/* ================================== */}

        <View style={styles.top}>
          <View>
            <Text
              style={[
                styles.brand,
                {
                  color: colors.primary,
                },
              ]}
            >
              LUNA ♡
            </Text>

            <Text
              style={[
                styles.brandSubtitle,
                {
                  color: colors.muted,
                },
              ]}
            >
              YOUR STYLE, YOUR STORY
            </Text>
          </View>

          <TouchableOpacity
            onPress={openSettings}
            activeOpacity={0.75}
            style={[
              styles.settingsButton,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
            accessibilityRole="button"
            accessibilityLabel="Open settings"
          >
            <Ionicons
              name="settings-outline"
              size={22}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* ================================== */}
        {/* HERO IMAGE */}
        {/* ================================== */}

        <View
          style={[
            styles.imageContainer,
            {
              backgroundColor: colors.secondary,
            },
          ]}
        >
          <Image
            source={{
              uri: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1000&q=85',
            }}
            style={styles.image}
            resizeMode="cover"
          />

          {/* Image overlay */}

          <View
            style={[
              styles.imageOverlay,
              {
                backgroundColor: colors.overlay,
              },
            ]}
          />

          {/* Collection badge */}

          <View style={styles.imageBadge}>
            <Ionicons
              name="sparkles"
              size={15}
              color="#705582"
            />

            <Text style={styles.imageBadgeText}>
              NEW COLLECTION
            </Text>
          </View>

          {/* Image caption */}

          <View style={styles.imageCaption}>
            <Text style={styles.imageCaptionTitle}>
              Elegance in{'\n'}Every Detail.
            </Text>

            <Text style={styles.imageCaptionSubtitle}>
              Discover your next favourite look.
            </Text>
          </View>

          {/* Heart icon */}

          <View style={styles.imageHeart}>
            <Ionicons
              name="heart"
              size={19}
              color="#E85D86"
            />
          </View>
        </View>

        {/* ================================== */}
        {/* INTRODUCTION */}
        {/* ================================== */}

        <View style={styles.intro}>
          <Text
            style={[
              styles.eyebrow,
              {
                color: colors.primary,
              },
            ]}
          >
            WELCOME TO LUNA
          </Text>

          <Text
            style={[
              styles.title,
              {
                color: colors.text,
              },
            ]}
          >
            Find Your{' '}

            <Text
              style={[
                styles.titleHighlight,
                {
                  color: colors.primary,
                },
              ]}
            >
              Everyday
            </Text>

            {'\n'}Magic.
          </Text>

          <Text
            style={[
              styles.subtitle,
              {
                color: colors.muted,
              },
            ]}
          >
            Discover beautiful fashion, accessories and
            beauty essentials, thoughtfully curated just
            for you.
          </Text>
        </View>

        {/* ================================== */}
        {/* CREATE ACCOUNT BUTTON */}
        {/* ================================== */}

        <TouchableOpacity
          style={[
            styles.button,
            {
              backgroundColor: colors.primary,
            },
          ]}
          onPress={openSignup}
          activeOpacity={0.85}
          accessibilityRole="button"
          accessibilityLabel="Create an account"
        >
          <Ionicons
            name="person-add-outline"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.buttonText}>
            Create an Account
          </Text>

          <Ionicons
            name="arrow-forward"
            size={19}
            color="#FFFFFF"
          />
        </TouchableOpacity>

        {/* ================================== */}
        {/* LOGIN BUTTON */}
        {/* ================================== */}

        <TouchableOpacity
          style={[
            styles.loginButton,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
          onPress={openLogin}
          activeOpacity={0.8}
          accessibilityRole="button"
          accessibilityLabel="Log in to your account"
        >
          <Ionicons
            name="log-in-outline"
            size={19}
            color={colors.primary}
          />

          <Text
            style={[
              styles.loginText,
              {
                color: colors.text,
              },
            ]}
          >
            I Already Have an Account
          </Text>
        </TouchableOpacity>

        {/* ================================== */}
        {/* DIVIDER */}
        {/* ================================== */}

        <View style={styles.dividerContainer}>
          <View
            style={[
              styles.divider,
              {
                backgroundColor: colors.border,
              },
            ]}
          />

          <Text
            style={[
              styles.orText,
              {
                color: colors.muted,
              },
            ]}
          >
            OR
          </Text>

          <View
            style={[
              styles.divider,
              {
                backgroundColor: colors.border,
              },
            ]}
          />
        </View>

        {/* ================================== */}
        {/* GUEST MODE */}
        {/* ================================== */}

        <TouchableOpacity
          style={styles.guestButton}
          onPress={openGuestMode}
          activeOpacity={0.7}
          accessibilityRole="button"
          accessibilityLabel="Explore as guest"
        >
          <Text
            style={[
              styles.guestText,
              {
                color: colors.primary,
              },
            ]}
          >
            Explore as Guest
          </Text>

          <Ionicons
            name="arrow-forward-circle-outline"
            size={20}
            color={colors.primary}
          />
        </TouchableOpacity>

        {/* ================================== */}
        {/* FOOTER */}
        {/* ================================== */}

        <View style={styles.footer}>
          <Ionicons
            name="heart"
            size={13}
            color={colors.primary}
          />

          <Text
            style={[
              styles.footerText,
              {
                color: colors.muted,
              },
            ]}
          >
            Discover • Love • Shop
          </Text>
        </View>

        <Text
          style={[
            styles.version,
            {
              color: colors.muted,
            },
          ]}
        >
          Made with love at LUNA ♡
        </Text>
      </ScrollView>
    </View>
  );
}

// ========================================
// STYLES
// ========================================

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 22,
    paddingTop: 48,
    paddingBottom: 25,
  },

  // HEADER

  top: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 23,
  },

  brand: {
    fontSize: 25,
    fontWeight: '900',
    letterSpacing: 3,
  },

  brandSubtitle: {
    fontSize: 8,
    fontWeight: '800',
    letterSpacing: 2,
    marginTop: 5,
  },

  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 15,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // HERO IMAGE

  imageContainer: {
    height: 290,
    borderRadius: 25,
    overflow: 'hidden',
    position: 'relative',
  },

  image: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },

  imageOverlay: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.65,
  },

  imageBadge: {
    position: 'absolute',
    top: 15,
    left: 15,
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    paddingHorizontal: 11,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },

  imageBadgeText: {
    color: '#705582',
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 1,
  },

  imageCaption: {
    position: 'absolute',
    left: 19,
    bottom: 22,
    right: 45,
  },

  imageCaptionTitle: {
    color: '#FFFFFF',
    fontSize: 29,
    lineHeight: 35,
    fontWeight: '900',
  },

  imageCaptionSubtitle: {
    color: '#FFFFFF',
    fontSize: 11,
    marginTop: 8,
    fontWeight: '600',
  },

  imageHeart: {
    position: 'absolute',
    bottom: 19,
    right: 17,
    width: 35,
    height: 35,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  // INTRODUCTION

  intro: {
    marginTop: 26,
  },

  eyebrow: {
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 2,
  },

  title: {
    fontSize: 33,
    lineHeight: 41,
    fontWeight: '900',
    marginTop: 9,
  },

  titleHighlight: {
    fontWeight: '900',
  },

  subtitle: {
    fontSize: 12,
    lineHeight: 21,
    marginTop: 11,
  },

  // CREATE ACCOUNT BUTTON

  button: {
    minHeight: 54,
    borderRadius: 16,
    paddingHorizontal: 17,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
    marginTop: 23,
  },

  buttonText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '900',
    flex: 1,
    textAlign: 'center',
  },

  // LOGIN BUTTON

  loginButton: {
    minHeight: 52,
    borderWidth: 1,
    borderRadius: 16,
    paddingHorizontal: 15,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 9,
    marginTop: 12,
  },

  loginText: {
    fontSize: 12,
    fontWeight: '800',
  },

  // DIVIDER

  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 13,
    marginTop: 19,
  },

  divider: {
    flex: 1,
    height: 1,
  },

  orText: {
    fontSize: 10,
    fontWeight: '800',
  },

  // GUEST BUTTON

  guestButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 13,
  },

  guestText: {
    fontSize: 12,
    fontWeight: '900',
  },

  // FOOTER

  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 7,
    marginTop: 9,
  },

  footerText: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.5,
  },

  version: {
    fontSize: 10,
    textAlign: 'center',
    marginTop: 8,
  },
});
