import React, { useState } from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  StatusBar,
  ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useCart } from "../context/CartContext";
import { useOrder } from "../context/OrderContext";

import { calculateBill } from "../services/productService";

export default function CheckoutScreen({ navigation }) {
  const { colors, isDark } = useTheme();

  const {
    cart = [],
    clearCart,
  } = useCart();

  const { addOrder } = useOrder();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [placingOrder, setPlacingOrder] = useState(false);

  const bill = calculateBill(cart);

  const subtotal = Number(bill.subtotal) || 0;
  const discount = Number(bill.discount) || 0;
  const total = Number(bill.total) || 0;

  const formatPrice = (amount) =>
    `Rs. ${Number(amount).toLocaleString("en-PK", {
      maximumFractionDigits: 2,
    })}`;

  async function handlePlaceOrder() {
    if (placingOrder) {
      return;
    }

    if (!cart.length) {
      Alert.alert(
        "Your cart is empty",
        "Please add products before placing an order."
      );
      return;
    }

    if (!name.trim() || !phone.trim() || !address.trim()) {
      Alert.alert(
        "Missing Information",
        "Please enter your name, phone number and delivery address."
      );
      return;
    }

    if (phone.trim().length < 10) {
      Alert.alert(
        "Invalid Phone Number",
        "Please enter a valid phone number."
      );
      return;
    }

    setPlacingOrder(true);

    try {
      const order = {
        id: `LUNA-${Date.now()}`,

        items: cart.map((item) => ({
          ...item,
          quantity: Number(item.quantity) || 1,
        })),

        subtotal,
        discount,
        total,

        customer: {
          name: name.trim(),
          phone: phone.trim(),
          address: address.trim(),
        },

        paymentMethod,

        status: "Placed",

        createdAt: new Date().toISOString(),
      };

      const result = await addOrder(order);

      // If addOrder explicitly reports failure, preserve the cart.
      if (result && result.success === false) {
        throw new Error(
          result.message || "Unable to save your order."
        );
      }

      // Clear cart only after the order has been saved.
      await clearCart();

      navigation.replace("OrderSuccess", {
        order,
      });
    } catch (error) {
      console.log("Checkout error:", error);

      Alert.alert(
        "Order Failed",
        error.message ||
          "Your order could not be placed. Please try again."
      );
    } finally {
      setPlacingOrder(false);
    }
  }

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.card,
            borderBottomColor: colors.border,
          },
        ]}
      >
        <TouchableOpacity
          style={[
            styles.backButton,
            { backgroundColor: colors.background },
          ]}
          onPress={() => navigation.goBack()}
        >
          <Ionicons
            name="arrow-back"
            size={22}
            color={colors.text}
          />
        </TouchableOpacity>

        <Text
          style={[
            styles.headerTitle,
            { color: colors.text },
          ]}
        >
          Checkout
        </Text>

        <Ionicons
          name="shield-checkmark-outline"
          size={23}
          color={colors.primary}
        />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
        {/* Delivery details */}

        <View
          style={[
            styles.section,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.sectionHeading}>
            <Ionicons
              name="location-outline"
              size={22}
              color={colors.primary}
            />

            <Text
              style={[
                styles.sectionTitle,
                { color: colors.text },
              ]}
            >
              Delivery Details
            </Text>
          </View>

          <Text style={[styles.label, { color: colors.text }]}>
            Full Name
          </Text>

          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.inputBackground,
                color: colors.text,
                borderColor: colors.border,
              },
            ]}
            placeholder="Enter your full name"
            placeholderTextColor={colors.placeholder}
            value={name}
            onChangeText={setName}
            autoCapitalize="words"
          />

          <Text style={[styles.label, { color: colors.text }]}>
            Phone Number
          </Text>

          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.inputBackground,
                color: colors.text,
                borderColor: colors.border,
              },
            ]}
            placeholder="03XXXXXXXXX"
            placeholderTextColor={colors.placeholder}
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
          />

          <Text style={[styles.label, { color: colors.text }]}>
            Delivery Address
          </Text>

          <TextInput
            style={[
              styles.input,
              styles.addressInput,
              {
                backgroundColor: colors.inputBackground,
                color: colors.text,
                borderColor: colors.border,
              },
            ]}
            placeholder="House, street, city"
            placeholderTextColor={colors.placeholder}
            value={address}
            onChangeText={setAddress}
            multiline
            textAlignVertical="top"
          />
        </View>

        {/* Payment method */}

        <View
          style={[
            styles.section,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.sectionHeading}>
            <Ionicons
              name="card-outline"
              size={22}
              color={colors.primary}
            />

            <Text
              style={[
                styles.sectionTitle,
                { color: colors.text },
              ]}
            >
              Payment Method
            </Text>
          </View>

          <TouchableOpacity
            style={[
              styles.paymentOption,
              {
                backgroundColor:
                  paymentMethod === "COD"
                    ? colors.background
                    : colors.card,

                borderColor:
                  paymentMethod === "COD"
                    ? colors.primary
                    : colors.border,
              },
            ]}
            onPress={() => setPaymentMethod("COD")}
          >
            <Ionicons
              name="cash-outline"
              size={23}
              color={colors.primary}
            />

            <View style={styles.paymentTextContainer}>
              <Text
                style={[
                  styles.paymentTitle,
                  { color: colors.text },
                ]}
              >
                Cash on Delivery
              </Text>

              <Text
                style={[
                  styles.paymentSubtitle,
                  { color: colors.muted },
                ]}
              >
                Pay when your order arrives
              </Text>
            </View>

            <Ionicons
              name={
                paymentMethod === "COD"
                  ? "radio-button-on"
                  : "radio-button-off"
              }
              size={22}
              color={colors.primary}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.paymentOption,
              {
                backgroundColor:
                  paymentMethod === "Bank Transfer"
                    ? colors.background
                    : colors.card,

                borderColor:
                  paymentMethod === "Bank Transfer"
                    ? colors.primary
                    : colors.border,
              },
            ]}
            onPress={() =>
              setPaymentMethod("Bank Transfer")
            }
          >
            <Ionicons
              name="business-outline"
              size={23}
              color={colors.primary}
            />

            <View style={styles.paymentTextContainer}>
              <Text
                style={[
                  styles.paymentTitle,
                  { color: colors.text },
                ]}
              >
                Bank Transfer
              </Text>

              <Text
                style={[
                  styles.paymentSubtitle,
                  { color: colors.muted },
                ]}
              >
                Demo selection only
              </Text>
            </View>

            <Ionicons
              name={
                paymentMethod === "Bank Transfer"
                  ? "radio-button-on"
                  : "radio-button-off"
              }
              size={22}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* Order summary */}

        <View
          style={[
            styles.section,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <View style={styles.sectionHeading}>
            <Ionicons
              name="receipt-outline"
              size={22}
              color={colors.primary}
            />

            <Text
              style={[
                styles.sectionTitle,
                { color: colors.text },
              ]}
            >
              Order Summary
            </Text>
          </View>

          {cart.length === 0 ? (
            <Text
              style={[
                styles.emptyText,
                { color: colors.muted },
              ]}
            >
              Your cart is empty.
            </Text>
          ) : (
            cart.map((item, index) => {
              const quantity = Number(item.quantity) || 1;
              const price = Number(item.price) || 0;

              return (
                <View
                  key={String(item.id ?? index)}
                  style={styles.productRow}
                >
                  <View style={styles.productInfo}>
                    <Text
                      numberOfLines={2}
                      style={[
                        styles.productName,
                        { color: colors.text },
                      ]}
                    >
                      {item.title ||
                        item.name ||
                        "LUNA Product"}
                    </Text>

                    <Text
                      style={[
                        styles.productQuantity,
                        { color: colors.muted },
                      ]}
                    >
                      Quantity: {quantity}
                    </Text>
                  </View>

                  <Text
                    style={[
                      styles.productPrice,
                      { color: colors.text },
                    ]}
                  >
                    {formatPrice(price * quantity)}
                  </Text>
                </View>
              );
            })
          )}

          <View
            style={[
              styles.divider,
              { backgroundColor: colors.border },
            ]}
          />

          <View style={styles.billRow}>
            <Text style={[styles.billLabel, { color: colors.muted }]}>
              Subtotal
            </Text>

            <Text style={[styles.billValue, { color: colors.text }]}>
              {formatPrice(subtotal)}
            </Text>
          </View>

          <View style={styles.billRow}>
            <Text style={[styles.billLabel, { color: colors.muted }]}>
              Discount
            </Text>

            <Text
              style={[
                styles.billValue,
                { color: colors.success },
              ]}
            >
              {discount > 0
                ? `- ${formatPrice(discount)}`
                : formatPrice(0)}
            </Text>
          </View>

          {subtotal >= 1200 && discount === 0 && (
            <Text
              style={[
                styles.discountHint,
                { color: colors.muted },
              ]}
            >
              Your cart qualifies for the threshold. Make sure
              eligible products have onSale: true.
            </Text>
          )}

          {subtotal < 1200 && (
            <View
              style={[
                styles.promoBox,
                { backgroundColor: colors.background },
              ]}
            >
              <Ionicons
                name="pricetag-outline"
                size={19}
                color={colors.primary}
              />

              <Text
                style={[
                  styles.promoText,
                  { color: colors.text },
                ]}
              >
                Shop for {formatPrice(1200 - subtotal)} more
                to unlock 20% off eligible sale products.
              </Text>
            </View>
          )}

          {subtotal >= 1200 && discount > 0 && (
            <View
              style={[
                styles.promoBox,
                { backgroundColor: colors.background },
              ]}
            >
              <Ionicons
                name="checkmark-circle"
                size={19}
                color={colors.success}
              />

              <Text
                style={[
                  styles.promoText,
                  { color: colors.success },
                ]}
              >
                Congratulations! Your 20% eligible-product
                discount has been applied.
              </Text>
            </View>
          )}

          <View
            style={[
              styles.divider,
              { backgroundColor: colors.border },
            ]}
          />

          <View style={styles.totalRow}>
            <Text
              style={[
                styles.totalLabel,
                { color: colors.text },
              ]}
            >
              Total
            </Text>

            <Text
              style={[
                styles.totalValue,
                { color: colors.primary },
              ]}
            >
              {formatPrice(total)}
            </Text>
          </View>
        </View>

        {/* Place order */}

        <TouchableOpacity
          style={[
            styles.placeOrderButton,
            {
              backgroundColor: colors.primary,
              opacity: placingOrder ? 0.7 : 1,
            },
          ]}
          onPress={handlePlaceOrder}
          disabled={placingOrder || cart.length === 0}
          activeOpacity={0.85}
        >
          {placingOrder ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <>
              <Ionicons
                name="checkmark-circle-outline"
                size={21}
                color="#FFFFFF"
              />

              <Text style={styles.placeOrderText}>
                Place Order • {formatPrice(total)}
              </Text>
            </>
          )}
        </TouchableOpacity>

        <View style={styles.secureNote}>
          <Ionicons
            name="shield-checkmark-outline"
            size={16}
            color={colors.muted}
          />

          <Text
            style={[
              styles.secureText,
              { color: colors.muted },
            ]}
          >
            Demo checkout. No real payment is processed.
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  header: {
    minHeight: 65,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
  },

  backButton: {
    width: 40,
    height: 40,
    borderRadius: 13,
    justifyContent: "center",
    alignItems: "center",
  },

  headerTitle: {
    fontSize: 19,
    fontWeight: "900",
  },

  scrollContent: {
    padding: 16,
    paddingBottom: 35,
  },

  section: {
    padding: 17,
    borderRadius: 20,
    borderWidth: 1,
    marginBottom: 16,
  },

  sectionHeading: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 18,
    gap: 10,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: "900",
  },

  label: {
    fontSize: 12,
    fontWeight: "800",
    marginBottom: 7,
    marginTop: 9,
  },

  input: {
    minHeight: 48,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 13,
    fontSize: 13,
  },

  addressInput: {
    minHeight: 85,
    paddingTop: 13,
  },

  paymentOption: {
    minHeight: 73,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    marginBottom: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },

  paymentTextContainer: {
    flex: 1,
  },

  paymentTitle: {
    fontSize: 12,
    fontWeight: "900",
  },

  paymentSubtitle: {
    fontSize: 10,
    marginTop: 5,
  },

  productRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 15,
    gap: 12,
  },

  productInfo: {
    flex: 1,
  },

  productName: {
    fontSize: 12,
    fontWeight: "800",
    lineHeight: 18,
  },

  productQuantity: {
    fontSize: 10,
    marginTop: 4,
  },

  productPrice: {
    fontSize: 12,
    fontWeight: "800",
  },

  divider: {
    height: 1,
    marginVertical: 13,
  },

  billRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginVertical: 7,
  },

  billLabel: {
    fontSize: 12,
    fontWeight: "600",
  },

  billValue: {
    fontSize: 12,
    fontWeight: "800",
  },

  discountHint: {
    fontSize: 10,
    lineHeight: 16,
    marginTop: 8,
  },

  promoBox: {
    flexDirection: "row",
    alignItems: "center",
    padding: 12,
    borderRadius: 12,
    gap: 9,
    marginTop: 12,
  },

  promoText: {
    flex: 1,
    fontSize: 11,
    lineHeight: 17,
    fontWeight: "700",
  },

  totalRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 5,
  },

  totalLabel: {
    fontSize: 16,
    fontWeight: "900",
  },

  totalValue: {
    fontSize: 21,
    fontWeight: "900",
  },

  placeOrderButton: {
    minHeight: 56,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 10,
    marginTop: 4,
  },

  placeOrderText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "900",
  },

  secureNote: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    marginTop: 16,
  },

  secureText: {
    fontSize: 10,
  },

  emptyText: {
    fontSize: 13,
    paddingVertical: 12,
  },
});
