// ============================================
// LUNA SHOPPING APP
// File: frontend/screens/HomeScreen.js
// ============================================

import React, { useCallback, useState } from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Alert,
  StatusBar,
  ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useFocusEffect } from "@react-navigation/native";

import ProductCard from "../components/ProductCard";
import MovingBanner from "../components/MovingBanner";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { useWishlist } from "../context/WishlistContext";

import { fetchProducts } from "../data/api";
import { CATEGORIES } from "../data/categories";

export default function HomeScreen({ navigation }) {
  const { colors, isDark } = useTheme();
  const { user } = useAuth();
  const { addToCart } = useCart();

  const {
    wishlist = [],
    toggleWishlist,
  } = useWishlist();

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  // ============================================
  // LOAD PRODUCTS FROM API
  // ============================================

  const loadProducts = useCallback(async () => {
    try {
      setLoading(true);

      const result = await fetchProducts();

      setProducts(Array.isArray(result) ? result : []);
    } catch (error) {
      console.log("Home products error:", error);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadProducts();
    }, [loadProducts])
  );

  // ============================================
  // WISHLIST HELPERS
  // ============================================

  const isFavourite = (product) => {
    return wishlist.some(
      (item) =>
        String(item.id) === String(product.id)
    );
  };

  function handleToggleWishlist(product) {
    if (typeof toggleWishlist !== "function") {
      Alert.alert(
        "Wishlist Error",
        "Wishlist is not connected correctly. Please check WishlistContext.js."
      );

      return;
    }

    toggleWishlist(product);
  }

  // ============================================
  // ADD TO CART
  // ============================================

  function handleAddToCart(product) {
    if (!user) {
      Alert.alert(
        "Login Required",
        "Please login or create an account first.",
        [
          {
            text: "Cancel",
            style: "cancel",
          },
          {
            text: "Login",
            onPress: () =>
              navigation.navigate("Login", {
                returnTo: "Home",
                pendingProduct: product,
              }),
          },
          {
            text: "Sign Up",
            onPress: () =>
              navigation.navigate("Signup", {
                returnTo: "Home",
                pendingProduct: product,
              }),
          },
        ]
      );

      return;
    }

    if (typeof addToCart !== "function") {
      Alert.alert(
        "Cart Error",
        "The cart is not connected correctly."
      );

      return;
    }

    addToCart({
      ...product,
      quantity: 1,
    });

    Alert.alert(
      "Added to Cart 💗",
      `${product.title || product.name || "Product"} added to your cart.`
    );
  }

  // ============================================
  // CATEGORY NAVIGATION
  // ============================================

  function openCategory(category) {
    navigation.navigate("Products", {
      category: category.name,
      categoryId: category.id,
    });
  }

  // ============================================
  // CATEGORY CARD
  // ============================================

  function renderCategory({ item }) {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => openCategory(item)}
        style={[
          styles.categoryCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <View
          style={[
            styles.categoryIcon,
            {
              backgroundColor: colors.background,
            },
          ]}
        >
          <Ionicons
            name={item.icon || "pricetag-outline"}
            size={23}
            color={colors.primary}
          />
        </View>

        <Text
          style={[
            styles.categoryName,
            { color: colors.text },
          ]}
          numberOfLines={1}
        >
          {item.name}
        </Text>
      </TouchableOpacity>
    );
  }

  // ============================================
  // PRODUCT CARD
  // ============================================

  function renderProduct({ item }) {
    return (
      <View style={styles.productWrapper}>
        <ProductCard
          product={item}
          onPress={() =>
            navigation.navigate("Details", {
              product: item,
            })
          }
          onAdd={() => handleAddToCart(item)}
          isFavourite={isFavourite(item)}
          onToggleWishlist={() =>
            handleToggleWishlist(item)
          }
          onWishlist={() =>
            handleToggleWishlist(item)
          }
        />
      </View>
    );
  }

  // ============================================
  // SCREEN
  // ============================================

  return (
    <View
      style={[
        styles.screen,
        {
          backgroundColor: colors.background,
        },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={
          isDark ? "light-content" : "dark-content"
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* HEADER */}

        <View style={styles.header}>
          <View style={styles.greetingContainer}>
            <Text
              style={[
                styles.eyebrow,
                { color: colors.muted },
              ]}
            >
              LUNA COLLECTION
            </Text>

            <Text
              style={[
                styles.greeting,
                { color: colors.text },
              ]}
            >
              {user
                ? `Hi, ${user.name || "there"} 👋`
                : "Hello, Beautiful 👋"}
            </Text>

            <Text
              style={[
                styles.subtitle,
                { color: colors.muted },
              ]}
            >
              Discover your everyday style.
            </Text>
          </View>

          {/* HEADER ACTIONS */}

          <View style={styles.headerActions}>
            {/* WISHLIST */}

            <TouchableOpacity
              activeOpacity={0.75}
              style={[
                styles.headerButton,
                {
                  backgroundColor: colors.card,
                },
              ]}
              onPress={() =>
                navigation.navigate("Wishlist")
              }
              accessibilityRole="button"
              accessibilityLabel="Open Wishlist"
            >
              <Ionicons
                name="heart-outline"
                size={24}
                color={colors.primary}
              />

              {wishlist.length > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>
                    {wishlist.length > 99
                      ? "99+"
                      : wishlist.length}
                  </Text>
                </View>
              )}
            </TouchableOpacity>

            {/* CART */}

            <TouchableOpacity
              activeOpacity={0.75}
              style={[
                styles.headerButton,
                {
                  backgroundColor: colors.card,
                },
              ]}
              onPress={() =>
                navigation.navigate("Cart")
              }
              accessibilityRole="button"
              accessibilityLabel="Open Cart"
            >
              <Ionicons
                name="bag-outline"
                size={24}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* MOVING BANNER */}

        <MovingBanner backgroundColor={colors.primary} />

        {/* DISCOUNT BANNER */}
        

        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() =>
            navigation.navigate("Products")
          }
          style={[
            styles.banner,
            {
              backgroundColor: colors.primary,
            },
          ]}
        >
          <View style={styles.bannerContent}>
            <Text style={styles.bannerEyebrow}>
              A LITTLE SOMETHING FOR YOU
            </Text>

            <Text style={styles.bannerTitle}>
              20% OFF
            </Text>

            <Text style={styles.bannerDescription}>
              Shop eligible sale items worth Rs. 1,200 or more.
            </Text>

            <View style={styles.bannerButton}>
              <Text style={styles.bannerButtonText}>
                SHOP NOW
              </Text>

              <Ionicons
                name="arrow-forward"
                size={15}
                color={colors.primary}
              />
            </View>
          </View>

          <Ionicons
            name="sparkles"
            size={66}
            color="#FFFFFF"
            style={styles.bannerIcon}
          />
        </TouchableOpacity>

        {/* CATEGORIES */}

        <View style={styles.sectionHeader}>
          <Text
            style={[
              styles.sectionTitle,
              { color: colors.text },
            ]}
          >
            Shop by Category
          </Text>

          <Text
            style={[
              styles.sectionHint,
              { color: colors.muted },
            ]}
          >
            Find your style
          </Text>
        </View>

        <FlatList
          data={CATEGORIES}
          renderItem={renderCategory}
          keyExtractor={(item) => String(item.id)}
          numColumns={2}
          scrollEnabled={false}
          columnWrapperStyle={styles.categoryRow}
          contentContainerStyle={styles.categoryList}
        />

        {/* FEATURED PRODUCTS */}

        <View style={styles.sectionHeader}>
          <Text
            style={[
              styles.sectionTitle,
              { color: colors.text },
            ]}
          >
            Featured Products
          </Text>

          <TouchableOpacity
            onPress={() =>
              navigation.navigate("Products")
            }
          >
            <Text
              style={[
                styles.viewAll,
                { color: colors.primary },
              ]}
            >
              View All
            </Text>
          </TouchableOpacity>
        </View>

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator
              size="large"
              color={colors.primary}
            />

            <Text
              style={[
                styles.loadingText,
                { color: colors.muted },
              ]}
            >
              Finding something lovely...
            </Text>
          </View>
        ) : products.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons
              name="bag-handle-outline"
              size={42}
              color={colors.primary}
            />

            <Text
              style={[
                styles.emptyTitle,
                { color: colors.text },
              ]}
            >
              No products available
            </Text>

            <Text
              style={[
                styles.emptyText,
                { color: colors.muted },
              ]}
            >
              Please check your connection and try again.
            </Text>

            <TouchableOpacity
              style={[
                styles.retryButton,
                {
                  backgroundColor: colors.primary,
                },
              ]}
              onPress={loadProducts}
            >
              <Text style={styles.retryButtonText}>
                Try Again
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={products.slice(0, 8)}
            renderItem={renderProduct}
            keyExtractor={(item, index) =>
              String(item.id ?? index)
            }
            numColumns={2}
            scrollEnabled={false}
            columnWrapperStyle={styles.productRow}
            contentContainerStyle={styles.productList}
          />
        )}

        {/* OFFER REMINDER */}

        <View
          style={[
            styles.offerReminder,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="pricetag-outline"
            size={22}
            color={colors.primary}
          />

          <View style={styles.offerTextContainer}>
            <Text
              style={[
                styles.offerTitle,
                { color: colors.text },
              ]}
            >
              A little extra love 💗
            </Text>

            <Text
              style={[
                styles.offerDescription,
                { color: colors.muted },
              ]}
            >
              Get 20% off eligible sale products when your
              subtotal reaches Rs. 1,200.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

// ============================================
// STYLES
// ============================================

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 18,
    paddingBottom: 35,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 22,
  },

  greetingContainer: {
    flex: 1,
    minWidth: 0,
  },

  eyebrow: {
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 2,
    marginBottom: 5,
  },

  greeting: {
    fontSize: 23,
    fontWeight: "900",
  },

  subtitle: {
    fontSize: 12,
    marginTop: 5,
  },

  // HEADER ICONS

  headerActions: {
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 8,
  },

  headerButton: {
    width: 43,
    height: 43,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
    marginLeft: 7,
    position: "relative",
  },

  badge: {
    position: "absolute",
    top: -5,
    right: -5,
    minWidth: 18,
    height: 18,
    paddingHorizontal: 4,
    borderRadius: 10,
    backgroundColor: "#E85D86",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#FFFFFF",
  },

  badgeText: {
    color: "#FFFFFF",
    fontSize: 9,
    fontWeight: "900",
  },

  // DISCOUNT BANNER

  banner: {
    minHeight: 185,
    borderRadius: 23,
    padding: 20,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 28,
  },

  bannerContent: {
    flex: 1,
    zIndex: 1,
  },

  bannerEyebrow: {
    color: "#FFFFFF",
    fontSize: 9,
    fontWeight: "800",
    letterSpacing: 1.1,
  },

  bannerTitle: {
    color: "#FFFFFF",
    fontSize: 36,
    fontWeight: "900",
    marginTop: 8,
  },

  bannerDescription: {
    color: "#FFFFFF",
    fontSize: 11,
    lineHeight: 17,
    marginTop: 5,
    maxWidth: 230,
  },

  bannerButton: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#FFFFFF",
    paddingHorizontal: 13,
    paddingVertical: 10,
    borderRadius: 11,
    marginTop: 13,
    gap: 8,
  },

  bannerButtonText: {
    color: "#705582",
    fontSize: 10,
    fontWeight: "900",
  },

  bannerIcon: {
    marginLeft: 5,
    opacity: 0.85,
  },

  // SECTION HEADERS

  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 15,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: "900",
  },

  sectionHint: {
    fontSize: 11,
  },

  viewAll: {
    fontSize: 12,
    fontWeight: "800",
  },

  // CATEGORIES

  categoryList: {
    marginBottom: 26,
  },

  categoryRow: {
    justifyContent: "space-between",
    marginBottom: 12,
  },

  categoryCard: {
    width: "48.5%",
    minHeight: 105,
    padding: 13,
    borderRadius: 17,
    borderWidth: 1,
  },

  categoryIcon: {
    width: 39,
    height: 39,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 9,
  },

  categoryName: {
    fontSize: 13,
    fontWeight: "800",
  },

  // PRODUCTS

  productList: {
    paddingBottom: 10,
  },

  productRow: {
    justifyContent: "space-between",
  },

  productWrapper: {
    width: "49%",
  },

  loadingContainer: {
    minHeight: 150,
    justifyContent: "center",
    alignItems: "center",
  },

  loadingText: {
    marginTop: 12,
    fontSize: 12,
  },

  emptyContainer: {
    paddingVertical: 30,
    alignItems: "center",
  },

  emptyTitle: {
    fontSize: 16,
    fontWeight: "800",
    marginTop: 12,
  },

  emptyText: {
    fontSize: 12,
    textAlign: "center",
    marginTop: 7,
  },

  retryButton: {
    marginTop: 15,
    borderRadius: 12,
    paddingHorizontal: 22,
    paddingVertical: 11,
  },

  retryButtonText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "800",
  },

  // OFFER REMINDER

  offerReminder: {
    flexDirection: "row",
    alignItems: "center",
    gap: 13,
    padding: 15,
    borderRadius: 17,
    borderWidth: 1,
    marginTop: 15,
  },

  offerTextContainer: {
    flex: 1,
  },

  offerTitle: {
    fontSize: 13,
    fontWeight: "900",
  },

  offerDescription: {
    fontSize: 11,
    lineHeight: 17,
    marginTop: 5,
  },
});