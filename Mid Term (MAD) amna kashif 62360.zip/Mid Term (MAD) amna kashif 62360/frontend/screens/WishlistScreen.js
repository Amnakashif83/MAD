// ============================================
// LUNA SHOPPING APP
// File: frontend/screens/WishlistScreen.js
// ============================================

import React from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  StatusBar,
} from "react-native";
import { useAuth } from "../context/AuthContext";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useWishlist } from "../context/WishlistContext";
import { useCart } from "../context/CartContext";

// ============================================
// WISHLIST SCREEN
// ============================================

export default function WishlistScreen({
  navigation,
}) {
  const { colors, isDark } = useTheme();

  const {
    wishlist = [],
    toggleWishlist,
  } = useWishlist();

  const { addToCart } = useCart();
const { user } = useAuth();

  const safeWishlist = Array.isArray(wishlist)
    ? wishlist
    : [];

  // ==========================================
  // FORMAT PRICE
  // ==========================================

  function formatPrice(price) {
    return `Rs. ${Number(
      price || 0
    ).toLocaleString("en-PK", {
      maximumFractionDigits: 2,
    })}`;
  }

  // ==========================================
  // ADD TO CART
  // ==========================================
function handleAddToCart(product) {
  if (!user) {
    Alert.alert(
      "Login Required",
      "Please login or create an account before adding products to your cart.",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Login",
          onPress: () =>
            navigation.navigate("Login", {
              returnTo: "Wishlist",
              pendingProduct: product,
            }),
        },
        {
          text: "Sign Up",
          onPress: () =>
            navigation.navigate("Signup", {
              returnTo: "Wishlist",
              pendingProduct: product,
            }),
        },
      ]
    );

    return;
  }

  addToCart({
    ...product,
    quantity: 1,
  });

  Alert.alert(
    "Added to Cart 💗",
    `${product.title || product.name || "Product"} added to your shopping bag.`
  );
}
  function handleRemove(product) {
    toggleWishlist(product);
  }

  // ==========================================
  // OPEN PRODUCT DETAILS
  // ==========================================

  function openProduct(product) {
    navigation.navigate("Details", {
      product,
    });
  }

  // ==========================================
  // HEADER
  // ==========================================

  return (
    <View
      style={[
        styles.screen,
        {
          backgroundColor: colors.background,
        },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={
          isDark
            ? "light-content"
            : "dark-content"
        }
      />

      {/* HEADER */}

      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[
            styles.backButton,
            {
              backgroundColor: colors.card,
            },
          ]}
          accessibilityLabel="Go back"
        >
          <Ionicons
            name="arrow-back"
            size={22}
            color={colors.text}
          />
        </TouchableOpacity>

        <View style={styles.headerInfo}>
          <Text
            style={[
              styles.headerTitle,
              { color: colors.text },
            ]}
          >
            My Wishlist
          </Text>

          <Text
            style={[
              styles.headerSubtitle,
              { color: colors.muted },
            ]}
          >
            Things you love
          </Text>
        </View>

        <View
          style={[
            styles.countBadge,
            {
              backgroundColor: colors.card,
            },
          ]}
        >
          <Ionicons
            name="heart"
            size={17}
            color="#E85D86"
          />

          <Text
            style={[
              styles.countText,
              { color: colors.text },
            ]}
          >
            {safeWishlist.length}
          </Text>
        </View>
      </View>

      {/* EMPTY WISHLIST */}

      {safeWishlist.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View
            style={[
              styles.emptyIcon,
              {
                backgroundColor: colors.card,
              },
            ]}
          >
            <Ionicons
              name="heart-outline"
              size={55}
              color="#E85D86"
            />
          </View>

          <Text
            style={[
              styles.emptyTitle,
              { color: colors.text },
            ]}
          >
            No favourites yet
          </Text>

          <Text
            style={[
              styles.emptyText,
              { color: colors.muted },
            ]}
          >
            Save products you love by tapping
            the heart icon on a product.
          </Text>

          <TouchableOpacity
            style={[
              styles.exploreButton,
              {
                backgroundColor: colors.primary,
              },
            ]}
            onPress={() =>
              navigation.navigate("Products")
            }
          >
            <Text
              style={styles.exploreButtonText}
            >
              Discover Products
            </Text>

            <Ionicons
              name="arrow-forward"
              size={17}
              color="#FFFFFF"
            />
          </TouchableOpacity>
        </View>
      ) : (
        /* WISHLIST PRODUCTS */

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={
            styles.listContent
          }
        >
          {/* INTRO CARD */}

          <View
            style={[
              styles.introCard,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
          >
            <Ionicons
              name="sparkles-outline"
              size={25}
              color={colors.primary}
            />

            <View style={styles.introInfo}>
              <Text
                style={[
                  styles.introTitle,
                  { color: colors.text },
                ]}
              >
                Your personal collection
              </Text>

              <Text
                style={[
                  styles.introText,
                  { color: colors.muted },
                ]}
              >
                Keep your favourite finds in one place.
              </Text>
            </View>
          </View>

          {/* PRODUCT LIST */}

          {safeWishlist.map(
            (product, index) => {
              /*
               * Online image:
               * product.image = "https://..."
               *
               * Local image:
               * product.image = require(...)
               *
               * Local require() returns a number,
               * so it must not be wrapped in { uri }.
               */

              const image =
                product.image ??
                product.thumbnail ??
                null;

              const imageSource =
                typeof image === "number"
                  ? image
                  : typeof image === "string" &&
                    /^https?:\/\/\S+/i.test(
                      image.trim()
                    )
                  ? {
                      uri: image.trim(),
                    }
                  : null;

              return (
                <View
                  key={String(
                    product.id ??
                    product._id ??
                    index
                  )}
                  style={[
                    styles.productCard,
                    {
                      backgroundColor:
                        colors.card,
                      borderColor:
                        colors.border,
                    },
                  ]}
                >
                  {/* PRODUCT IMAGE */}

                  <TouchableOpacity
                    activeOpacity={0.8}
                    onPress={() =>
                      openProduct(product)
                    }
                    style={styles.imageWrapper}
                  >
                    {imageSource ? (
                      <Image
                        source={imageSource}
                        style={styles.productImage}
                        resizeMode="contain"
                      />
                    ) : (
                      <View
                        style={[
                          styles.productImage,
                          styles.imagePlaceholder,
                          {
                            backgroundColor:
                              colors.background,
                          },
                        ]}
                      >
                        <Ionicons
                          name="image-outline"
                          size={35}
                          color={colors.muted}
                        />

                        <Text
                          style={[
                            styles.placeholderText,
                            {
                              color: colors.muted,
                            },
                          ]}
                        >
                          No Image
                        </Text>
                      </View>
                    )}
                  </TouchableOpacity>

                  {/* PRODUCT DETAILS */}

                  <View style={styles.productInfo}>
                    <TouchableOpacity
                      activeOpacity={0.8}
                      onPress={() =>
                        openProduct(product)
                      }
                    >
                      <Text
                        numberOfLines={2}
                        style={[
                          styles.productTitle,
                          { color: colors.text },
                        ]}
                      >
                        {product.title ||
                          product.name ||
                          "LUNA Product"}
                      </Text>
                    </TouchableOpacity>

                    <Text
                      numberOfLines={1}
                      style={[
                        styles.productCategory,
                        { color: colors.muted },
                      ]}
                    >
                      {product.category ||
                        "LUNA COLLECTION"}
                    </Text>

                    <Text
                      style={[
                        styles.productPrice,
                        {
                          color: colors.primary,
                        },
                      ]}
                    >
                      {formatPrice(product.price)}
                    </Text>

                    {/* SALE BADGE */}

                    {product.onSale === true && (
                      <View style={styles.saleBadge}>
                        <Ionicons
                          name="pricetag-outline"
                          size={12}
                          color="#2E8B57"
                        />

                        <Text
                          style={styles.saleBadgeText}
                        >
                          20% OFF ELIGIBLE ORDERS
                        </Text>
                      </View>
                    )}

                    {/* ACTION BUTTONS */}

                    <View style={styles.actions}>
                      <TouchableOpacity
                        style={[
                          styles.addButton,
                          {
                            backgroundColor:
                              colors.primary,
                          },
                        ]}
                        onPress={() =>
                          handleAddToCart(product)
                        }
                        accessibilityLabel="Add product to cart"
                      >
                        <Ionicons
                          name="bag-add-outline"
                          size={16}
                          color="#FFFFFF"
                        />

                        <Text
                          style={
                            styles.addButtonText
                          }
                        >
                          Add to Bag
                        </Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={[
                          styles.removeButton,
                          {
                            backgroundColor:
                              colors.background,
                            borderColor:
                              colors.border,
                          },
                        ]}
                        onPress={() =>
                          handleRemove(product)
                        }
                        accessibilityLabel="Remove from wishlist"
                      >
                        <Ionicons
                          name="heart-dislike-outline"
                          size={19}
                          color="#E85D86"
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              );
            }
          )}

          {/* CONTINUE SHOPPING */}

          <TouchableOpacity
            style={[
              styles.continueButton,
              {
                borderColor: colors.border,
              },
            ]}
            onPress={() =>
              navigation.navigate("Products")
            }
          >
            <Text
              style={[
                styles.continueButtonText,
                {
                  color: colors.primary,
                },
              ]}
            >
              Continue Shopping
            </Text>

            <Ionicons
              name="arrow-forward"
              size={18}
              color={colors.primary}
            />
          </TouchableOpacity>

          <View style={{ height: 25 }} />
        </ScrollView>
      )}
    </View>
  );
}

// ============================================
// STYLES
// ============================================

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 17,
    gap: 12,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },

  headerInfo: {
    flex: 1,
  },

  headerTitle: {
    fontSize: 20,
    fontWeight: "900",
  },

  headerSubtitle: {
    fontSize: 11,
    marginTop: 4,
  },

  countBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 13,
  },

  countText: {
    fontSize: 12,
    fontWeight: "900",
  },

  listContent: {
    paddingHorizontal: 18,
    paddingBottom: 15,
  },

  introCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 15,
    borderRadius: 17,
    borderWidth: 1,
    marginBottom: 17,
  },

  introInfo: {
    flex: 1,
  },

  introTitle: {
    fontSize: 13,
    fontWeight: "900",
  },

  introText: {
    fontSize: 11,
    marginTop: 4,
  },

  productCard: {
    borderRadius: 19,
    borderWidth: 1,
    padding: 12,
    flexDirection: "row",
    gap: 13,
    marginBottom: 13,
  },

  imageWrapper: {
    width: 112,
    height: 145,
  },

  productImage: {
    width: "100%",
    height: "100%",
    borderRadius: 14,
  },

  imagePlaceholder: {
    justifyContent: "center",
    alignItems: "center",
  },

  placeholderText: {
    fontSize: 10,
    marginTop: 5,
  },

  productInfo: {
    flex: 1,
    justifyContent: "space-between",
    paddingVertical: 3,
    minWidth: 0,
  },

  productTitle: {
    fontSize: 13,
    lineHeight: 19,
    fontWeight: "900",
  },

  productCategory: {
    fontSize: 10,
    marginTop: 5,
  },

  productPrice: {
    fontSize: 16,
    fontWeight: "900",
    marginTop: 8,
  },

  saleBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 6,
    flexWrap: "wrap",
  },

  saleBadgeText: {
    color: "#2E8B57",
    fontSize: 8,
    fontWeight: "900",
  },

  actions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginTop: 10,
  },

  addButton: {
    flex: 1,
    minHeight: 37,
    borderRadius: 11,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingHorizontal: 5,
  },

  addButtonText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "900",
  },

  removeButton: {
    width: 38,
    height: 37,
    borderRadius: 11,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  continueButton: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 14,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
    marginTop: 5,
  },

  continueButtonText: {
    fontSize: 12,
    fontWeight: "900",
  },

  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 35,
  },

  emptyIcon: {
    width: 115,
    height: 115,
    borderRadius: 36,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 22,
  },

  emptyTitle: {
    fontSize: 21,
    fontWeight: "900",
  },

  emptyText: {
    fontSize: 12,
    lineHeight: 19,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 23,
  },

  exploreButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    paddingHorizontal: 24,
    paddingVertical: 15,
    borderRadius: 14,
  },

  exploreButtonText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "900",
  },
});
