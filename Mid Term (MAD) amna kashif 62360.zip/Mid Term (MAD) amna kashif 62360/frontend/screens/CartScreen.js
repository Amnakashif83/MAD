import React from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  StatusBar,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useCart } from "../context/CartContext";

import { calculateBill } from "../services/productService";

export default function CartScreen({ navigation }) {
  const { colors, isDark } = useTheme();

  const {
    cart = [],
    removeFromCart,
    updateQuantity,
    clearCart,
  } = useCart();

  const safeCart = Array.isArray(cart) ? cart : [];

  const bill = calculateBill(safeCart);

  function increase(item) {
    updateQuantity(item.id, (Number(item.quantity) || 1) + 1);
  }

  function decrease(item) {
    const quantity = Number(item.quantity) || 1;

    if (quantity <= 1) {
      return;
    }

    updateQuantity(item.id, quantity - 1);
  }

  function confirmRemove(item) {
    Alert.alert(
      "Remove Product",
      `Remove ${item.title || item.name || "this product"} from your cart?`,
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Remove",
          style: "destructive",
          onPress: () => removeFromCart(item.id),
        },
      ]
    );
  }

  function formatPrice(value) {
    return `Rs. ${Number(value || 0).toLocaleString("en-PK", {
      maximumFractionDigits: 2,
    })}`;
  }

  function checkout() {
    if (safeCart.length === 0) {
      Alert.alert("Your bag is empty", "Add products before checkout.");
      return;
    }

    navigation.navigate("Checkout");
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[styles.backButton, { backgroundColor: colors.card }]}
        >
          <Ionicons name="arrow-back" size={22} color={colors.text} />
        </TouchableOpacity>

        <View style={{ flex: 1 }}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>
            My Shopping Bag
          </Text>

          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
            {safeCart.length} product type(s)
          </Text>
        </View>

        {safeCart.length > 0 && (
          <TouchableOpacity
            onPress={() =>
              Alert.alert(
                "Clear Shopping Bag",
                "Remove all products from your cart?",
                [
                  { text: "Cancel", style: "cancel" },
                  {
                    text: "Clear",
                    style: "destructive",
                    onPress: clearCart,
                  },
                ]
              )
            }
          >
            <Text style={styles.clearText}>Clear</Text>
          </TouchableOpacity>
        )}
      </View>

      {safeCart.length === 0 ? (
        <View style={styles.emptyContainer}>
          <View
            style={[
              styles.emptyIcon,
              { backgroundColor: colors.card },
            ]}
          >
            <Ionicons
              name="bag-handle-outline"
              size={52}
              color={colors.primary}
            />
          </View>

          <Text style={[styles.emptyTitle, { color: colors.text }]}>
            Your bag is waiting
          </Text>

          <Text style={[styles.emptyText, { color: colors.muted }]}>
            Discover something beautiful and add it to your shopping bag.
          </Text>

          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: colors.primary }]}
            onPress={() => navigation.navigate("Products")}
          >
            <Text style={styles.primaryButtonText}>Explore Products</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}
          >
            {safeCart.map((item) => {
              const price = Number(item.price) || 0;
              const quantity = Number(item.quantity) || 1;

              const lineTotal = price * quantity;

              const imageUri =
                typeof item.image === "string" &&
                item.image.startsWith("http")
                  ? item.image
                  : typeof item.thumbnail === "string" &&
                    item.thumbnail.startsWith("http")
                  ? item.thumbnail
                  : null;

              return (
                <View
                  key={String(item.id)}
                  style={[
                    styles.cartItem,
                    {
                      backgroundColor: colors.card,
                      borderColor: colors.border,
                    },
                  ]}
                >
                  {imageUri ? (
                    <Image
                      source={{ uri: imageUri }}
                      style={styles.productImage}
                      resizeMode="contain"
                    />
                  ) : (
                    <View
                      style={[
                        styles.productImage,
                        styles.imagePlaceholder,
                        { backgroundColor: colors.background },
                      ]}
                    >
                      <Ionicons
                        name="image-outline"
                        size={35}
                        color={colors.muted}
                      />
                    </View>
                  )}

                  <View style={styles.itemContent}>
                    <Text
                      numberOfLines={2}
                      style={[styles.productTitle, { color: colors.text }]}
                    >
                      {item.title || item.name || "LUNA Product"}
                    </Text>

                    <Text style={[styles.productPrice, { color: colors.primary }]}>
                      {formatPrice(price)}
                    </Text>

                    <Text style={[styles.lineTotal, { color: colors.muted }]}>
                      Item total: {formatPrice(lineTotal)}
                    </Text>

                    {item.onSale && (
                      <Text style={styles.saleLabel}>
                        Eligible for 20% off*
                      </Text>
                    )}

                    <View style={styles.itemBottom}>
                      <View
                        style={[
                          styles.quantityControl,
                          { borderColor: colors.border },
                        ]}
                      >
                        <TouchableOpacity
                          style={styles.quantityButton}
                          onPress={() => decrease(item)}
                          disabled={quantity <= 1}
                        >
                          <Ionicons
                            name="remove"
                            size={17}
                            color={colors.primary}
                          />
                        </TouchableOpacity>

                        <Text style={[styles.quantity, { color: colors.text }]}>
                          {quantity}
                        </Text>

                        <TouchableOpacity
                          style={styles.quantityButton}
                          onPress={() => increase(item)}
                        >
                          <Ionicons
                            name="add"
                            size={17}
                            color={colors.primary}
                          />
                        </TouchableOpacity>
                      </View>

                      <TouchableOpacity onPress={() => confirmRemove(item)}>
                        <Ionicons
                          name="trash-outline"
                          size={21}
                          color="#D9534F"
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              );
            })}

            <View
              style={[
                styles.offerCard,
                { backgroundColor: colors.card, borderColor: colors.border },
              ]}
            >
              <Ionicons
                name="gift-outline"
                size={26}
                color={colors.primary}
              />

              <View style={{ flex: 1 }}>
                <Text style={[styles.offerTitle, { color: colors.text }]}>
                  Your LUNA Special Offer
                </Text>

                <Text style={[styles.offerText, { color: colors.muted }]}>
                  Spend Rs. 1,200 or more to unlock 20% off eligible sale
                  products.
                </Text>
              </View>
            </View>
          </ScrollView>

          <View
            style={[
              styles.summary,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
          >
            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.muted }]}>
                Subtotal
              </Text>

              <Text style={[styles.summaryValue, { color: colors.text }]}>
                {formatPrice(bill.subtotal)}
              </Text>
            </View>

            <View style={styles.summaryRow}>
              <Text style={[styles.summaryLabel, { color: colors.muted }]}>
                Discount
              </Text>

              <Text style={[styles.discountValue, { color: "#2E8B57" }]}>
                - {formatPrice(bill.discount)}
              </Text>
            </View>

            <View
              style={[
                styles.divider,
                { backgroundColor: colors.border },
              ]}
            />

            <View style={styles.summaryRow}>
              <Text style={[styles.totalLabel, { color: colors.text }]}>
                Total
              </Text>

              <Text style={[styles.totalValue, { color: colors.primary }]}>
                {formatPrice(bill.total)}
              </Text>
            </View>

            <TouchableOpacity
              style={[
                styles.checkoutButton,
                { backgroundColor: colors.primary },
              ]}
              onPress={checkout}
              activeOpacity={0.85}
            >
              <Text style={styles.checkoutButtonText}>
                Proceed to Checkout
              </Text>

              <Ionicons
                name="arrow-forward"
                size={19}
                color="#FFFFFF"
              />
            </TouchableOpacity>

            <Text style={[styles.taxNote, { color: colors.muted }]}>
              *Discount applies only to eligible sale products when subtotal
              reaches Rs. 1,200.
            </Text>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 14,
    gap: 12,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontSize: 19,
    fontWeight: "900",
  },

  headerSubtitle: {
    fontSize: 11,
    marginTop: 4,
  },

  clearText: {
    color: "#D9534F",
    fontSize: 12,
    fontWeight: "900",
  },

  scroll: {
    flex: 1,
  },

  scrollContent: {
    paddingHorizontal: 18,
    paddingBottom: 15,
  },

  cartItem: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 12,
    flexDirection: "row",
    gap: 12,
    marginBottom: 12,
  },

  productImage: {
    width: 100,
    height: 125,
    borderRadius: 13,
  },

  imagePlaceholder: {
    justifyContent: "center",
    alignItems: "center",
  },

  itemContent: {
    flex: 1,
    justifyContent: "space-between",
    paddingVertical: 3,
  },

  productTitle: {
    fontSize: 13,
    lineHeight: 19,
    fontWeight: "800",
  },

  productPrice: {
    fontSize: 14,
    fontWeight: "900",
    marginTop: 6,
  },

  lineTotal: {
    fontSize: 10,
    marginTop: 4,
  },

  saleLabel: {
    color: "#2E8B57",
    fontSize: 10,
    fontWeight: "800",
    marginTop: 5,
  },

  itemBottom: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 10,
  },

  quantityControl: {
    borderWidth: 1,
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    minHeight: 33,
  },

  quantityButton: {
    width: 31,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
  },

  quantity: {
    minWidth: 23,
    textAlign: "center",
    fontSize: 12,
    fontWeight: "900",
  },

  offerCard: {
    flexDirection: "row",
    gap: 12,
    padding: 15,
    borderWidth: 1,
    borderRadius: 16,
    marginTop: 7,
  },

  offerTitle: {
    fontSize: 12,
    fontWeight: "900",
  },

  offerText: {
    fontSize: 11,
    lineHeight: 17,
    marginTop: 5,
  },

  summary: {
    paddingHorizontal: 20,
    paddingTop: 15,
    paddingBottom: 17,
    borderTopWidth: 1,
    borderTopLeftRadius: 23,
    borderTopRightRadius: 23,
  },

  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },

  summaryLabel: {
    fontSize: 12,
  },

  summaryValue: {
    fontSize: 12,
    fontWeight: "800",
  },

  discountValue: {
    fontSize: 12,
    fontWeight: "900",
  },

  divider: {
    height: 1,
    marginVertical: 5,
  },

  totalLabel: {
    fontSize: 15,
    fontWeight: "900",
  },

  totalValue: {
    fontSize: 19,
    fontWeight: "900",
  },

  checkoutButton: {
    minHeight: 51,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    marginTop: 7,
  },

  checkoutButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "900",
  },

  taxNote: {
    fontSize: 9,
    lineHeight: 14,
    textAlign: "center",
    marginTop: 10,
  },

  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 35,
  },

  emptyIcon: {
    width: 110,
    height: 110,
    borderRadius: 35,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 20,
  },

  emptyTitle: {
    fontSize: 21,
    fontWeight: "900",
  },

  emptyText: {
    fontSize: 12,
    lineHeight: 19,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 22,
  },

  primaryButton: {
    paddingHorizontal: 25,
    paddingVertical: 15,
    borderRadius: 14,
  },

  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "900",
  },
});
