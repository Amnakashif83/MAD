import React from "react";

import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Switch,
  Alert,
  StatusBar,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";

export default function SettingsScreen({ navigation }) {
  const { colors, isDark, toggleTheme } = useTheme();
  const auth = useAuth();

  const user = auth?.user;

  const muted =
    colors.muted || colors.secondaryText || colors.text;

  function openScreen(screenName) {
    navigation.navigate(screenName);
  }

  function handleLogout() {
    const logoutFunction =
      typeof auth?.logout === "function"
        ? auth.logout
        : typeof auth?.signOut === "function"
        ? auth.signOut
        : null;

    if (!logoutFunction) {
      Alert.alert(
        "Logout Unavailable",
        "Please configure logout in AuthContext.js."
      );
      return;
    }

    Alert.alert(
      "Logout",
      "Are you sure you want to logout?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Logout",
          style: "destructive",
          onPress: async () => {
            try {
              await logoutFunction();

              // Authentication state should be updated by AuthContext.
              // Navigate to Welcome only if it is registered.
              navigation.reset({
                index: 0,
                routes: [{ name: "Welcome" }],
              });
            } catch (error) {
              console.log("Logout error:", error);

              Alert.alert(
                "Logout Failed",
                "Unable to logout. Please try again."
              );
            }
          },
        },
      ]
    );
  }

  function SettingItem({
    icon,
    title,
    subtitle,
    onPress,
    danger = false,
  }) {
    return (
      <TouchableOpacity
        style={[
          styles.settingItem,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
        onPress={onPress}
        activeOpacity={0.75}
      >
        <View
          style={[
            styles.itemIcon,
            { backgroundColor: colors.background },
          ]}
        >
          <Ionicons
            name={icon}
            size={21}
            color={danger ? "#E85D86" : colors.primary}
          />
        </View>

        <View style={styles.itemContent}>
          <Text
            style={[
              styles.itemTitle,
              { color: danger ? "#E85D86" : colors.text },
            ]}
          >
            {title}
          </Text>

          {!!subtitle && (
            <Text style={[styles.itemSubtitle, { color: muted }]}>
              {subtitle}
            </Text>
          )}
        </View>

        <Ionicons
          name="chevron-forward"
          size={19}
          color={colors.secondary}
        />
      </TouchableOpacity>
    );
  }

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <ScrollView
        contentContainerStyle={styles.container}
        showsVerticalScrollIndicator={false}
      >
        {/* HEADER */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={[
              styles.backButton,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
          >
            <Ionicons
              name="arrow-back"
              size={22}
              color={colors.text}
            />
          </TouchableOpacity>

          <Text style={[styles.headerTitle, { color: colors.text }]}>
            Settings
          </Text>

          <View style={styles.headerSpacer} />
        </View>

        {/* BRAND */}
        <View
          style={[
            styles.brandCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <View
            style={[
              styles.brandIcon,
              { backgroundColor: colors.background },
            ]}
          >
            <Ionicons
              name="heart"
              size={30}
              color={colors.primary}
            />
          </View>

          <Text style={[styles.brandTitle, { color: colors.primary }]}>
            LUNA ♡
          </Text>

          <Text style={[styles.brandSubtitle, { color: muted }]}>
            Your style, your story.
          </Text>
        </View>

        {/* ACCOUNT */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          MY ACCOUNT
        </Text>

        <View style={styles.section}>
          <SettingItem
            icon="person-outline"
            title="My Profile"
            subtitle="Manage your personal information"
            onPress={() => openScreen("Profile")}
          />

          <SettingItem
            icon="heart-outline"
            title="My Wishlist"
            subtitle="View your favourite products"
            onPress={() => openScreen("Wishlist")}
          />

          <SettingItem
            icon="bag-outline"
            title="Shopping Cart"
            subtitle="View items in your bag"
            onPress={() => openScreen("Cart")}
          />
        </View>

        {/* APPEARANCE */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          APPEARANCE
        </Text>

        <View
          style={[
            styles.themeCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <View
            style={[
              styles.itemIcon,
              { backgroundColor: colors.background },
            ]}
          >
            <Ionicons
              name={isDark ? "moon" : "sunny"}
              size={22}
              color={colors.primary}
            />
          </View>

          <View style={styles.themeTextContainer}>
            <Text style={[styles.itemTitle, { color: colors.text }]}>
              Dark Mode
            </Text>

            <Text style={[styles.itemSubtitle, { color: muted }]}>
              {isDark
                ? "Dark appearance is enabled"
                : "Light appearance is enabled"}
            </Text>
          </View>

          <Switch
            value={isDark}
            onValueChange={toggleTheme}
            trackColor={{
              false: "#D8C9E0",
              true: colors.primary,
            }}
            thumbColor="#FFFFFF"
            ios_backgroundColor="#D8C9E0"
            accessibilityLabel="Toggle dark mode"
          />
        </View>

        {/* SUPPORT */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          SUPPORT
        </Text>

        <View style={styles.section}>
          <SettingItem
            icon="information-circle-outline"
            title="About LUNA"
            subtitle="Learn more about our store"
            onPress={() =>
              Alert.alert(
                "About LUNA ♡",
                "LUNA is your destination for fashion, accessories and beauty essentials."
              )
            }
          />

          <SettingItem
            icon="help-circle-outline"
            title="Help & Support"
            subtitle="Get assistance with your shopping"
            onPress={() =>
              Alert.alert(
                "Help & Support",
                "Please contact your store administrator for assistance."
              )
            }
          />
        </View>

        {/* USER INFORMATION */}
        <View
          style={[
            styles.userCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="person-circle-outline"
            size={35}
            color={colors.primary}
          />

          <View style={styles.userInfo}>
            <Text style={[styles.userName, { color: colors.text }]}>
              {user?.name || "LUNA Shopper"}
            </Text>

            <Text style={[styles.itemSubtitle, { color: muted }]}>
              {user?.email || "Welcome to LUNA"}
            </Text>
          </View>
        </View>

        {/* LOGOUT */}
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
          activeOpacity={0.8}
        >
          <Ionicons
            name="log-out-outline"
            size={21}
            color="#E85D86"
          />

          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>

        {/* FOOTER */}
        <Text style={[styles.footer, { color: muted }]}>
          Made with love at LUNA ♡
        </Text>

        <Text style={[styles.version, { color: muted }]}>
          Version 1.0.0
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  container: {
    paddingHorizontal: 18,
    paddingTop: 50,
    paddingBottom: 35,
  },

  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 25,
  },

  backButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  headerTitle: {
    fontSize: 22,
    fontWeight: "900",
  },

  headerSpacer: {
    width: 42,
  },

  brandCard: {
    alignItems: "center",
    padding: 23,
    borderRadius: 22,
    borderWidth: 1,
    marginBottom: 28,
  },

  brandIcon: {
    width: 65,
    height: 65,
    borderRadius: 23,
    alignItems: "center",
    justifyContent: "center",
  },

  brandTitle: {
    fontSize: 25,
    fontWeight: "900",
    letterSpacing: 3,
    marginTop: 13,
  },

  brandSubtitle: {
    fontSize: 12,
    marginTop: 6,
  },

  sectionTitle: {
    fontSize: 12,
    fontWeight: "900",
    letterSpacing: 1.5,
    marginBottom: 12,
    marginLeft: 3,
  },

  section: {
    gap: 10,
    marginBottom: 27,
  },

  settingItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    minHeight: 76,
  },

  itemIcon: {
    width: 43,
    height: 43,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },

  itemContent: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
  },

  itemTitle: {
    fontSize: 13,
    fontWeight: "800",
  },

  itemSubtitle: {
    fontSize: 10,
    marginTop: 5,
    lineHeight: 15,
  },

  themeCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 28,
  },

  themeTextContainer: {
    flex: 1,
    marginLeft: 12,
    marginRight: 8,
  },

  userCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 15,
    borderRadius: 16,
    borderWidth: 1,
    marginTop: 2,
  },

  userInfo: {
    flex: 1,
    marginLeft: 12,
  },

  userName: {
    fontSize: 14,
    fontWeight: "900",
  },

  logoutButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
    borderWidth: 1,
    borderColor: "#E85D86",
    borderRadius: 14,
    paddingVertical: 14,
    marginTop: 20,
  },

  logoutText: {
    fontSize: 13,
    fontWeight: "900",
    color: "#E85D86",
  },

  footer: {
    textAlign: "center",
    fontSize: 11,
    marginTop: 25,
  },

  version: {
    textAlign: "center",
    fontSize: 10,
    marginTop: 6,
  },
});
