import React, { useEffect, useRef } from "react";

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Animated,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "../context/ThemeContext";

export default function OrderSuccessScreen({ navigation, route }) {
  const { colors, isDark } = useTheme();

  const order = route?.params?.order || null;

  const scale = useRef(new Animated.Value(0.5)).current;
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(scale, {
        toValue: 1,
        friction: 5,
        tension: 70,
        useNativeDriver: true,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 450,
        useNativeDriver: true,
      }),
    ]).start();
  }, [scale, opacity]);

  const orderId = order?.id ? String(order.id) : null;

  const total = Number(
    order?.total ?? order?.bill?.total ?? 0
  );

  function goHome() {
    navigation.reset({
      index: 0,
      routes: [
        {
          name: "Main",
        },
      ],
    });
  }

  function viewOrders() {
    navigation.navigate("Profile");
  }

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <View style={styles.content}>
        <Animated.View
          style={[
            styles.successCircle,
            {
              backgroundColor: colors.success + "20",
              opacity,
              transform: [{ scale }],
            },
          ]}
        >
          <View
            style={[
              styles.innerCircle,
              { backgroundColor: colors.success },
            ]}
          >
            <Ionicons
              name="checkmark"
              size={58}
              color="#FFFFFF"
            />
          </View>
        </Animated.View>

        <Text style={[styles.brand, { color: colors.primary }]}>
          L U N A
        </Text>

        <Text style={[styles.title, { color: colors.text }]}>
          Order Placed!
        </Text>

        <Text style={[styles.description, { color: colors.muted }]}>
          Thank you for shopping with LUNA. Your order has been placed
          successfully.
        </Text>

        {orderId && (
          <View
            style={[
              styles.orderCard,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
              },
            ]}
          >
            <Text style={[styles.orderLabel, { color: colors.muted }]}>
              ORDER NUMBER
            </Text>

            <Text style={[styles.orderNumber, { color: colors.text }]}>
              #{orderId}
            </Text>

            <View
              style={[
                styles.divider,
                { backgroundColor: colors.border },
              ]}
            />

            <View style={styles.totalRow}>
              <Text style={[styles.totalLabel, { color: colors.muted }]}>
                Order total
              </Text>

              <Text style={[styles.total, { color: colors.primary }]}>
                Rs. {total.toLocaleString("en-PK")}
              </Text>
            </View>
          </View>
        )}

        <View style={styles.infoRow}>
          <Ionicons
            name="heart-outline"
            size={20}
            color={colors.primary}
          />

          <Text style={[styles.infoText, { color: colors.muted }]}>
            Your next favourite is just around the corner.
          </Text>
        </View>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity
          style={[
            styles.primaryButton,
            { backgroundColor: colors.primary },
          ]}
          onPress={goHome}
          activeOpacity={0.85}
        >
          <Ionicons name="home-outline" size={19} color="#FFFFFF" />

          <Text style={styles.primaryButtonText}>
            Continue Shopping
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.secondaryButton,
            {
              borderColor: colors.border,
              backgroundColor: colors.card,
            },
          ]}
          onPress={viewOrders}
          activeOpacity={0.85}
        >
          <Text style={[styles.secondaryButtonText, { color: colors.text }]}>
            View My Account
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    justifyContent: "space-between",
    padding: 24,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  successCircle: {
    width: 145,
    height: 145,
    borderRadius: 75,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 30,
  },
  innerCircle: {
    width: 105,
    height: 105,
    borderRadius: 55,
    justifyContent: "center",
    alignItems: "center",
  },
  brand: {
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 3,
    marginBottom: 17,
  },
  title: {
    fontSize: 31,
    fontWeight: "900",
    textAlign: "center",
  },
  description: {
    fontSize: 13,
    lineHeight: 22,
    textAlign: "center",
    marginTop: 13,
    maxWidth: 300,
  },
  orderCard: {
    width: "100%",
    borderRadius: 18,
    borderWidth: 1,
    padding: 20,
    marginTop: 30,
  },
  orderLabel: {
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 1.5,
  },
  orderNumber: {
    fontSize: 20,
    fontWeight: "900",
    marginTop: 7,
  },
  divider: {
    height: 1,
    marginVertical: 17,
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  totalLabel: {
    fontSize: 12,
    fontWeight: "700",
  },
  total: {
    fontSize: 18,
    fontWeight: "900",
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 9,
    marginTop: 22,
  },
  infoText: {
    fontSize: 11,
    flex: 1,
  },
  footer: {
    gap: 12,
    paddingBottom: 12,
  },
  primaryButton: {
    minHeight: 54,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },
  primaryButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "900",
  },
  secondaryButton: {
    minHeight: 50,
    borderRadius: 15,
    borderWidth: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  secondaryButtonText: {
    fontSize: 12,
    fontWeight: "800",
  },
});
