import React, { useEffect, useRef } from "react";

import {
  View,
  Text,
  StyleSheet,
  Animated,
  StatusBar,
} from "react-native";

export default function SplashScreen({ navigation }) {
  const logoScale = useRef(
    new Animated.Value(0.5)
  ).current;

  const fadeAnim = useRef(
    new Animated.Value(0)
  ).current;

  const heartAnim = useRef(
    
    new Animated.Value(0)
  ).current;

  useEffect(() => {
    // LOGO, TEXT AND HEART ANIMATIONS
    const animation = Animated.parallel([
      Animated.spring(logoScale, {
        toValue: 1,
        friction: 5,
        tension: 45,
        useNativeDriver: true,
      }),

      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1200,
        useNativeDriver: true,
      }),

      Animated.loop(
        Animated.sequence([
          Animated.timing(heartAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),

          Animated.timing(heartAnim, {
            toValue: 0,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ),
    ]);

    animation.start();

    // OPEN WELCOME SCREEN
    const timer = setTimeout(() => {
      navigation.replace("Welcome");
    }, 3000);

    return () => {
      clearTimeout(timer);
      animation.stop();
    };
  }, [
    navigation,
    logoScale,
    fadeAnim,
    heartAnim,
  ]);

  return (
    <View style={styles.container}>
      <StatusBar
        backgroundColor="#705582"
        barStyle="light-content"
      />

      {/* DECORATIVE CIRCLES */}
      <View style={styles.circleTop} />
      <View style={styles.circleBottom} />

      {/* MAIN CONTENT */}
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,

            transform: [
              {
                scale: logoScale,
              },
            ],
          },
        ]}
      >
        {/* ANIMATED LOGO */}
        <View style={styles.logoContainer}>
          <View style={styles.logoCircle}>
            <Text style={styles.logo}>
              🛍️
            </Text>
          </View>

          {/* FLOATING HEART */}
          <Animated.Text
            style={[
              styles.floatingHeart,
              {
                opacity: heartAnim,

                transform: [
                  {
                    translateY: heartAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [5, -8],
                    }),
                  },
                ],
              },
            ]}
          >
            💗
          </Animated.Text>

          <Text style={styles.sparkle}>
            ✦
          </Text>

          <Text style={styles.sparkleTwo}>
            ✧
          </Text>
        </View>

        {/* LUNA BRAND NAME */}
        <Text style={styles.brandName}>
          LUNA
        </Text>

        <View style={styles.line} />

        {/* TAGLINE */}
        <Text style={styles.tagline}>
          YOUR STYLE, YOUR STORY
        </Text>

        <Text style={styles.description}>
          Discover something beautiful
        </Text>
      </Animated.View>

      {/* BOTTOM CONTENT */}
      <Animated.View
        style={{
          opacity: fadeAnim,
        }}
      >
        <Text style={styles.bottomText}>
          DISCOVER  •  LOVE  •  SHOP
        </Text>

        <Text style={styles.footer}>
          Made with love ♡
        </Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#705582",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 65,
    overflow: "hidden",
  },

  circleTop: {
    position: "absolute",
    top: -110,
    right: -100,
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: "#A894B8",
    opacity: 0.4,
  },

  circleBottom: {
    position: "absolute",
    bottom: -130,
    left: -100,
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: "#E9C9D8",
    opacity: 0.2,
  },

  content: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  logoContainer: {
    width: 180,
    height: 180,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 25,
  },

  logoCircle: {
    width: 145,
    height: 145,
    borderRadius: 45,
    backgroundColor: "#F1EBF5",
    justifyContent: "center",
    alignItems: "center",
    elevation: 12,

    shadowColor: "#29252D",
    shadowOpacity: 0.25,
    shadowRadius: 15,

    shadowOffset: {
      width: 0,
      height: 8,
    },
  },

  logo: {
    fontSize: 75,
  },

  floatingHeart: {
    position: "absolute",
    top: 5,
    right: 5,
    fontSize: 34,
  },

  sparkle: {
    position: "absolute",
    left: 5,
    top: 25,
    color: "#FFFFFF",
    fontSize: 35,
  },

  sparkleTwo: {
    position: "absolute",
    bottom: 10,
    right: 5,
    color: "#E9C9D8",
    fontSize: 30,
  },

  brandName: {
    fontSize: 43,
    fontWeight: "900",
    color: "#FFFFFF",
    letterSpacing: 10,
    marginLeft: 10,
  },

  line: {
    width: 65,
    height: 3,
    backgroundColor: "#E9C9D8",
    borderRadius: 5,
    marginTop: 15,
    marginBottom: 15,
  },

  tagline: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "800",
    letterSpacing: 3,
    textAlign: "center",
  },

  description: {
    color: "#F1EBF5",
    fontSize: 13,
    marginTop: 12,
    letterSpacing: 0.5,
  },

  bottomText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 2,
    textAlign: "center",
  },

  footer: {
    color: "#E9C9D8",
    fontSize: 12,
    textAlign: "center",
    marginTop: 15,
  },
});
