import React, { useState } from "react";

import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  Alert,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { useWishlist } from "../context/WishlistContext";
import { useCart } from "../context/CartContext";

export default function DetailsScreen({ navigation, route }) {
  const { colors, isDark } = useTheme();

  const { user } = useAuth();

  const {
    wishlist = [],
    toggleWishlist,
  } = useWishlist();

  const { addToCart } = useCart();

  const product = route?.params?.product;

  const [quantity, setQuantity] = useState(1);
  const [imageFailed, setImageFailed] = useState(false);
const placeholder = { uri: "https://placehold.co/500x500/EDE7F3/6B4E7D.png?text=No+Image" };
  if (!product) {
    return (
      <View
        style={[
          styles.screen,
          styles.center,
          { backgroundColor: colors.background },
        ]}
      >
        <Ionicons
          name="alert-circle-outline"
          size={55}
          color={colors.primary}
        />

        <Text style={[styles.errorTitle, { color: colors.text }]}>
          Product not found
        </Text>

        <TouchableOpacity
          style={[
            styles.button,
            { backgroundColor: colors.primary },
          ]}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.buttonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const price = Number(product.price) || 0;

  const title =
    product.title || product.name || "Beautiful Product";

  const description =
    product.description ||
    "Discover your new favourite from LUNA. This carefully selected product brings style, beauty and everyday comfort together.";

  const rating = Number(product.rating) || 4.5;

  const isSale = product.onSale === true;

  const isFavourite = wishlist.some(
    (item) => String(item.id) === String(product.id)
  );

  const imageUrl =
    typeof product.image === "string" &&
    product.image.trim() !== "" &&
    product.image !== "string"
      ? product.image
      : typeof product.thumbnail === "string" &&
        product.thumbnail.trim() !== "" &&
        product.thumbnail !== "string"
      ? product.thumbnail
      : null;

  const imageSource =
    imageUrl && !imageFailed
      ? { uri: imageUrl }
      : placeholder;

  function handleAddToCart() {
    if (!user) {
      Alert.alert(
        "Login Required",
        "Please login or create an account first.",
        [
          {
            text: "Cancel",
            style: "cancel",
          },
          {
            text: "Login",
            onPress: () =>
              navigation.navigate("Login", {
                returnTo: "Details",
                pendingProduct: product,
                pendingQuantity: quantity,
              }),
          },
          {
            text: "Sign Up",
            onPress: () =>
              navigation.navigate("Signup", {
                returnTo: "Details",
                pendingProduct: product,
                pendingQuantity: quantity,
              }),
          },
        ]
      );

      return;
    }

    addToCart({
      ...product,
      quantity,
    });

    Alert.alert(
      "Added to Cart 💗",
      `${quantity} × ${title} added to your cart.`,
      [
        {
          text: "Continue Shopping",
          style: "cancel",
        },
        {
          text: "View Cart",
          onPress: () => navigation.navigate("Cart"),
        },
      ]
    );
  }

  function handleWishlist() {
    toggleWishlist(product);
  }

  return (
    <View
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Product image */}
        <View
          style={[
            styles.imageContainer,
            { backgroundColor: colors.card },
          ]}
        >
          <Image
            source={imageSource}
            style={styles.image}
            resizeMode="contain"
            onError={() => setImageFailed(true)}
          />

          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Ionicons
              name="arrow-back"
              size={23}
              color="#29252D"
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.heartButton}
            onPress={handleWishlist}
          >
            <Ionicons
              name={isFavourite ? "heart" : "heart-outline"}
              size={23}
              color={isFavourite ? "#E85D86" : "#705582"}
            />
          </TouchableOpacity>

          {isSale && (
            <View style={styles.discountBadge}>
              <Text style={styles.discountText}>
                20% OFF
              </Text>
            </View>
          )}
        </View>

        <View style={styles.content}>
          <Text style={[styles.category, { color: colors.primary }]}>
            {product.category || "LUNA COLLECTION"}
          </Text>

          <Text style={[styles.title, { color: colors.text }]}>
            {title}
          </Text>

          <View style={styles.ratingRow}>
            <Ionicons
              name="star"
              size={17}
              color="#E5A000"
            />

            <Text style={[styles.rating, { color: colors.text }]}>
              {rating.toFixed(1)}
            </Text>

            <Text style={[styles.ratingLabel, { color: colors.muted }]}>
              Product rating
            </Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={[styles.price, { color: colors.primary }]}>
              Rs. {price.toLocaleString("en-PK")}
            </Text>
          </View>

          <View
            style={[
              styles.divider,
              { backgroundColor: colors.border },
            ]}
          />

          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Product Description
          </Text>

          <Text style={[styles.description, { color: colors.muted }]}>
            {description}
          </Text>

          {isSale && (
            <View
              style={[
                styles.offerBox,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                },
              ]}
            >
              <Ionicons
                name="pricetag-outline"
                size={22}
                color={colors.primary}
              />

              <View style={{ flex: 1 }}>
                <Text style={[styles.offerTitle, { color: colors.text }]}>
                  Special Sale Offer
                </Text>

                <Text
                  style={[
                    styles.offerDescription,
                    { color: colors.muted },
                  ]}
                >
                  Save 20% on eligible sale products when your cart subtotal
                  reaches Rs. 1,200.
                </Text>
              </View>
            </View>
          )}

          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            Quantity
          </Text>

          <View style={styles.quantityRow}>
            <TouchableOpacity
              style={[
                styles.quantityButton,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                },
              ]}
              onPress={() =>
                setQuantity((previous) => Math.max(1, previous - 1))
              }
              disabled={quantity <= 1}
            >
              <Ionicons
                name="remove"
                size={19}
                color={colors.primary}
              />
            </TouchableOpacity>

            <Text style={[styles.quantity, { color: colors.text }]}>
              {quantity}
            </Text>

            <TouchableOpacity
              style={[
                styles.quantityButton,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                },
              ]}
              onPress={() =>
                setQuantity((previous) => Math.min(99, previous + 1))
              }
              disabled={quantity >= 99}
            >
              <Ionicons
                name="add"
                size={19}
                color={colors.primary}
              />
            </TouchableOpacity>
          </View>

          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.muted }]}>
              Item subtotal
            </Text>

            <Text style={[styles.totalPrice, { color: colors.text }]}>
              Rs. {(price * quantity).toLocaleString("en-PK")}
            </Text>
          </View>

          <TouchableOpacity
            style={[
              styles.button,
              { backgroundColor: colors.primary },
            ]}
            onPress={handleAddToCart}
            activeOpacity={0.85}
          >
            <Ionicons
              name="bag-add-outline"
              size={20}
              color="#FFFFFF"
            />

            <Text style={styles.buttonText}>
              Add to Cart
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.secondaryButton,
              {
                borderColor: colors.border,
                backgroundColor: colors.card,
              },
            ]}
            onPress={handleWishlist}
          >
            <Ionicons
              name={isFavourite ? "heart" : "heart-outline"}
              size={19}
              color="#E85D86"
            />

            <Text
              style={[
                styles.secondaryButtonText,
                { color: colors.text },
              ]}
            >
              {isFavourite
                ? "Remove from Wishlist"
                : "Add to Wishlist"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.secondaryButton,
              {
                borderColor: colors.border,
                backgroundColor: colors.card,
              },
            ]}
            onPress={() => navigation.navigate("Cart")}
          >
            <Ionicons
              name="bag-outline"
              size={19}
              color={colors.primary}
            />

            <Text
              style={[
                styles.secondaryButtonText,
                { color: colors.text },
              ]}
            >
              View Shopping Cart
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  scrollContent: {
    paddingBottom: 30,
  },

  center: {
    justifyContent: "center",
    alignItems: "center",
    padding: 25,
  },

  imageContainer: {
    height: 350,
    position: "relative",
    alignItems: "center",
    justifyContent: "center",
  },

  image: {
    width: "100%",
    height: "100%",
  },

  backButton: {
    position: "absolute",
    top: 45,
    left: 18,
    width: 43,
    height: 43,
    borderRadius: 14,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },

  heartButton: {
    position: "absolute",
    top: 45,
    right: 18,
    width: 43,
    height: 43,
    borderRadius: 14,
    backgroundColor: "#FFFFFF",
    alignItems: "center",
    justifyContent: "center",
  },

  discountBadge: {
    position: "absolute",
    bottom: 18,
    left: 18,
    backgroundColor: "#E85D86",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },

  discountText: {
    color: "#FFFFFF",
    fontSize: 11,
    fontWeight: "900",
  },

  content: {
    padding: 22,
  },

  category: {
    fontSize: 11,
    fontWeight: "900",
    letterSpacing: 1.5,
  },

  title: {
    fontSize: 25,
    lineHeight: 33,
    fontWeight: "900",
    marginTop: 9,
  },

  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 12,
    gap: 6,
  },

  rating: {
    fontSize: 13,
    fontWeight: "900",
  },

  ratingLabel: {
    fontSize: 11,
  },

  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 13,
  },

  price: {
    fontSize: 23,
    fontWeight: "900",
  },

  divider: {
    height: 1,
    marginVertical: 22,
  },

  sectionTitle: {
    fontSize: 15,
    fontWeight: "900",
    marginBottom: 10,
  },

  description: {
    fontSize: 12,
    lineHeight: 21,
  },

  offerBox: {
    flexDirection: "row",
    gap: 12,
    alignItems: "flex-start",
    padding: 14,
    borderRadius: 15,
    borderWidth: 1,
    marginTop: 22,
    marginBottom: 22,
  },

  offerTitle: {
    fontSize: 12,
    fontWeight: "900",
  },

  offerDescription: {
    fontSize: 10,
    lineHeight: 16,
    marginTop: 5,
  },

  quantityRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 20,
    marginTop: 5,
  },

  quantityButton: {
    width: 40,
    height: 40,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  quantity: {
    fontSize: 17,
    fontWeight: "900",
  },

  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 25,
    marginBottom: 15,
  },

  totalLabel: {
    fontSize: 13,
    fontWeight: "700",
  },

  totalPrice: {
    fontSize: 18,
    fontWeight: "900",
  },

  button: {
    minHeight: 53,
    borderRadius: 15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },

  buttonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "900",
  },

  secondaryButton: {
    minHeight: 50,
    borderRadius: 15,
    borderWidth: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 9,
    marginTop: 12,
  },

  secondaryButtonText: {
    fontSize: 12,
    fontWeight: "800",
  },

  errorTitle: {
    fontSize: 20,
    fontWeight: "900",
    marginVertical: 15,
  },
});
