import React, { useState } from "react";

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";

export default function SignupScreen({ navigation }) {
  const { signup } = useAuth();
  const { colors } = useTheme();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const muted =
    colors.muted || colors.secondaryText || "#A894B8";

  // CREATE ACCOUNT
  async function handleSignup() {
    if (isLoading) {
      return;
    }

    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();

    // Validate required fields
    if (!cleanName || !cleanEmail || !password) {
      Alert.alert(
        "Required Fields",
        "Please fill in all fields."
      );
      return;
    }

    // Validate email
    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
      Alert.alert(
        "Invalid Email",
        "Please enter a valid email address."
      );
      return;
    }

    // Validate password
    if (password.length < 6) {
      Alert.alert(
        "Weak Password",
        "Password must contain at least 6 characters."
      );
      return;
    }

    try {
      setIsLoading(true);

      const result = await signup(
        cleanName,
        cleanEmail,
        password
      );

      if (!result?.success) {
        Alert.alert(
          "Signup Failed",
          result?.message ||
            "Unable to create your account."
        );
        return;
      }

      Alert.alert(
        "Welcome to Luna! 💜",
        `Your account has been created successfully, ${cleanName}!`,
        [
          {
            text: "Continue Shopping",
            onPress: () => navigation.replace("Home"),
          },
        ]
      );
    } catch (error) {
      console.log("Signup screen error:", error);

      Alert.alert(
        "Something Went Wrong",
        "Please try creating your account again."
      );
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Back Button */}
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={[
            styles.back,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
          activeOpacity={0.7}
        >
          <Ionicons
            name="arrow-back"
            size={23}
            color={colors.text}
          />
        </TouchableOpacity>

        {/* Logo */}
        <View
          style={[
            styles.logo,
            { backgroundColor: colors.secondary },
          ]}
        >
          <Ionicons
            name="heart"
            size={38}
            color="#FFFFFF"
          />
        </View>

        {/* Brand */}
        <Text
          style={[
            styles.brand,
            { color: colors.primary },
          ]}
        >
          L U N A
        </Text>

        {/* Heading */}
        <Text
          style={[
            styles.title,
            { color: colors.text },
          ]}
        >
          Create Account
        </Text>

        <Text
          style={[
            styles.subtitle,
            { color: muted },
          ]}
        >
          Join Luna and discover your new favourites.
        </Text>

        {/* Full Name Label */}
        <Text
          style={[
            styles.label,
            { color: colors.text },
          ]}
        >
          Full Name
        </Text>

        {/* Full Name Input */}
        <View
          style={[
            styles.inputBox,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="person-outline"
            size={20}
            color={muted}
          />

          <TextInput
            placeholder="Your full name"
            placeholderTextColor={muted}
            value={name}
            onChangeText={setName}
            autoCapitalize="words"
            autoCorrect={false}
            style={[
              styles.input,
              { color: colors.text },
            ]}
            returnKeyType="next"
          />
        </View>

        {/* Email Label */}
        <Text
          style={[
            styles.label,
            { color: colors.text },
          ]}
        >
          Email Address
        </Text>

        {/* Email Input */}
        <View
          style={[
            styles.inputBox,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="mail-outline"
            size={20}
            color={muted}
          />

          <TextInput
            placeholder="example@gmail.com"
            placeholderTextColor={muted}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            textContentType="emailAddress"
            value={email}
            onChangeText={setEmail}
            style={[
              styles.input,
              { color: colors.text },
            ]}
            returnKeyType="next"
          />
        </View>

        {/* Password Label */}
        <Text
          style={[
            styles.label,
            { color: colors.text },
          ]}
        >
          Password
        </Text>

        {/* Password Input */}
        <View
          style={[
            styles.inputBox,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={muted}
          />

          <TextInput
            placeholder="Minimum 6 characters"
            placeholderTextColor={muted}
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="new-password"
            textContentType="newPassword"
            style={[
              styles.input,
              { color: colors.text },
            ]}
            returnKeyType="done"
            onSubmitEditing={handleSignup}
          />

          {/* Show / Hide Password */}
          <TouchableOpacity
            onPress={() =>
              setShowPassword((previous) => !previous)
            }
            activeOpacity={0.7}
            accessibilityRole="button"
            accessibilityLabel={
              showPassword
                ? "Hide password"
                : "Show password"
            }
            style={styles.eyeButton}
          >
            <Ionicons
              name={
                showPassword
                  ? "eye-outline"
                  : "eye-off-outline"
              }
              size={22}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        {/* Create Account Button */}
        <TouchableOpacity
          style={[
            styles.button,
            { backgroundColor: colors.primary },
            isLoading && styles.disabledButton,
          ]}
          onPress={handleSignup}
          activeOpacity={0.85}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <>
              <Text style={styles.buttonText}>
                Create My Account
              </Text>

              <Ionicons
                name="arrow-forward"
                size={19}
                color="#FFFFFF"
              />
            </>
          )}
        </TouchableOpacity>

        {/* Login Link */}
        <View style={styles.loginRow}>
          <Text style={{ color: muted }}>
            Already have an account?{" "}
          </Text>

          <TouchableOpacity
            onPress={() => navigation.navigate("Login")}
            activeOpacity={0.7}
          >
            <Text
              style={{
                color: colors.primary,
                fontWeight: "900",
              }}
            >
              Login
            </Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <Text
          style={[
            styles.footer,
            { color: muted },
          ]}
        >
          Discover • Love • Shop 💗
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  container: {
    flexGrow: 1,
    paddingHorizontal: 25,
    paddingTop: 45,
    paddingBottom: 35,
  },

  back: {
    width: 43,
    height: 43,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 25,
  },

  logo: {
    width: 75,
    height: 75,
    borderRadius: 25,
    alignItems: "center",
    justifyContent: "center",
    alignSelf: "center",
  },

  brand: {
    textAlign: "center",
    fontSize: 15,
    fontWeight: "900",
    letterSpacing: 3,
    marginTop: 12,
  },

  title: {
    fontSize: 27,
    fontWeight: "900",
    marginTop: 25,
  },

  subtitle: {
    fontSize: 12,
    marginTop: 8,
    marginBottom: 20,
    lineHeight: 20,
  },

  label: {
    fontSize: 12,
    fontWeight: "800",
    marginTop: 15,
    marginBottom: 8,
  },

  inputBox: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    minHeight: 53,
    gap: 10,
  },

  input: {
    flex: 1,
    fontSize: 13,
    paddingVertical: 12,
  },

  eyeButton: {
    padding: 5,
    justifyContent: "center",
    alignItems: "center",
  },

  button: {
    height: 55,
    borderRadius: 15,
    marginTop: 30,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },

  disabledButton: {
    opacity: 0.7,
  },

  buttonText: {
    color: "#FFFFFF",
    fontWeight: "900",
    fontSize: 14,
  },

  loginRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginTop: 25,
  },

  footer: {
    textAlign: "center",
    marginTop: 30,
    fontSize: 11,
    letterSpacing: 1,
  },
});
