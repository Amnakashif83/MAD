import React from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Alert,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";

function MenuItem({
  icon,
  title,
  subtitle,
  colors,
  onPress,
  danger = false,
}) {
  return (
    <TouchableOpacity
      style={[
        styles.menuItem,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
        },
      ]}
      onPress={onPress}
      activeOpacity={0.75}
    >
      <View
        style={[
          styles.menuIcon,
          { backgroundColor: colors.primary + "18" },
        ]}
      >
        <Ionicons
          name={icon}
          size={21}
          color={danger ? colors.error : colors.primary}
        />
      </View>

      <View style={styles.menuContent}>
        <Text
          style={[
            styles.menuTitle,
            { color: danger ? colors.error : colors.text },
          ]}
        >
          {title}
        </Text>

        {!!subtitle && (
          <Text style={[styles.menuSubtitle, { color: colors.muted }]}>
            {subtitle}
          </Text>
        )}
      </View>

      <Ionicons
        name="chevron-forward"
        size={18}
        color={colors.muted}
      />
    </TouchableOpacity>
  );
}

export default function ProfileScreen({ navigation }) {
  const { colors, isDark } = useTheme();
  const { user, logout } = useAuth();
  const { cart = [] } = useCart();

  const displayName = user?.name || "LUNA Shopper";
  const displayEmail = user?.email || "Guest account";

  const handleLogout = () => {
    Alert.alert(
      "Logout",
      "Are you sure you want to log out?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Logout",
          style: "destructive",
          onPress: async () => {
            try {
              await logout();

              navigation.reset({
                index: 0,
                routes: [{ name: "Welcome" }],
              });
            } catch (error) {
              console.log("Logout error:", error);

              Alert.alert(
                "Error",
                "Unable to log out. Please try again."
              );
            }
          },
        },
      ]
    );
  };

  const menuItems = [
    {
      icon: "bag-handle-outline",
      title: "My Orders",
      subtitle: "View your previous purchases",
      onPress: () => navigation.navigate("OrderHistory"),
    },
    {
      icon: "heart-outline",
      title: "My Wishlist",
      subtitle: "Your favourite products",
      onPress: () => navigation.navigate("Wishlist"),
    },
    {
      icon: "cart-outline",
      title: "Shopping Cart",
      subtitle: `${cart.length} product types in your cart`,
      onPress: () => navigation.navigate("Cart"),
    },
    {
      icon: "settings-outline",
      title: "Settings",
      subtitle: "Theme and app preferences",
      onPress: () => navigation.navigate("Settings"),
    },
  ];

  return (
    <ScrollView
      style={[
        styles.screen,
        { backgroundColor: colors.background },
      ]}
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={isDark ? "light-content" : "dark-content"}
      />

      <View style={styles.header}>
        <View>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>
            LUNA MEMBER
          </Text>

          <Text style={[styles.heading, { color: colors.text }]}>
            My Account
          </Text>
        </View>

        <TouchableOpacity
          style={[
            styles.settingsButton,
            { backgroundColor: colors.card },
          ]}
          onPress={() => navigation.navigate("Settings")}
        >
          <Ionicons
            name="settings-outline"
            size={22}
            color={colors.primary}
          />
        </TouchableOpacity>
      </View>

      <View
        style={[
          styles.profileCard,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
          },
        ]}
      >
        <View
          style={[
            styles.avatar,
            { backgroundColor: colors.primary },
          ]}
        >
          <Text style={styles.avatarText}>
            {displayName.charAt(0).toUpperCase()}
          </Text>
        </View>

        <View style={styles.profileInfo}>
          <Text
            style={[styles.profileName, { color: colors.text }]}
            numberOfLines={1}
          >
            {displayName}
          </Text>

          <Text
            style={[styles.profileEmail, { color: colors.muted }]}
            numberOfLines={2}
          >
            {displayEmail}
          </Text>

          <View style={styles.memberBadge}>
            <Ionicons
              name="checkmark-circle"
              size={13}
              color={colors.success}
            />

            <Text style={[styles.memberBadgeText, { color: colors.success }]}>
              LUNA Shopper
            </Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate("Settings")}
        >
          <Ionicons
            name="create-outline"
            size={21}
            color={colors.primary}
          />
        </TouchableOpacity>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          Account Overview
        </Text>
      </View>

      <View style={styles.statsRow}>
        <TouchableOpacity
          style={[
            styles.statCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
          onPress={() => navigation.navigate("OrderHistory")}
        >
          <Ionicons
            name="receipt-outline"
            size={23}
            color={colors.primary}
          />

          <Text style={[styles.statValue, { color: colors.text }]}>
            Orders
          </Text>

          <Text style={[styles.statLabel, { color: colors.muted }]}>
            View history
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.statCard,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
          onPress={() => navigation.navigate("Cart")}
        >
          <Ionicons
            name="bag-outline"
            size={23}
            color={colors.primary}
          />

          <Text style={[styles.statValue, { color: colors.text }]}>
            {cart.length}
          </Text>

          <Text style={[styles.statLabel, { color: colors.muted }]}>
            Cart items
          </Text>
        </TouchableOpacity>
      </View>

      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, { color: colors.text }]}>
          My Account
        </Text>
      </View>

      {menuItems.map((item) => (
        <MenuItem
          key={item.title}
          icon={item.icon}
          title={item.title}
          subtitle={item.subtitle}
          colors={colors}
          onPress={item.onPress}
        />
      ))}

      {!user && (
        <MenuItem
          icon="log-in-outline"
          title="Login"
          subtitle="Sign in to your LUNA account"
          colors={colors}
          onPress={() => navigation.navigate("Login")}
        />
      )}

      {user && (
        <MenuItem
          icon="log-out-outline"
          title="Logout"
          subtitle="Sign out of your account"
          colors={colors}
          onPress={handleLogout}
          danger
        />
      )}

      <View style={styles.footer}>
        <Ionicons
          name="heart"
          size={15}
          color="#E85D86"
        />

        <Text style={[styles.footerText, { color: colors.muted }]}>
          Made with love by LUNA
        </Text>

        <Text style={[styles.version, { color: colors.muted }]}>
          Version 1.0.0
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },
  container: {
    padding: 18,
    paddingBottom: 35,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 22,
  },
  eyebrow: {
    fontSize: 10,
    fontWeight: "900",
    letterSpacing: 2,
  },
  heading: {
    fontSize: 25,
    fontWeight: "900",
    marginTop: 5,
  },
  settingsButton: {
    width: 46,
    height: 46,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  profileCard: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 20,
    padding: 17,
    gap: 13,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#FFFFFF",
    fontSize: 27,
    fontWeight: "900",
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 16,
    fontWeight: "900",
  },
  profileEmail: {
    fontSize: 11,
    marginTop: 5,
  },
  memberBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    marginTop: 8,
  },
  memberBadgeText: {
    fontSize: 10,
    fontWeight: "800",
  },
  sectionHeader: {
    marginTop: 27,
    marginBottom: 13,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "900",
  },
  statsRow: {
    flexDirection: "row",
    gap: 12,
  },
  statCard: {
    flex: 1,
    borderWidth: 1,
    borderRadius: 17,
    padding: 15,
  },
  statValue: {
    fontSize: 17,
    fontWeight: "900",
    marginTop: 11,
  },
  statLabel: {
    fontSize: 10,
    marginTop: 4,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderRadius: 16,
    padding: 13,
    marginBottom: 10,
    gap: 12,
  },
  menuIcon: {
    width: 43,
    height: 43,
    borderRadius: 13,
    alignItems: "center",
    justifyContent: "center",
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 12,
    fontWeight: "900",
  },
  menuSubtitle: {
    fontSize: 10,
    marginTop: 5,
  },
  footer: {
    alignItems: "center",
    marginTop: 32,
    gap: 7,
  },
  footerText: {
    fontSize: 11,
    fontWeight: "700",
  },
  version: {
    fontSize: 10,
  },
});
