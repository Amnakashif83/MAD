import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  StatusBar,
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export default function LoginScreen({ navigation }) {
  const auth = useAuth();
  const { colors, isDark } = useTheme();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const muted =
    colors.muted ||
    colors.secondaryText ||
    '#A894B8';

  async function handleLogin() {
    if (loading) return;

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !password) {
      Alert.alert(
        'Missing Information',
        'Please enter your email and password.'
      );
      return;
    }

    if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
      Alert.alert(
        'Invalid Email',
        'Please enter a valid email address.'
      );
      return;
    }

    if (typeof auth?.login !== 'function') {
      Alert.alert(
        'Login Unavailable',
        'Please check your AuthContext configuration.'
      );
      return;
    }

    try {
      setLoading(true);

      const result = await auth.login(
        cleanEmail,
        password
      );

      if (result?.success === false) {
        Alert.alert(
          'Login Failed',
          result.message || 'Incorrect email or password.'
        );
        return;
      }

      if (result === false) {
        Alert.alert(
          'Login Failed',
          'Incorrect email or password.'
        );
        return;
      }

      navigation.reset({
        index: 0,
        routes: [
          {
            name: 'Main',
          },
        ],
      });
    } catch (error) {
      console.log('Login error:', error);

      Alert.alert(
        'Login Failed',
        error?.message ||
          'Unable to log in. Please try again.'
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={[
        styles.screen,
        {
          backgroundColor: colors.background,
        },
      ]}
      behavior={
        Platform.OS === 'ios' ? 'padding' : undefined
      }
    >
      <StatusBar
        backgroundColor={colors.background}
        barStyle={
          isDark ? 'light-content' : 'dark-content'
        }
      />

      <ScrollView
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <TouchableOpacity
          style={[
            styles.backButton,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
          onPress={() => navigation.goBack()}
          activeOpacity={0.75}
        >
          <Ionicons
            name="arrow-back"
            size={22}
            color={colors.text}
          />
        </TouchableOpacity>

        <View
          style={[
            styles.logo,
            {
              backgroundColor: colors.primary,
            },
          ]}
        >
          <Ionicons
            name="heart"
            size={38}
            color="#FFFFFF"
          />
        </View>

        <Text
          style={[
            styles.brand,
            {
              color: colors.primary,
            },
          ]}
        >
          L U N A
        </Text>

        <Text
          style={[
            styles.title,
            {
              color: colors.text,
            },
          ]}
        >
          Welcome Back!
        </Text>

        <Text
          style={[
            styles.subtitle,
            {
              color: muted,
            },
          ]}
        >
          Log in to discover your favourite styles.
        </Text>

        <Text
          style={[
            styles.label,
            {
              color: colors.text,
            },
          ]}
        >
          Email Address
        </Text>

        <View
          style={[
            styles.inputBox,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="mail-outline"
            size={20}
            color={muted}
          />

          <TextInput
            style={[
              styles.input,
              {
                color: colors.text,
              },
            ]}
            placeholder="example@gmail.com"
            placeholderTextColor={muted}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="email"
            textContentType="emailAddress"
            returnKeyType="next"
          />
        </View>

        <Text
          style={[
            styles.label,
            {
              color: colors.text,
            },
          ]}
        >
          Password
        </Text>

        <View
          style={[
            styles.inputBox,
            {
              backgroundColor: colors.card,
              borderColor: colors.border,
            },
          ]}
        >
          <Ionicons
            name="lock-closed-outline"
            size={20}
            color={muted}
          />

          <TextInput
            style={[
              styles.input,
              {
                color: colors.text,
              },
            ]}
            placeholder="Enter your password"
            placeholderTextColor={muted}
            value={password}
            onChangeText={setPassword}
            secureTextEntry={!showPassword}
            autoCapitalize="none"
            autoCorrect={false}
            autoComplete="current-password"
            textContentType="password"
            returnKeyType="done"
            onSubmitEditing={handleLogin}
          />

          <TouchableOpacity
            onPress={() =>
              setShowPassword(previous => !previous)
            }
            accessibilityRole="button"
            accessibilityLabel={
              showPassword
                ? 'Hide password'
                : 'Show password'
            }
            style={styles.eyeButton}
          >
            <Ionicons
              name={
                showPassword
                  ? 'eye-outline'
                  : 'eye-off-outline'
              }
              size={21}
              color={colors.primary}
            />
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          style={[
            styles.loginButton,
            {
              backgroundColor: colors.primary,
              opacity: loading ? 0.7 : 1,
            },
          ]}
          onPress={handleLogin}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <>
              <Text style={styles.loginButtonText}>
                Login to LUNA
              </Text>

              <Ionicons
                name="arrow-forward"
                size={19}
                color="#FFFFFF"
              />
            </>
          )}
        </TouchableOpacity>

        <View style={styles.signupRow}>
          <Text
            style={{
              color: muted,
            }}
          >
            Don't have an account?{' '}
          </Text>

          <TouchableOpacity
            onPress={() =>
              navigation.navigate('Signup')
            }
          >
            <Text
              style={{
                color: colors.primary,
                fontWeight: '900',
              }}
            >
              Sign Up
            </Text>
          </TouchableOpacity>
        </View>

        <Text
          style={[
            styles.footer,
            {
              color: muted,
            },
          ]}
        >
          Discover • Love • Shop ♡
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
  },

  container: {
    flexGrow: 1,
    paddingHorizontal: 25,
    paddingTop: 45,
    paddingBottom: 35,
  },

  backButton: {
    width: 43,
    height: 43,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
  },

  logo: {
    width: 75,
    height: 75,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
  },

  brand: {
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 4,
    marginTop: 14,
  },

  title: {
    fontSize: 28,
    fontWeight: '900',
    marginTop: 32,
  },

  subtitle: {
    fontSize: 12,
    lineHeight: 20,
    marginTop: 9,
    marginBottom: 20,
  },

  label: {
    fontSize: 12,
    fontWeight: '800',
    marginTop: 17,
    marginBottom: 9,
  },

  inputBox: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 14,
    minHeight: 55,
    gap: 10,
  },

  input: {
    flex: 1,
    fontSize: 13,
    paddingVertical: 12,
  },

  eyeButton: {
    padding: 5,
    alignItems: 'center',
    justifyContent: 'center',
  },

  loginButton: {
    minHeight: 55,
    borderRadius: 15,
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },

  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '900',
  },

  signupRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 25,
  },

  footer: {
    textAlign: 'center',
    marginTop: 35,
    fontSize: 11,
    letterSpacing: 1,
  },
});
