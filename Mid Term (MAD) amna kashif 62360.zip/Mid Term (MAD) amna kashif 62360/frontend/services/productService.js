
const DISCOUNT_THRESHOLD = 1200;
const DISCOUNT_RATE = 0.20;

export function calculateBill(cart = []) {
  const validCart = Array.isArray(cart) ? cart : [];

  const subtotal = validCart.reduce((total, item) => {
    const price = Math.max(0, Number(item.price) || 0);
    const quantity = Math.max(
      0,
      Number(item.quantity) || 0
    );

    return total + price * quantity;
  }, 0);

  const discountEligible = subtotal >= DISCOUNT_THRESHOLD;

  const discount = discountEligible
    ? validCart.reduce((total, item) => {
        if (item.onSale !== true) {
          return total;
        }

        const price = Math.max(0, Number(item.price) || 0);
        const quantity = Math.max(
          0,
          Number(item.quantity) || 0
        );

        return total + price * quantity * DISCOUNT_RATE;
      }, 0)
    : 0;

  const roundedSubtotal = Math.round(subtotal * 100) / 100;

  const roundedDiscount = Math.round(discount * 100) / 100;

  const total = Math.max(
    0,
    Math.round((roundedSubtotal - roundedDiscount) * 100) / 100
  );

  return {
    subtotal: roundedSubtotal,
    discount: roundedDiscount,
    total,
    discountEligible,
    discountThreshold: DISCOUNT_THRESHOLD,
    discountRate: DISCOUNT_RATE,
    amountRemaining: Math.max(
      0,
      Math.round((DISCOUNT_THRESHOLD - roundedSubtotal) * 100) / 100
    ),
  };
}

/**
 * Calculate the number of items in the cart.
 */
export function getCartItemCount(cart = []) {
  if (!Array.isArray(cart)) {
    return 0;
  }

  return cart.reduce((count, item) => {
    return count + Math.max(
      0,
      Number(item.quantity) || 0
    );
  }, 0);
}

/**
 * Calculate the discount for a single eligible product.
 */
export function calculateProductDiscount(product, cartSubtotal = 0) {
  const price = Math.max(0, Number(product?.price) || 0);

  if (
    product?.onSale !== true ||
    Number(cartSubtotal) < DISCOUNT_THRESHOLD
  ) {
    return 0;
  }

  return Math.round(price * DISCOUNT_RATE * 100) / 100;
}

/**
 * Return the final unit price when the cart qualifies.
 */
export function getDiscountedPrice(product, cartSubtotal = 0) {
  const price = Math.max(0, Number(product?.price) || 0);

  const discount = calculateProductDiscount(
    product,
    cartSubtotal
  );

  return Math.round((price - discount) * 100) / 100;
}
