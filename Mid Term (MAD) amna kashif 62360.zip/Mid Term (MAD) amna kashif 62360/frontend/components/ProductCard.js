
import React, { useState, useEffect } from "react";

import {
  View,
  Text,
  Image,
  Pressable,
  StyleSheet,
  ActivityIndicator,
} from "react-native";

import { Ionicons } from "@expo/vector-icons";

import { useTheme } from "../context/ThemeContext";

const PLACEHOLDER_IMAGE = {
  uri: "https://placehold.co/500x500/EDE7F3/6B4E7D.png?text=No+Image",
};

export default function ProductCard({
  product,
  onPress,
  onAdd,
  onWishlist,
  onToggleWishlist,
  isFavourite = false,
}) {
  const { colors } = useTheme();

  const [imageFailed, setImageFailed] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  const title =
    product?.title ||
    product?.name ||
    "Beautiful Product";
  const price = Number(product?.price) || 0;

  const productImage =
    product?.image !== undefined &&
    product?.image !== null &&
    product?.image !== "" &&
    product?.image !== "string"
      ? product.image
      : product?.thumbnail !== undefined &&
        product?.thumbnail !== null &&
        product?.thumbnail !== "" &&
        product?.thumbnail !== "string"
      ? product.thumbnail
      : null;

  const imageSource =
    !imageFailed && productImage
      ? typeof productImage === "string"
        ? { uri: productImage }
        : productImage
      : PLACEHOLDER_IMAGE;


  useEffect(() => {
    setImageFailed(false);
    setImageLoading(true);
  }, [product?.id, product?.image, product?.thumbnail]);


  function handleImageError() {
    setImageFailed(true);
    setImageLoading(false);
  }

  function handleImageLoad() {
    setImageLoading(false);
  }


  function handleAdd() {
    if (typeof onAdd === "function") {
      onAdd(product);
    }
  }


  function handleWishlist() {
    const wishlistHandler =
      typeof onToggleWishlist === "function"
        ? onToggleWishlist
        : onWishlist;

    if (typeof wishlistHandler === "function") {
      wishlistHandler(product);
    } else {
      console.warn(
        "Wishlist handler missing. Pass onWishlist or onToggleWishlist to ProductCard."
      );
    }
  }


  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
        },
      ]}
    >
      {/* PRODUCT IMAGE */}

      <Pressable
        style={styles.imagePressable}
        onPress={onPress}
        accessibilityRole="button"
        accessibilityLabel={`View ${title}`}
      >
        <View style={styles.imageContainer}>
          {imageLoading && !imageFailed && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator
                size="small"
                color={colors.primary}
              />
            </View>
          )}

          <Image
            source={imageSource}
            style={styles.image}
            resizeMode="contain"
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
        </View>
      </Pressable>

      {/* WISHLIST HEART */}

      <Pressable
        style={[
          styles.heartButton,
          {
            backgroundColor: colors.card,
          },
        ]}
        onPress={handleWishlist}
        hitSlop={8}
        accessibilityRole="button"
        accessibilityLabel={
          isFavourite
            ? "Remove from wishlist"
            : "Add to wishlist"
        }
        accessibilityState={{
          selected: isFavourite,
        }}
      >
        <Ionicons
          name={
            isFavourite
              ? "heart"
              : "heart-outline"
          }
          size={22}
          color={
            isFavourite
              ? colors.heart || "#E85D86"
              : colors.primary
          }
        />
      </Pressable>

      {/* PRODUCT INFORMATION */}

      <Pressable
        style={styles.info}
        onPress={onPress}
      >
        <Text
          numberOfLines={2}
          ellipsizeMode="tail"
          style={[
            styles.title,
            {
              color: colors.text,
            },
          ]}
        >
          {title}
        </Text>

        <Text
          numberOfLines={1}
          style={[
            styles.price,
            {
              color: colors.primary,
            },
          ]}
        >
          Rs. {price.toLocaleString("en-PK")}
        </Text>

        {product?.onSale === true && (
          <Text
            style={[
              styles.saleText,
              {
                color: colors.heart || "#E85D86",
              },
            ]}
          >
            20% OFF eligible orders
          </Text>
        )}
      </Pressable>

      {/* ADD TO CART */}

      <Pressable
        style={[
          styles.addButton,
          {
            backgroundColor: colors.primary,
          },
        ]}
        onPress={handleAdd}
        accessibilityRole="button"
        accessibilityLabel={`Add ${title} to cart`}
      >
        <Ionicons
          name="bag-add-outline"
          size={16}
          color={colors.buttonText || "#FFFFFF"}
        />

        <Text
          numberOfLines={1}
          adjustsFontSizeToFit
          minimumFontScale={0.8}
          style={[
            styles.addButtonText,
            {
              color: colors.buttonText || "#FFFFFF",
            },
          ]}
        >
          Add to Cart
        </Text>
      </Pressable>
    </View>
  );
}

// ============================================
// STYLES
// ============================================

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 0,
    maxWidth: "100%",
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    padding: 10,
    marginBottom: 12,
    overflow: "hidden",
    position: "relative",
  },

  imagePressable: {
    width: "100%",
  },

  imageContainer: {
    width: "100%",
    height: 155,
    alignItems: "center",
    justifyContent: "center",
    overflow: "hidden",
  },

  image: {
    width: "100%",
    height: "100%",
    alignSelf: "center",
  },

  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1,
  },

  heartButton: {
    position: "absolute",
    top: 15,
    right: 15,
    width: 38,
    height: 38,
    borderRadius: 19,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 2,
    elevation: 3,
  },

  info: {
    flexGrow: 1,
    paddingTop: 10,
  },

  title: {
    fontSize: 13,
    lineHeight: 18,
    fontWeight: "700",
    minHeight: 36,
  },

  price: {
    fontSize: 14,
    fontWeight: "900",
    marginTop: 7,
  },

  saleText: {
    fontSize: 9,
    fontWeight: "800",
    marginTop: 5,
  },

  addButton: {
    minHeight: 40,
    marginTop: 10,
    paddingHorizontal: 7,
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 5,
  },

  addButtonText: {
    fontSize: 11,
    fontWeight: "800",
    flexShrink: 1,
    textAlign: "center",
  },
});
