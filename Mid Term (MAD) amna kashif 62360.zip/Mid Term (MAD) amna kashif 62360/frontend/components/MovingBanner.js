import React, { useEffect, useRef, useState } from "react";
import { View, Text, Animated, Easing, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

const DEFAULT_MESSAGES = [
  "NEW ARRIVALS EVERY WEEK",
  "20% OFF ELIGIBLE SALE ITEMS OVER Rs. 1,200",
  "FREE DELIVERY ON SELECTED ORDERS",
];

export default function MovingBanner({
  messages = DEFAULT_MESSAGES,
  backgroundColor = "#E85D86",
  textColor = "#FFFFFF",
  speed = 45, // pixels per second
}) {
  const translateX = useRef(new Animated.Value(0)).current;
  const [textWidth, setTextWidth] = useState(0);

  const text = messages.join("   ✦   ") + "   ✦   ";

  useEffect(() => {
    if (!textWidth) return;

    translateX.setValue(0);

    const animation = Animated.loop(
      Animated.timing(translateX, {
        toValue: -textWidth,
        duration: (textWidth / speed) * 1000,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );

    animation.start();

    return () => animation.stop();
  }, [textWidth, speed, translateX]);

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Animated.View
        style={[styles.track, { transform: [{ translateX }] }]}
      >
        {[0, 1, 2, 3].map((i) => (
          <Text
            key={i}
            numberOfLines={1}
            onLayout={
              i === 0
                ? (e) => setTextWidth(e.nativeEvent.layout.width)
                : undefined
            }
            style={[styles.text, { color: textColor }]}
          >
            {text}
          </Text>
        ))}
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 38,
    borderRadius: 14,
    overflow: "hidden",
    justifyContent: "center",
    marginBottom: 18,
  },
  track: {
    flexDirection: "row",
    width: 6000,
    alignItems: "center",
  },
  text: {
    fontSize: 11,
    fontWeight: "800",
    letterSpacing: 1.2,
    flexShrink: 0,
  },
});