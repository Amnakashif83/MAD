const fs = require('fs');
const src = 'assets/hero.jpg';
const list = {
  'assets': ['cat-men', 'cat-women', 'cat-accessories', 'cat-makeup'],
  'assets/men': ['banner','stitched','unstitched','shirts','trousers','jeans','casual','formal','winter'],
  'assets/women': ['banner','stitched','unstitched','dresses','tops','jeans','casual','formal','winter'],
  'assets/acc': ['banner','him-wallets','him-watches','him-belts','him-sunglasses','him-bags','him-caps',
    'her-handbags','her-jewellery','her-earrings','her-necklaces','her-bracelets','her-watches','her-sunglasses'],
  'assets/makeup': ['banner','lipstick','foundation','mascara','eyeshadow','skincare','perfume'],
};
for (const dir in list) {
  fs.mkdirSync(dir, { recursive: true });
  list[dir].forEach((n) => { const f = `${dir}/${n}.jpg`; if (!fs.existsSync(f)) fs.copyFileSync(src, f); });
}
console.log('placeholders ready');