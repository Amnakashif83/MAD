import React from "react";

import {
  NavigationContainer,
  DefaultTheme,
  DarkTheme,
} from "@react-navigation/native";

import { GestureHandlerRootView } from "react-native-gesture-handler";

import {
  AuthProvider,
} from "./frontend/context/AuthContext";

import {
  CartProvider,
} from "./frontend/context/CartContext";

import {
  ThemeProvider,
  useTheme,
} from "./frontend/context/ThemeContext";

import {
  WishlistProvider,
} from "./frontend/context/WishlistContext";

import {
  OrderProvider,
} from "./frontend/context/OrderContext";

import StackNavigator from "./frontend/navigation/StackNavigator";
import DrawerNavigator from "./frontend/navigation/DrawerNavigator";

function RootNavigator() {
  const { colors, isDark } = useTheme();

  const navigationTheme = {
    ...(isDark ? DarkTheme : DefaultTheme),

    colors: {
      ...(isDark ? DarkTheme.colors : DefaultTheme.colors),
      primary: colors.primary,
      background: colors.background,
      card: colors.card,
      text: colors.text,
      border: colors.border,
      notification: colors.heart,
    },
  };

  return (
    <NavigationContainer theme={navigationTheme}>
      <StackNavigator />
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AuthProvider>
        <ThemeProvider>
          <WishlistProvider>
            <OrderProvider>
              <CartProvider>
                <RootNavigator />
              </CartProvider>
            </OrderProvider>
          </WishlistProvider>
        </ThemeProvider>
      </AuthProvider>
    </GestureHandlerRootView>
  );
}
